# Prompt per Progetto Azure Functions con CQRS e DDD

## 1. Expertise Richiesta

### Cloud Technologies
- **Microsoft Azure**
  - Azure Functions (Serverless/FaaS)
  - Azure Storage (Blob Storage, Queue Storage)
  - Azure Service Bus (per messaging asincrono)
  - Azure Cosmos DB o Azure SQL Database (per persistenza)

### Architetture Software
- **Architetture SOA** (Service-Oriented Architecture)
- **Architetture a Microservizi**
- **Serverless Architecture**
- **FaaS** (Function as a Service)

### Pattern Architetturali
- **CQRS** (Command Query Responsibility Segregation)
- **DDD** (Domain-Driven Design)
  - Aggregates
  - Domain Events
  - Bounded Contexts
  - Value Objects
  - Entities
- **Saga Pattern** (per gestione transazioni distribuite)
  - Orchestration-based Saga
  - Choreography-based Saga
  - Compensation logic

### Tecnologie di Sviluppo
- **TypeScript** (linguaggio principale)
- **Node.js** per runtime serverless
- **Azure Functions SDK** per Node.js/TypeScript

---

## 2. Obiettivo del Progetto

Realizzare un progetto **Node.js con TypeScript** che dimostri l'applicazione dei pattern **SAGA**, **CQRS** e **DDD** utilizzando **Azure Functions** (FaaS).

Il progetto deve essere un esempio concreto e funzionante che implementi due processi di business realistici nel dominio delle telecomunicazioni mobili.

---

## 3. Requisiti Funzionali

### 3.1 Processo: Acquisto SIM Card Mobile

Implementare un processo completo di acquisto di una SIM card per telefonia mobile che preveda i seguenti step:

#### Commands (Scrittura)
1. **Iniziare Transazione di Acquisto**
   - Raccogliere dati del cliente (nome, cognome, email, telefono)
   - Raccogliere dati della SIM richiesta (tipo di piano, numero preferito, ecc.)
   - Validare i dati di input
   - Creare un Order ID univoco

2. **Caricare Documentazione Cliente**
   - Upload carta d'identità (fronte e retro)
   - Upload codice fiscale
   - Archiviare i file su Azure Blob Storage
   - Registrare i riferimenti ai documenti nell'ordine

3. **Richiedere Abilitazione SIM**
   - Sottomettere la richiesta per approvazione
   - Generare un task per il personale addetto

4. **Approvare/Rifiutare Abilitazione** (azione operatore)
   - Validare la documentazione
   - Approvare o rifiutare la richiesta
   - Emettere evento di approvazione/rifiuto

5. **Generare Contratto**
   - Generare documento PDF del contratto
   - Archiviare il contratto su storage
   - Associare il contratto all'ordine

6. **Inviare Contratto al Cliente**
   - Inviare email con link al contratto
   - Registrare l'invio

#### Queries (Lettura)
- Ottenere stato dell'ordine per Order ID
- Ottenere lista ordini per cliente
- Ottenere storico delle transizioni di stato
- Ottenere documenti associati a un ordine

#### Domain Events
- `SimCardOrderCreated`
- `CustomerDocumentsUploaded`
- `ActivationRequested`
- `ActivationApproved` / `ActivationRejected`
- `ContractGenerated`
- `ContractSentToCustomer`

#### Saga Pattern per Gestione Transazioni Distribuite
- **Saga Name**: SimCardOrderSaga
- **Steps**:
  1. Create Order → (compensate: Cancel Order)
  2. Upload Documents → (compensate: Delete Documents)
  3. Request Activation → (compensate: Cancel Activation Request)
  4. Approve Activation → (compensate: Revoke Activation)
  5. Generate Contract → (compensate: Void Contract)
  6. Send Contract → (compensate: Send Cancellation Notice)
- **Implementazione**: Orchestration-based con Durable Functions
- **Compensation Logic**: In caso di fallimento, eseguire azioni compensative in ordine inverso

---

### 3.2 Processo: Adesione a Promozioni

Implementare un processo di adesione a una promozione commerciale:

#### Commands (Scrittura)
1. **Richiedere Adesione a Promozione**
   - Identificare il cliente
   - Identificare la promozione desiderata
   - Validare l'eleggibilità del cliente
   - Creare una richiesta di adesione

2. **Elaborare Transazione**
   - Calcolare eventuali costi
   - Processare il pagamento (se necessario)
   - Confermare la transazione

3. **Attivare Promozione**
   - Applicare la promozione al profilo del cliente
   - Aggiornare i sistemi di billing (simulato)
   - Confermare l'attivazione

4. **Notificare Cliente**
   - Inviare email di conferma attivazione
   - Inviare SMS di conferma (simulato)

#### Queries (Lettura)
- Ottenere lista promozioni disponibili
- Ottenere promozioni attive per un cliente
- Ottenere storico adesioni di un cliente
- Verificare eleggibilità cliente per una promozione

#### Domain Events
- `PromotionSubscriptionRequested`
- `PaymentProcessed`
- `PromotionActivated`
- `CustomerNotified`

#### Saga Pattern per Gestione Transazioni Distribuite
- **Saga Name**: PromotionSubscriptionSaga
- **Steps**:
  1. Validate Eligibility → (compensate: N/A)
  2. Process Payment → (compensate: Refund Payment)
  3. Activate Promotion → (compensate: Deactivate Promotion)
  4. Notify Customer → (compensate: Send Deactivation Notice)
- **Implementazione**: Orchestration-based con Durable Functions
- **Compensation Logic**: Gestire rollback automatico in caso di errore post-pagamento

---

## 4. Requisiti Tecnici

### 4.1 Architettura CQRS

- **Separazione Command/Query**:
  - Function separate per Commands (scrittura)
  - Function separate per Queries (lettura)
  - Modelli di lettura ottimizzati (eventualmente denormalizzati)
  - Modelli di scrittura basati su aggregati DDD

- **Event Sourcing** (opzionale ma consigliato):
  - Persistere gli eventi di dominio
  - Possibilità di ricostruire lo stato da eventi

### 4.2 Domain-Driven Design

- **Bounded Contexts**:
  - Context "SalesOrder" per gestione ordini SIM
  - Context "PromotionManagement" per gestione promozioni
  - Context condiviso per Customer (se necessario)

- **Aggregates**:
  - `SimCardOrder` Aggregate
  - `PromotionSubscription` Aggregate
  - Definire Aggregate Roots
  - Garantire consistenza transazionale all'interno dell'aggregato

- **Value Objects**:
  - `CustomerId`, `OrderId`, `PromotionId`
  - `EmailAddress`, `PhoneNumber`
  - `DocumentReference`

- **Domain Events**:
  - Eventi immutabili
  - Pubblicati su Azure Service Bus o Event Grid

### 4.3 Azure Functions

- **Trigger Types**:
  - HTTP Triggers per API REST (Commands e Queries)
  - Service Bus Triggers per elaborazione eventi
  - Timer Triggers per task schedulati (se necessario)
  - Blob Triggers per elaborazione documenti

- **Bindings**:
  - Output bindings per Service Bus (pubblicazione eventi)
  - Input/Output bindings per storage
  - Cosmos DB bindings (se utilizzato)

- **Durable Functions** (consigliato):
  - Per orchestrazione di processi lunghi
  - Per implementazione del pattern Saga
  - Per gestione compensazioni in caso di fallimento
  - Stateful orchestrations con checkpointing automatico

### 4.4 Storage e Persistenza

- **Azure Blob Storage**:
  - Per documenti (carta d'identità, contratti PDF)
  - Container separati per tipo di documento
  - Gestione SAS tokens per accesso sicuro

- **Database**:
  - Azure Cosmos DB o Azure SQL Database
  - Repository pattern per astrazione
  - Separazione read/write stores (CQRS)

- **Azure Service Bus**:
  - Topics per pubblicazione eventi di dominio
  - Subscriptions per consumer di eventi
  - Dead letter queue per gestione errori

### 4.5 Struttura del Progetto

```
/project-root
├── /src
│   ├── /functions           # Azure Functions endpoints
│   │   ├── /commands        # HTTP Functions per Commands
│   │   ├── /queries         # HTTP Functions per Queries
│   │   ├── /eventHandlers   # Service Bus triggered functions
│   │   └── /sagas           # Durable Functions orchestrators (Saga implementations)
│   ├── /domain              # Domain logic (DDD)
│   │   ├── /salesOrder
│   │   │   ├── aggregates/
│   │   │   ├── events/
│   │   │   ├── commands/
│   │   │   └── valueObjects/
│   │   └── /promotionManagement
│   │       ├── aggregates/
│   │       ├── events/
│   │       ├── commands/
│   │       └── valueObjects/
│   ├── /application         # Application services
│   │   ├── /commandHandlers
│   │   └── /queryHandlers
│   ├── /infrastructure      # Infrastructure layer
│   │   ├── /repositories
│   │   ├── /messaging
│   │   └── /storage
│   └── /shared              # Shared utilities
├── /tests                   # Unit e Integration tests
├── /docs                    # Documentazione
├── /infrastructure          # IaC (Bicep/ARM templates)
├── host.json
├── local.settings.json
├── package.json
└── tsconfig.json
```

### 4.6 Qualità del Codice

- **Testing**:
  - Unit tests per domain logic (Jest o Mocha)
  - Integration tests per Azure Functions
  - Mock per servizi esterni
  - Code coverage > 70%

- **Error Handling**:
  - Gestione eccezioni centralizzata
  - Logging strutturato (Application Insights)
  - Retry policies per operazioni transient

- **Security**:
  - Validazione input
  - Managed Identity per accesso a risorse Azure
  - HTTPS only
  - CORS configuration
  - Secret management con Azure Key Vault

### 4.7 Infrastructure as Code

- **Bicep o ARM Templates**:
  - Definire tutte le risorse Azure
  - Parametrizzazione per ambienti (dev, staging, prod)
  - Resource naming conventions

- **Risorse da Provisionare**:
  - Function App con piano Consumption
  - Storage Account
  - Service Bus Namespace
  - Database (Cosmos DB o SQL)
  - Application Insights
  - Key Vault (opzionale)

### 4.8 CI/CD

- **GitHub Actions o Azure DevOps**:
  - Build automatica
  - Esecuzione tests
  - Deploy automatico su Azure

---

## 5. Output Richiesti

### 5.1 Codice

- **Linguaggio**: Inglese per tutto il codice
  - Nomi di classi, metodi, variabili in inglese
  - Rispettare naming conventions TypeScript/JavaScript

- **Commenti**: Italiano
  - Commenti esplicativi in italiano
  - JSDoc in italiano per documentazione API

- **SDK e Librerie**:
  - Utilizzare esclusivamente SDK ufficiali Microsoft
  - `@azure/functions`
  - `durable-functions` per implementazione Saga pattern
  - `@azure/storage-blob`
  - `@azure/service-bus`
  - `@azure/cosmos` (se utilizzato)
  - `@azure/identity` per managed identity

### 5.2 Setup Progetto

- **CLI Microsoft**:
  - Utilizzare Azure Functions Core Tools per scaffolding
  - Utilizzare Azure CLI per deployment
  - Seguire la documentazione ufficiale Microsoft

- **Comandi di Setup** (da documentare):
  ```bash
  # Esempio
  npm install -g azure-functions-core-tools@4
  func init --typescript
  func new --template "HTTP trigger" --name "CreateSimCardOrder"
  ```

### 5.3 Documentazione

Generare documentazione dettagliata in Markdown che includa:

1. **README.md principale**:
   - Descrizione del progetto
   - Architettura generale (con diagrammi)
   - Prerequisiti
   - Istruzioni di setup locale
   - Istruzioni di deployment
   - Struttura del progetto

2. **ARCHITECTURE.md**:
   - Diagramma architetturale
   - Spiegazione pattern CQRS
   - Spiegazione pattern DDD applicati
   - Bounded Contexts
   - Flussi di dati

3. **API.md**:
   - Documentazione API REST
   - Endpoints disponibili
   - Request/Response examples
   - Esempi di chiamate con curl/Postman

4. **DOMAIN.md**:
   - Descrizione del domain model
   - Aggregates e loro responsabilità
   - Domain Events
   - Business rules
   - Saga implementations e flussi di compensazione

5. **DEPLOYMENT.md**:
   - Guida al deployment su Azure
   - Configurazione risorse
   - Variabili d'ambiente
   - Troubleshooting

6. **TESTING.md**:
   - Strategia di testing
   - Come eseguire i tests
   - Come scrivere nuovi tests

### 5.4 File di Configurazione

- `package.json` con dependencies
- `tsconfig.json` con configurazione TypeScript ottimale
- `host.json` per configurazione Azure Functions
- `local.settings.json.example` (template)
- `.funcignore`
- `.gitignore`
- `jest.config.js` o `mocha.config.js`

---

## 6. Best Practices da Seguire

1. **Principi SOLID** nel codice domain
2. **Dependency Injection** per gestione dipendenze
3. **Repository Pattern** per astrazione persistenza
4. **Command Pattern** per incapsulare operazioni
5. **Event-Driven Architecture** per disaccoppiamento
5. **Saga Pattern** per transazioni distribuite con compensazione
6. **Idempotency** per operazioni critiche
7. **Logging strutturato** con correlation IDs e saga instance tracking
8. **Graceful degradation** in caso di errori
9. **Compensation over Prevention** per Saga failures
10. **Configuration over Convention** dove appropriato
11. **Documentation as Code** (commenti e README aggiornati)
12. **Saga timeout handling** con retry policies appropriate

---

## 7. Deliverables Finali

- [ ] Codice sorgente completo del progetto
- [ ] Infrastructure as Code (Bicep files)
- [ ] Suite di tests (unit e integration)
- [ ] Documentazione completa in markdown
- [ ] File di configurazione per CI/CD
- [ ] Scripts per setup e deployment
- [ ] Esempi di chiamate API (Postman collection o file .http)

---

## Note Aggiuntive

- Il progetto deve essere **production-ready** o molto vicino
- Seguire le **Azure Well-Architected Framework** guidelines
- Implementare **monitoring e observability** con Application Insights
- Considerare **scalabilità** e **resilienza**
- Documentare eventuali **limitazioni** o **assunzioni**
