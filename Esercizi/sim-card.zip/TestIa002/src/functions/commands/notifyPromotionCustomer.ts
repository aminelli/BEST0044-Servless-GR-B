import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { notifyCustomer } from "../../application/commandHandlers/promotionLifecycleCommandHandler";
import { mapNotifyPromotionCustomerCommand, mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest, readJsonBody } from "../../shared/http";

app.http("NotifyPromotionCustomer", {
  methods: ["POST"],
  authLevel: "function",
  route: "promotions/subscriptions/{subscriptionId}/notify",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeSubscriptionId = mapRouteParam(request, "subscriptionId");
      if (!routeSubscriptionId.ok) {
        return badRequest(routeSubscriptionId.error);
      }

      const body = await readJsonBody<{ channels?: Array<"email" | "sms"> }>(request);
      const result = await notifyCustomer(
        mapNotifyPromotionCustomerCommand(routeSubscriptionId.value, body)
      );

      return accepted(result);
    } catch (error) {
      context.error("NotifyPromotionCustomer failed", error);
      return badRequest("Invalid customer notify payload.");
    }
  }
});
