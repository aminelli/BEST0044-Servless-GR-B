import { getApplicationDependencies } from "../dependencies";

export async function getSimCardOrderStatus(orderId: string) {
  return getApplicationDependencies().simCardOrderRepository.getById(orderId);
}

export async function getSimCardOrdersByCustomer(customerId: string) {
  return getApplicationDependencies().simCardOrderRepository.getByCustomer(customerId);
}

export async function getSimCardOrderHistory(orderId: string) {
  return getApplicationDependencies().simCardOrderRepository.getTransitions(orderId);
}

export async function getSimCardOrderDocuments(orderId: string) {
  return getApplicationDependencies().simCardOrderRepository.getDocuments(orderId);
}
