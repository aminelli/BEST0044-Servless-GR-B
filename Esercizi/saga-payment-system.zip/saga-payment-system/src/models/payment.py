"""
Modello per rappresentare un pagamento digitale.
"""
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Optional
from datetime import datetime


class PaymentStatus(Enum):
    """Stati possibili di un pagamento."""
    PENDING = "PENDING"
    VALIDATED = "VALIDATED"
    FUNDS_VERIFIED = "FUNDS_VERIFIED"
    PROCESSED = "PROCESSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    ROLLED_BACK = "ROLLED_BACK"


@dataclass
class Payment:
    """
    Rappresenta un pagamento digitale nel sistema.
    
    Attributes:
        payment_id: Identificativo univoco del pagamento
        customer_id: ID del cliente che effettua il pagamento
        amount: Importo del pagamento
        currency: Valuta (default: EUR)
        card_number: Ultime 4 cifre della carta (mascherato)
        account_id: ID del conto/carta da addebitare
        merchant_id: ID del merchant che riceve il pagamento
        status: Stato corrente del pagamento
        created_at: Timestamp di creazione
        updated_at: Timestamp ultimo aggiornamento
        error_message: Messaggio di errore in caso di fallimento
    """
    payment_id: str
    customer_id: str
    amount: Decimal
    currency: str = "EUR"
    card_number: str = ""
    account_id: str = ""
    merchant_id: str = ""
    status: PaymentStatus = PaymentStatus.PENDING
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    error_message: Optional[str] = None
    idempotency_key: Optional[str] = None
    
    def __post_init__(self):
        """Inizializza i timestamp se non forniti."""
        if self.created_at is None:
            self.created_at = datetime.utcnow()
        if self.updated_at is None:
            self.updated_at = datetime.utcnow()
    
    def to_dict(self) -> dict:
        """
        Converte il pagamento in un dizionario per DynamoDB.
        
        Returns:
            Dizionario con i dati del pagamento
        """
        return {
            "payment_id": self.payment_id,
            "customer_id": self.customer_id,
            "amount": str(self.amount),
            "currency": self.currency,
            "card_number": self.card_number,
            "account_id": self.account_id,
            "merchant_id": self.merchant_id,
            "status": self.status.value,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "error_message": self.error_message,
            "idempotency_key": self.idempotency_key,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Payment':
        """
        Crea un oggetto Payment da un dizionario.
        
        Args:
            data: Dizionario con i dati del pagamento
            
        Returns:
            Istanza di Payment
        """
        return cls(
            payment_id=data["payment_id"],
            customer_id=data["customer_id"],
            amount=Decimal(data["amount"]),
            currency=data.get("currency", "EUR"),
            card_number=data.get("card_number", ""),
            account_id=data.get("account_id", ""),
            merchant_id=data.get("merchant_id", ""),
            status=PaymentStatus(data.get("status", "PENDING")),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            error_message=data.get("error_message"),
            idempotency_key=data.get("idempotency_key"),
        )
