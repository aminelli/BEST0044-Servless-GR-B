import { HttpRequest } from "@azure/functions";
import { PaymentStatus } from "../../domain/payments/aggregates/paymentTransactionAggregate";

function isValidStatus(value?: string): value is PaymentStatus {
  return value === "Requested" || value === "Processed" || value === "Refunded" || value === "Failed";
}

function isValidUtc(value?: string): boolean {
  if (!value) {
    return true;
  }

  return !Number.isNaN(Date.parse(value));
}

export function mapRouteParam(
  request: HttpRequest,
  paramName: string
): { ok: true; value: string } | { ok: false; error: string } {
  const value = request.params[paramName];
  if (!value) {
    return {
      ok: false,
      error: `${paramName} is required.`
    };
  }

  return {
    ok: true,
    value
  };
}

export function mapItemsResponse<T>(items: T[]) {
  return { items };
}

export function mapNotFoundResponse(entity: string) {
  return {
    status: 404,
    jsonBody: {
      error: `${entity} not found.`
    }
  };
}

export function mapPaymentQueryFilter(request: HttpRequest):
  | {
      ok: true;
      value: {
        status?: PaymentStatus;
        fromUtc?: string;
        toUtc?: string;
      };
    }
  | { ok: false; error: string } {
  const rawStatus = request.query.get("status") ?? undefined;
  const fromUtc = request.query.get("fromUtc") ?? undefined;
  const toUtc = request.query.get("toUtc") ?? undefined;

  if (rawStatus && !isValidStatus(rawStatus)) {
    return {
      ok: false,
      error: "status must be one of Requested, Processed, Refunded, Failed."
    };
  }

  if (!isValidUtc(fromUtc) || !isValidUtc(toUtc)) {
    return {
      ok: false,
      error: "fromUtc/toUtc must be valid UTC ISO timestamps."
    };
  }

  const status: PaymentStatus | undefined = isValidStatus(rawStatus) ? rawStatus : undefined;

  return {
    ok: true,
    value: {
      status,
      fromUtc,
      toUtc
    }
  };
}
