import { ApplicationOutboundPorts } from "../../application/ports/outboundPorts";
import { publishDomainEvent } from "../messaging/domainEventPublisher";
import { paymentTransactionRepository } from "../repositories/paymentTransactionRepository";
import { promotionSubscriptionRepository } from "../repositories/promotionSubscriptionRepository";
import { simCardOrderRepository } from "../repositories/simCardOrderRepository";
import { uploadTextDocument } from "../storage/documentStorage";

export const outboundAdapters: ApplicationOutboundPorts = {
  simCardOrderRepository,
  promotionSubscriptionRepository,
  paymentTransactionRepository,
  domainEventPublisher: {
    publishDomainEvent
  },
  documentStorage: {
    uploadTextDocument
  }
};
