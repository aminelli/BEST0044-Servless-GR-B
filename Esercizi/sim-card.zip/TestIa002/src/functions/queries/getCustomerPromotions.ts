import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getPromotionsByCustomer } from "../../application/queryHandlers/promotionQueryHandler";
import { mapItemsResponse, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetCustomerPromotions", {
  methods: ["GET"],
  authLevel: "function",
  route: "customers/{customerId}/promotions",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeCustomerId = mapRouteParam(request, "customerId");
    if (!routeCustomerId.ok) {
      return badRequest(routeCustomerId.error);
    }

    const customerId = routeCustomerId.value;

    const promotions = await getPromotionsByCustomer(customerId);
    return ok(mapItemsResponse(promotions));
  }
});
