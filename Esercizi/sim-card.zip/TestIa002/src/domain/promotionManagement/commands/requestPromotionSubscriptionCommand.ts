import { z } from "zod";

export const RequestPromotionSubscriptionCommandSchema = z.object({
  customerId: z.string().min(1),
  promotionId: z.string().min(1)
});

export type RequestPromotionSubscriptionCommand = z.infer<
  typeof RequestPromotionSubscriptionCommandSchema
>;
