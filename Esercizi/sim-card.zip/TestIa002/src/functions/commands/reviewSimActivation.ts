import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { reviewActivation } from "../../application/commandHandlers/simCardOrderLifecycleCommandHandler";
import { mapReviewActivationCommand, mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest, readJsonBody } from "../../shared/http";

app.http("ReviewSimActivation", {
  methods: ["POST"],
  authLevel: "function",
  route: "orders/{orderId}/activation/review",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeOrderId = mapRouteParam(request, "orderId");
      if (!routeOrderId.ok) {
        return badRequest(routeOrderId.error);
      }

      const body = await readJsonBody<{ approved: boolean; reason?: string }>(request);
      const result = await reviewActivation(mapReviewActivationCommand(routeOrderId.value, body));

      return accepted(result);
    } catch (error) {
      context.error("ReviewSimActivation failed", error);
      return badRequest("Invalid activation review payload.");
    }
  }
});
