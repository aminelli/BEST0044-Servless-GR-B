import * as df from "durable-functions";

// Orchestrazione base della saga ordine SIM con compensazioni.
df.app.orchestration("SimCardOrderSaga", function* (context) {
  const input = context.df.getInput() as { orderId: string };
  const completedSteps: string[] = [];

  try {
    yield context.df.callActivity("SimOrderStepUploadDocuments", input);
    completedSteps.push("UploadDocuments");

    yield context.df.callActivity("SimOrderStepProcessPayment", input);
    completedSteps.push("ProcessPayment");

    yield context.df.callActivity("SimOrderStepRequestActivation", input);
    completedSteps.push("RequestActivation");

    yield context.df.callActivity("SimOrderStepGenerateContract", input);
    completedSteps.push("GenerateContract");

    yield context.df.callActivity("SimOrderStepSendContract", input);
    completedSteps.push("SendContract");

    return { ok: true, orderId: input.orderId };
  } catch (error) {
    for (const step of completedSteps.reverse()) {
      yield context.df.callActivity("SimOrderCompensation", {
        orderId: input.orderId,
        step
      });
    }

    return { ok: false, error: `${error}` };
  }
});
