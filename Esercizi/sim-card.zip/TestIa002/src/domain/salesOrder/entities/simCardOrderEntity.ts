import {
  OrderDocumentReference,
  SimCardOrder,
  SimCardOrderStatus
} from "../aggregates/simCardOrderAggregate";

export class SimCardOrderEntity {
  private constructor(private readonly state: SimCardOrder) {}

  static createNew(params: {
    id: string;
    customerId: string;
    nowUtc: string;
  }): SimCardOrderEntity {
    return new SimCardOrderEntity({
      id: params.id,
      customerId: params.customerId,
      status: "Created",
      documents: [],
      transitions: [
        {
          from: null,
          to: "Created",
          changedAtUtc: params.nowUtc,
          reason: "Order created"
        }
      ],
      createdAt: params.nowUtc,
      updatedAt: params.nowUtc
    });
  }

  static rehydrate(raw: SimCardOrder): SimCardOrderEntity {
    return new SimCardOrderEntity({ ...raw });
  }

  get id(): string {
    return this.state.id;
  }

  get status(): SimCardOrderStatus {
    return this.state.status;
  }

  addDocuments(refs: OrderDocumentReference[]): void {
    this.state.documents.push(...refs);
  }

  removeDocumentsByTypes(types: Array<OrderDocumentReference["type"]>): void {
    this.state.documents = this.state.documents.filter((x) => !types.includes(x.type));
  }

  transition(to: SimCardOrderStatus, reason: string, nowUtc: string): void {
    const from = this.state.status;
    this.state.status = to;
    this.state.updatedAt = nowUtc;
    this.state.transitions.push({
      from,
      to,
      changedAtUtc: nowUtc,
      reason
    });
  }

  toPrimitives(): SimCardOrder {
    return {
      ...this.state,
      documents: [...this.state.documents],
      transitions: [...this.state.transitions]
    };
  }
}
