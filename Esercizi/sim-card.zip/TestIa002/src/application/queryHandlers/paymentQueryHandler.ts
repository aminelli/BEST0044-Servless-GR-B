import { PaymentStatus, PaymentTransaction } from "../../domain/payments/aggregates/paymentTransactionAggregate";
import { getApplicationDependencies } from "../dependencies";

export interface PaymentQueryFilter {
  status?: PaymentStatus;
  fromUtc?: string;
  toUtc?: string;
}

function applyFilters(items: PaymentTransaction[], filter?: PaymentQueryFilter): PaymentTransaction[] {
  if (!filter) {
    return items;
  }

  return items.filter((item) => {
    if (filter.status && item.status !== filter.status) {
      return false;
    }

    if (filter.fromUtc && item.updatedAt < filter.fromUtc) {
      return false;
    }

    if (filter.toUtc && item.updatedAt > filter.toUtc) {
      return false;
    }

    return true;
  });
}

export async function getPaymentsByOrder(orderId: string, filter?: PaymentQueryFilter) {
  const items = await getApplicationDependencies().paymentTransactionRepository.getByAggregate(
    "SimOrder",
    orderId
  );
  return applyFilters(items, filter);
}

export async function getPaymentsByPromotionSubscription(
  subscriptionId: string,
  filter?: PaymentQueryFilter
) {
  const items = await getApplicationDependencies().paymentTransactionRepository.getByAggregate(
    "PromotionSubscription",
    subscriptionId
  );
  return applyFilters(items, filter);
}
