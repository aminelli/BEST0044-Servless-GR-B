import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import * as df from "durable-functions";
import { mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest } from "../../shared/http";

app.http("StartSimCardOrderSaga", {
  methods: ["POST"],
  authLevel: "function",
  route: "orders/{orderId}/saga/start",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    const routeOrderId = mapRouteParam(request, "orderId");
    if (!routeOrderId.ok) {
      return badRequest(routeOrderId.error);
    }

    const orderId = routeOrderId.value;

    const client = df.getClient(context);
    const instanceId = await client.startNew("SimCardOrderSaga", {
      input: { orderId }
    });

    return accepted({ instanceId, orderId });
  }
});
