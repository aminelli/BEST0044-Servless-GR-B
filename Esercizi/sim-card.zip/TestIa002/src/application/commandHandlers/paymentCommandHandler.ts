import { PaymentTransactionEntity } from "../../domain/payments/entities/paymentTransactionEntity";
import { PaymentEvent } from "../../domain/payments/events/paymentEvents";
import { PaymentId } from "../../domain/payments/valueObjects/paymentId";
import { getApplicationDependencies } from "../dependencies";
import { createEventMetadata, toUtcIsoTimestamp } from "../../shared/eventMetadata";
import { newId } from "../../shared/ids";

async function publish(paymentId: string, type: PaymentEvent["type"], payload: Record<string, unknown>) {
  const deps = getApplicationDependencies();
  const event: PaymentEvent = {
    ...createEventMetadata(paymentId),
    paymentId,
    type,
    occurredAtUtc: toUtcIsoTimestamp(),
    payload
  };

  await deps.domainEventPublisher.publishDomainEvent(event);
}

export async function requestAndProcessPayment(input: {
  aggregateType: "SimOrder" | "PromotionSubscription";
  aggregateId: string;
  customerId: string;
  amount: number;
}): Promise<{ paymentId: string; status: string }> {
  const deps = getApplicationDependencies();
  const paymentId = PaymentId.create(newId("pay"));
  const now = toUtcIsoTimestamp();

  const payment = PaymentTransactionEntity.createNew({
    id: paymentId.value,
    aggregateType: input.aggregateType,
    aggregateId: input.aggregateId,
    customerId: input.customerId,
    amount: input.amount,
    currency: "EUR",
    nowUtc: now
  });

  await deps.paymentTransactionRepository.upsert(payment.toPrimitives());
  await publish(paymentId.value, "PaymentRequested", {
    aggregateType: input.aggregateType,
    aggregateId: input.aggregateId,
    amount: input.amount,
    currency: "EUR"
  });

  payment.transition("Processed", toUtcIsoTimestamp());
  await deps.paymentTransactionRepository.upsert(payment.toPrimitives());
  await publish(paymentId.value, "PaymentProcessed", {
    aggregateType: input.aggregateType,
    aggregateId: input.aggregateId,
    amount: input.amount,
    currency: "EUR"
  });

  return {
    paymentId: paymentId.value,
    status: payment.status
  };
}

export async function refundLatestPayment(input: {
  aggregateType: "SimOrder" | "PromotionSubscription";
  aggregateId: string;
}): Promise<{ refunded: boolean; paymentId?: string }> {
  const deps = getApplicationDependencies();
  const candidates = await deps.paymentTransactionRepository.getByAggregate(
    input.aggregateType,
    input.aggregateId
  );

  const latestProcessed = candidates
    .filter((x) => x.status === "Processed")
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];

  if (!latestProcessed) {
    return { refunded: false };
  }

  const payment = PaymentTransactionEntity.rehydrate(latestProcessed);
  payment.transition("Refunded", toUtcIsoTimestamp());
  await deps.paymentTransactionRepository.upsert(payment.toPrimitives());

  await publish(payment.id, "PaymentRefunded", {
    aggregateType: input.aggregateType,
    aggregateId: input.aggregateId,
    amount: latestProcessed.amount,
    currency: latestProcessed.currency
  });

  return { refunded: true, paymentId: payment.id };
}
