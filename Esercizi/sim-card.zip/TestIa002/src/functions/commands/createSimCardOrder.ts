import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { createSimCardOrder } from "../../application/commandHandlers/simCardOrderCommandHandler";
import { mapCreateSimCardOrderResponse } from "../mappers/commandHttpMapper";
import { badRequest, accepted, readJsonBody } from "../../shared/http";

export async function createSimCardOrderHttp(
  request: HttpRequest,
  context: InvocationContext
): Promise<HttpResponseInit> {
  try {
    const body = await readJsonBody<unknown>(request);
    const order = await createSimCardOrder(body);
    return accepted(mapCreateSimCardOrderResponse(order));
  } catch (error) {
    context.error("CreateSimCardOrder failed", error);
    return badRequest("Invalid order payload.");
  }
}

app.http("CreateSimCardOrder", {
  methods: ["POST"],
  authLevel: "function",
  route: "orders",
  handler: createSimCardOrderHttp
});
