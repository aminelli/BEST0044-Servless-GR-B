import { EventMetadata, UtcIsoTimestamp } from "../../../shared/eventEnvelope";

export type SalesOrderEventType =
  | "SimCardOrderCreated"
  | "CustomerDocumentsUploaded"
  | "PaymentProcessed"
  | "ActivationRequested"
  | "ActivationApproved"
  | "ActivationRejected"
  | "ContractGenerated"
  | "ContractSentToCustomer";

export interface SalesOrderEvent extends EventMetadata {
  orderId: string;
  type: SalesOrderEventType;
  occurredAtUtc: UtcIsoTimestamp;
  payload: Record<string, unknown>;
}
