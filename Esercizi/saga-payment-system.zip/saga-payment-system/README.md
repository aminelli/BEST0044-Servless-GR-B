# Saga Payment System

Sistema di gestione pagamenti digitali che implementa il **pattern Saga** utilizzando AWS serverless services (Lambda Functions e Step Functions) per gestire transazioni distribuite con compensating transactions.

## 📋 Indice

- [Overview](#overview)
- [Architettura](#architettura)
- [Features](#features)
- [Prerequisiti](#prerequisiti)
- [Installazione](#installazione)
- [Deploy](#deploy)
- [Utilizzo](#utilizzo)
- [Testing](#testing)
- [Struttura del Progetto](#struttura-del-progetto)
- [Documentazione Aggiuntiva](#documentazione-aggiuntiva)

## 🎯 Overview

Questo progetto dimostra l'implementazione del pattern Saga in un contesto serverless AWS per gestire pagamenti digitali. Il pattern Saga è essenziale per mantenere la consistenza dei dati in architetture distribuite, dove le transazioni ACID tradizionali non sono applicabili.

### Cos'è il Pattern Saga?

Il pattern Saga divide una transazione distribuita in una serie di transazioni locali. Ogni transazione locale aggiorna un singolo servizio e pubblica un evento o messaggio per triggerare la prossima transazione. Se una transazione fallisce, vengono eseguite **compensating transactions** per annullare le modifiche delle transazioni precedenti.

### Scenario Implementato

Sistema di pagamento digitale con i seguenti step:

1. **Validazione Pagamento** - Verifica dei dati del pagamento
2. **Verifica Fondi** - Controllo disponibilità e prenotazione fondi
3. **Processamento Pagamento** - Addebito effettivo
4. **Notifica Cliente** - Invio conferma al cliente
5. **Registrazione Transazione** - Audit log permanente

In caso di fallimento in qualsiasi step, vengono eseguite le compensating transactions per rollback.

## 🏗️ Architettura

### Componenti Principali

- **AWS Step Functions**: Orchestrazione della Saga
- **AWS Lambda**: Esecuzione della business logic
- **Amazon DynamoDB**: Persistenza dei dati
- **Amazon API Gateway**: Endpoint HTTP per iniziare i pagamenti
- **Amazon CloudWatch**: Logging e monitoring

### Diagramma Architetturale

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │
       ▼
┌─────────────────────┐
│   API Gateway       │
└──────┬──────────────┘
       │
       ▼
┌─────────────────────┐        ┌──────────────────┐
│ InitiatePayment     │───────▶│   DynamoDB       │
│   Lambda            │        │ - Payments       │
└──────┬──────────────┘        │ - SagaStates     │
       │                       └──────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────┐
│         AWS Step Functions (Saga Orchestrator)   │
│                                                  │
│  ┌──────────────┐  ┌──────────────┐            │
│  │  Validate    │─▶│ Verify Funds │            │
│  │  Payment     │  └──────┬───────┘            │
│  └──────────────┘         │                     │
│                           ▼                     │
│  ┌──────────────┐  ┌──────────────┐            │
│  │   Notify     │◀─│   Process    │            │
│  │  Customer    │  │   Payment    │            │
│  └──────┬───────┘  └──────────────┘            │
│         │                                       │
│         ▼                                       │
│  ┌──────────────┐                              │
│  │   Record     │                              │
│  │ Transaction  │                              │
│  └──────────────┘                              │
│                                                  │
│  Compensating Transactions (on failure):        │
│  ┌─────────────────────────────┐               │
│  │ • Release Funds Hold        │               │
│  │ • Reverse Payment           │               │
│  └─────────────────────────────┘               │
└─────────────────────────────────────────────────┘
```

### Flusso della Saga

**Scenario di Successo:**
```
Validate → Verify Funds → Process Payment → Notify → Record → SUCCESS
```

**Scenario di Fallimento (es. fondi insufficienti):**
```
Validate → Verify Funds [FAIL] → Compensate (Release Hold) → ROLLED_BACK
```

**Scenario di Fallimento Avanzato (es. errore dopo processamento):**
```
Validate → Verify Funds → Process Payment → Notify [FAIL]
  → Compensate Process (Reverse Payment)
  → Compensate Funds (Release Hold)
  → ROLLED_BACK
```

## ✨ Features

- ✅ **Pattern Saga Orchestrato** con AWS Step Functions
- ✅ **Compensating Transactions** automatiche su fallimento
- ✅ **Idempotenza** per operazioni sicure in caso di retry
- ✅ **Retry Logic** configurabile per resilienza
- ✅ **Logging Strutturato** in formato JSON per CloudWatch
- ✅ **Monitoring** con CloudWatch Alarms
- ✅ **Type Hints** completi per type safety
- ✅ **Infrastructure as Code** con AWS SAM
- ✅ **Test Suite** con unit e integration tests

## 📋 Prerequisiti

### Software Richiesto

- **Python 3.9+**
- **AWS CLI** configurato con credenziali valide
- **AWS SAM CLI** ([Guida installazione](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/serverless-sam-cli-install.html))
- **Make** (opzionale, per automazione comandi)
- **Git** (opzionale)

### Account AWS

- Account AWS attivo
- Permessi IAM per:
  - Lambda
  - Step Functions
  - DynamoDB
  - API Gateway
  - CloudWatch
  - IAM (per creazione ruoli)
  - CloudFormation

### Verifica Installazione

```bash
# Verifica Python
python3 --version

# Verifica AWS CLI
aws --version

# Verifica SAM CLI
sam --version

# Verifica credenziali AWS
aws sts get-caller-identity
```

## 🚀 Installazione

### 1. Clone del Repository

```bash
git clone <repository-url>
cd saga-payment-system
```

### 2. Setup Ambiente Virtuale Python

**Linux/Mac:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Windows:**
```powershell
python -m venv venv
.\venv\Scripts\activate
```

### 3. Installazione Dipendenze

```bash
# Usando Make
make install-dev

# Oppure manualmente
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configurazione Variabili d'Ambiente

```bash
# Copia il template
cp .env.example .env

# Modifica .env con i tuoi valori
# Nota: le variabili di environment saranno gestite da SAM durante il deploy
```

## 📦 Deploy

### Deploy Guidato (Prima Volta)

```bash
# Usando Make
make deploy-guided

# Oppure con SAM direttamente
sam build --template infrastructure/template.yaml
sam deploy --guided
```

Durante il deploy guidato, fornisci:
- **Stack Name**: `saga-payment-system-dev`
- **AWS Region**: es. `eu-west-1`
- **Environment**: `dev`
- Conferma la creazione di IAM roles
- Salva la configurazione nel file `samconfig.toml`

### Deploy Successivi

```bash
# Usando Make
make deploy ENVIRONMENT=dev

# Oppure con SAM
sam build
sam deploy --parameter-overrides Environment=dev
```

### Verifica Deploy

```bash
# Mostra stack info
make describe-stack

# Oppure con AWS CLI
aws cloudformation describe-stacks --stack-name saga-payment-system-dev
```

Gli Outputs mostreranno:
- API Endpoint
- ARN State Machine
- Nomi tabelle DynamoDB

## 💻 Utilizzo

### Iniziare un Pagamento via API

```bash
# Recupera l'endpoint API dagli outputs dello stack
API_ENDPOINT=$(aws cloudformation describe-stacks \
  --stack-name saga-payment-system-dev \
  --query 'Stacks[0].Outputs[?OutputKey==`ApiEndpoint`].OutputValue' \
  --output text)

# Invia una richiesta di pagamento
curl -X POST $API_ENDPOINT \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": "cust-12345",
    "amount": "99.99",
    "currency": "EUR",
    "account_id": "acc-67890",
    "merchant_id": "merch-abc",
    "idempotency_key": "unique-key-123"
  }'
```

**Risposta di Successo:**
```json
{
  "payment_id": "uuid-generated",
  "execution_arn": "arn:aws:states:...",
  "status": "PROCESSING"
}
```

### Monitorare l'Esecuzione

```bash
# Lista esecuzioni
make list-executions

# Visualizza logs
make logs

# Oppure nella AWS Console
# Step Functions → Esecuzioni → Seleziona esecuzione → Visualizza dettagli
```

### Query DynamoDB

```bash
# Recupera stato pagamento
aws dynamodb get-item \
  --table-name SagaPayments-dev \
  --key '{"payment_id": {"S": "your-payment-id"}}'

# Recupera stato Saga
aws dynamodb get-item \
  --table-name SagaStates-dev \
  --key '{"saga_id": {"S": "your-saga-id"}}'
```

## 🧪 Testing

### Unit Tests

```bash
# Esegui tutti i test
make test

# Con coverage
make test-coverage
```

### Integration Tests

Gli integration tests richiedono che lo stack sia deployato su AWS.

```bash
# Configura variabili d'ambiente
export STATE_MACHINE_ARN=$(aws cloudformation describe-stacks \
  --stack-name saga-payment-system-dev \
  --query 'Stacks[0].Outputs[?OutputKey==`StateMachineArn`].OutputValue' \
  --output text)

export SAGA_STATE_TABLE=SagaStates-dev
export PAYMENTS_TABLE=SagaPayments-dev

# Esegui integration tests
python tests/test_saga_integration.py
```

### Test Scenari

**Pagamento con successo:**
```bash
# account_id normale = saldo sufficiente
curl -X POST $API_ENDPOINT -H "Content-Type: application/json" \
  -d '{"customer_id":"cust-1","amount":"50.00","account_id":"acc-normal","merchant_id":"merch-1"}'
```

**Fondi insufficienti (trigger rollback):**
```bash
# account_id che inizia con "LOW_" = saldo basso
curl -X POST $API_ENDPOINT -H "Content-Type: application/json" \
  -d '{"customer_id":"cust-2","amount":"1000.00","account_id":"LOW_acc-1","merchant_id":"merch-1"}'
```

**Errore processamento (trigger rollback complesso):**
```bash
# merchant_id che inizia con "FAIL_" = errore processamento
curl -X POST $API_ENDPOINT -H "Content-Type: application/json" \
  -d '{"customer_id":"cust-3","amount":"50.00","account_id":"acc-normal","merchant_id":"FAIL_merch-1"}'
```

## 📁 Struttura del Progetto

```
saga-payment-system/
├── src/
│   ├── lambdas/                    # Lambda functions
│   │   ├── validate_payment.py
│   │   ├── verify_funds.py
│   │   ├── process_payment.py
│   │   ├── notify_customer.py
│   │   ├── record_transaction.py
│   │   ├── compensate_verify_funds.py
│   │   └── compensate_process_payment.py
│   ├── shared/                     # Codice condiviso
│   │   ├── __init__.py
│   │   ├── dynamodb_client.py      # Client DynamoDB
│   │   ├── logger.py               # Logging strutturato
│   │   └── exceptions.py           # Eccezioni custom
│   └── models/                     # Modelli dati
│       ├── __init__.py
│       ├── payment.py              # Modello Payment
│       └── saga_state.py           # Modello SagaState
├── infrastructure/                 # Infrastructure as Code
│   ├── template.yaml               # AWS SAM template
│   └── statemachine.asl.json       # Step Functions definition
├── tests/                          # Test suite
│   ├── test_payment_model.py       # Unit tests
│   └── test_saga_integration.py    # Integration tests
├── docs/                           # Documentazione
│   ├── ARCHITECTURE.md             # Architettura dettagliata
│   └── DEPLOYMENT.md               # Guida deployment
├── requirements.txt                # Dipendenze Python
├── .env.example                    # Template variabili d'ambiente
├── Makefile                        # Automazione comandi
└── README.md                       # Questo file
```

## 📚 Documentazione Aggiuntiva

- **[ARCHITECTURE.md](docs/ARCHITECTURE.md)**: Descrizione dettagliata dell'architettura, pattern Saga, e design decisions
- **[DEPLOYMENT.md](docs/DEPLOYMENT.md)**: Guida completa al deployment con tutti i comandi CLI

## 🔧 Comandi Utili (Make)

```bash
make help              # Mostra tutti i comandi disponibili
make install          # Installa dipendenze
make test             # Esegue test
make lint             # Linting del codice
make format           # Formatta il codice
make build            # Build SAM
make deploy           # Deploy su AWS
make logs             # Visualizza logs
make clean            # Pulisce file temporanei
make delete           # Elimina stack AWS
```

## 💰 Stima Costi AWS

Con utilizzo moderato (< 1000 transazioni/mese):

- **Lambda**: < $0.20/mese (Free Tier copre 1M richieste)
- **Step Functions**: < $0.03/mese (Free Tier copre 4,000 transizioni)
- **DynamoDB**: < $2.50/mese (On-demand pricing)
- **API Gateway**: < $0.10/mese (Free Tier copre 1M chiamate)
- **CloudWatch**: < $0.50/mese (logging)

**Totale stimato: < $3.50/mese** per development

## 🤝 Contribuire

Contributi sono benvenuti! Per favore:

1. Fork del repository
2. Crea un branch per la feature (`git checkout -b feature/AmazingFeature`)
3. Commit delle modifiche (`git commit -m 'Add AmazingFeature'`)
4. Push al branch (`git push origin feature/AmazingFeature`)
5. Apri una Pull Request

## 📝 Licenza

Questo progetto è rilasciato come esempio educativo.

## 🙏 Ringraziamenti

- Pattern Saga basato sul paper "Sagas" di Hector Garcia-Molina e Kenneth Salem
- Architettura ispirata alle AWS Serverless Best Practices

## 📞 Supporto

Per domande o problemi:
- Apri un Issue su GitHub
- Consulta la [documentazione AWS Step Functions](https://docs.aws.amazon.com/step-functions/)
- Consulta la [documentazione AWS SAM](https://docs.aws.amazon.com/serverless-application-model/)

---

**Buon utilizzo del Saga Payment System! 🚀**
