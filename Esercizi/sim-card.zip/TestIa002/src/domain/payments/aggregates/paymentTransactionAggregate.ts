export type PaymentAggregateType = "SimOrder" | "PromotionSubscription";

export type PaymentStatus = "Requested" | "Processed" | "Refunded" | "Failed";

export interface PaymentTransaction {
  id: string;
  aggregateType: PaymentAggregateType;
  aggregateId: string;
  customerId: string;
  amount: number;
  currency: "EUR";
  status: PaymentStatus;
  createdAt: string;
  updatedAt: string;
}
