"""
Lambda per registrare la transazione completata.
Quinto e ultimo step della Saga.
"""
import json
import sys
from typing import Dict, Any
from datetime import datetime

# Aggiungi il path per importare i moduli condivisi
sys.path.insert(0, '/opt/python')

from shared import get_logger, DynamoDBClient
from models import PaymentStatus

logger = get_logger(__name__)
db_client = DynamoDBClient()


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler per registrare la transazione completata.
    
    Crea un record di audit log permanente della transazione.
    
    Args:
        event: Evento Step Functions con i dati del pagamento
        context: Contesto Lambda
        
    Returns:
        Evento aggiornato con recording_result
    """
    logger.add_context(
        function_name='record_transaction',
        request_id=context.request_id
    )
    
    logger.info("Starting transaction recording", event=event)
    
    try:
        payment_data = event.get('payment', {})
        payment_id = payment_data.get('payment_id')
        transaction_id = event.get('transaction_id')
        
        logger.add_context(
            payment_id=payment_id,
            transaction_id=transaction_id
        )
        
        # Crea il record della transazione
        transaction_record = {
            'transaction_id': transaction_id,
            'payment_id': payment_id,
            'customer_id': payment_data.get('customer_id'),
            'merchant_id': payment_data.get('merchant_id'),
            'amount': payment_data.get('amount'),
            'currency': payment_data.get('currency', 'EUR'),
            'status': 'COMPLETED',
            'completed_at': datetime.utcnow().isoformat(),
            'reservation_id': event.get('reservation_id'),
            'notification_id': event.get('notification_id'),
        }
        
        # Salva il record in DynamoDB
        # In produzione, potrebbe anche salvare in un data warehouse per analytics
        success = _save_transaction_record(transaction_record)
        
        if not success:
            raise Exception("Failed to save transaction record")
        
        # Aggiorna lo stato finale del pagamento
        db_client.update_payment_status(payment_id, PaymentStatus.COMPLETED.value)
        
        logger.info("Transaction recorded successfully", 
                   payment_id=payment_id,
                   transaction_id=transaction_id)
        
        # Aggiorna l'evento
        event['recording_result'] = 'SUCCESS'
        event['payment']['status'] = PaymentStatus.COMPLETED.value
        event['completed_at'] = datetime.utcnow().isoformat()
        
        return event
        
    except Exception as e:
        logger.error("Transaction recording failed", 
                    error=str(e),
                    payment_id=payment_data.get('payment_id'))
        
        # Questo è critico - il pagamento è stato processato ma non registrato
        # In produzione, dovrebbe triggare un alert per intervento manuale
        raise


def _save_transaction_record(transaction_record: Dict[str, Any]) -> bool:
    """
    Salva il record della transazione.
    
    In produzione:
    - Salverebbe in DynamoDB per query veloci
    - Potrebbe inviare a Kinesis/EventBridge per data warehouse
    - Potrebbe inviare a un servizio di audit logging
    
    Args:
        transaction_record: Dati della transazione da salvare
        
    Returns:
        True se salvato con successo, False altrimenti
    """
    try:
        # Qui salveremmo in una tabella DynamoDB dedicata alle transazioni
        # Per ora logghiamo semplicemente
        logger.info("Transaction record saved", 
                   transaction_id=transaction_record['transaction_id'],
                   payment_id=transaction_record['payment_id'])
        
        # In produzione:
        # transactions_table = dynamodb.Table('Transactions')
        # transactions_table.put_item(Item=transaction_record)
        
        return True
        
    except Exception as e:
        logger.error("Failed to save transaction record", 
                    error=str(e),
                    transaction_record=transaction_record)
        return False
