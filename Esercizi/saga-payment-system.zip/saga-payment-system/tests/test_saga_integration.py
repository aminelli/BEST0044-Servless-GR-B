"""
Integration test per la Saga completa.
"""
import json
import boto3
import time
from decimal import Decimal


def test_successful_payment_saga():
    """
    Test end-to-end di una Saga che completa con successo.
    """
    stepfunctions = boto3.client('stepfunctions')
    dynamodb = boto3.resource('dynamodb')
    
    # Prepara i dati del test
    payment_data = {
        "payment": {
            "payment_id": "test-success-001",
            "customer_id": "cust-001",
            "amount": "50.00",
            "currency": "EUR",
            "account_id": "acc-normal",  # Account con saldo sufficiente
            "merchant_id": "merch-001",
            "status": "PENDING"
        },
        "saga_id": "test-success-001"
    }
    
    # Recupera l'ARN della state machine dalle variabili d'ambiente
    import os
    state_machine_arn = os.environ.get('STATE_MACHINE_ARN')
    
    if not state_machine_arn:
        print("STATE_MACHINE_ARN non configurato, skipping test")
        return
    
    # Avvia l'esecuzione
    response = stepfunctions.start_execution(
        stateMachineArn=state_machine_arn,
        name=f'test-success-{int(time.time())}',
        input=json.dumps(payment_data)
    )
    
    execution_arn = response['executionArn']
    print(f"Execution started: {execution_arn}")
    
    # Attendi il completamento
    max_wait = 60  # secondi
    waited = 0
    
    while waited < max_wait:
        exec_response = stepfunctions.describe_execution(
            executionArn=execution_arn
        )
        
        status = exec_response['status']
        print(f"Status dopo {waited}s: {status}")
        
        if status in ['SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED']:
            break
        
        time.sleep(2)
        waited += 2
    
    # Verifica il risultato
    assert status == 'SUCCEEDED', f"Saga failed with status: {status}"
    
    # Verifica lo stato finale in DynamoDB
    saga_table = dynamodb.Table(os.environ.get('SAGA_STATE_TABLE'))
    saga_state = saga_table.get_item(Key={'saga_id': 'test-success-001'})
    
    assert 'Item' in saga_state
    assert saga_state['Item']['status'] == 'COMPLETED'
    
    print("✓ Test successful payment saga: PASSED")


def test_failed_payment_saga_insufficient_funds():
    """
    Test end-to-end di una Saga che fallisce per fondi insufficienti.
    Verifica che venga eseguito il rollback.
    """
    stepfunctions = boto3.client('stepfunctions')
    dynamodb = boto3.resource('dynamodb')
    
    payment_data = {
        "payment": {
            "payment_id": "test-fail-001",
            "customer_id": "cust-002",
            "amount": "1000.00",  # Importo alto
            "currency": "EUR",
            "account_id": "LOW_acc-001",  # Account con saldo basso
            "merchant_id": "merch-001",
            "status": "PENDING"
        },
        "saga_id": "test-fail-001"
    }
    
    import os
    state_machine_arn = os.environ.get('STATE_MACHINE_ARN')
    
    if not state_machine_arn:
        print("STATE_MACHINE_ARN non configurato, skipping test")
        return
    
    response = stepfunctions.start_execution(
        stateMachineArn=state_machine_arn,
        name=f'test-fail-{int(time.time())}',
        input=json.dumps(payment_data)
    )
    
    execution_arn = response['executionArn']
    print(f"Execution started: {execution_arn}")
    
    # Attendi il completamento
    max_wait = 60
    waited = 0
    
    while waited < max_wait:
        exec_response = stepfunctions.describe_execution(
            executionArn=execution_arn
        )
        
        status = exec_response['status']
        print(f"Status dopo {waited}s: {status}")
        
        if status in ['SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED']:
            break
        
        time.sleep(2)
        waited += 2
    
    # Verifica che la Saga sia fallita correttamente
    assert status == 'FAILED', f"Expected FAILED but got: {status}"
    
    # Verifica lo stato del rollback
    saga_table = dynamodb.Table(os.environ.get('SAGA_STATE_TABLE'))
    saga_state = saga_table.get_item(Key={'saga_id': 'test-fail-001'})
    
    assert 'Item' in saga_state
    assert saga_state['Item']['status'] in ['ROLLED_BACK', 'FAILED']
    
    print("✓ Test failed payment saga with rollback: PASSED")


if __name__ == '__main__':
    print("Running integration tests...")
    print()
    
    try:
        test_successful_payment_saga()
        print()
        test_failed_payment_saga_insufficient_funds()
        print()
        print("=" * 50)
        print("All integration tests PASSED!")
    except AssertionError as e:
        print(f"✗ Test FAILED: {e}")
    except Exception as e:
        print(f"✗ Test ERROR: {e}")
