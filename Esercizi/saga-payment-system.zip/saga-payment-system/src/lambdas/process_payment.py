"""
Lambda per processare il pagamento (addebito effettivo).
Terzo step della Saga.
"""
import json
import sys
from decimal import Decimal
from typing import Dict, Any
import uuid

# Aggiungi il path per importare i moduli condivisi
sys.path.insert(0, '/opt/python')

from shared import get_logger, DynamoDBClient, PaymentProcessingError
from models import PaymentStatus

logger = get_logger(__name__)
db_client = DynamoDBClient()


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler per processare il pagamento effettivo.
    
    Esegue l'addebito dal conto e l'accredito al merchant.
    
    Args:
        event: Evento Step Functions con i dati del pagamento
        context: Contesto Lambda
        
    Returns:
        Evento aggiornato con processing_result
        
    Raises:
        PaymentProcessingError: Se il processamento fallisce
    """
    logger.add_context(
        function_name='process_payment',
        request_id=context.request_id
    )
    
    logger.info("Starting payment processing", event=event)
    
    try:
        payment_data = event.get('payment', {})
        payment_id = payment_data.get('payment_id')
        amount = Decimal(str(payment_data.get('amount', 0)))
        account_id = payment_data.get('account_id')
        merchant_id = payment_data.get('merchant_id')
        reservation_id = event.get('reservation_id')
        
        logger.add_context(
            payment_id=payment_id,
            amount=str(amount),
            merchant_id=merchant_id
        )
        
        # Simula il processamento del pagamento
        # In produzione, questo interagirebbe con un payment processor reale
        transaction_id = _simulate_payment_processing(
            account_id=account_id,
            merchant_id=merchant_id,
            amount=amount,
            reservation_id=reservation_id
        )
        
        # Aggiorna lo stato del pagamento
        db_client.update_payment_status(payment_id, PaymentStatus.PROCESSED.value)
        
        logger.info("Payment processing successful", 
                   payment_id=payment_id,
                   transaction_id=transaction_id)
        
        # Aggiorna l'evento
        event['processing_result'] = 'SUCCESS'
        event['payment']['status'] = PaymentStatus.PROCESSED.value
        event['transaction_id'] = transaction_id  # Per rollback e notifica
        
        return event
        
    except PaymentProcessingError as e:
        logger.error("Payment processing failed", 
                    error=str(e),
                    payment_id=payment_data.get('payment_id'))
        
        # Aggiorna lo stato del pagamento
        if payment_data.get('payment_id'):
            db_client.update_payment_status(
                payment_data['payment_id'], 
                PaymentStatus.FAILED.value,
                str(e)
            )
        
        raise
    
    except Exception as e:
        logger.error("Unexpected error during payment processing", 
                    error=str(e),
                    error_type=type(e).__name__)
        raise


def _simulate_payment_processing(
    account_id: str,
    merchant_id: str,
    amount: Decimal,
    reservation_id: str
) -> str:
    """
    Simula il processamento del pagamento.
    
    In produzione:
    1. Convertirebbe il hold in addebito effettivo
    2. Trasferirebbe i fondi al merchant
    3. Registrerebbe la transazione nel sistema bancario
    
    Args:
        account_id: ID del conto da addebitare
        merchant_id: ID del merchant beneficiario
        amount: Importo da trasferire
        reservation_id: ID della prenotazione fondi
        
    Returns:
        ID della transazione completata
        
    Raises:
        PaymentProcessingError: Se il processamento fallisce
    """
    # Simula possibili errori di processamento
    # Per testing: merchant che iniziano con "FAIL_" causano errore
    if merchant_id.startswith("FAIL_"):
        raise PaymentProcessingError(
            f"Payment processing failed for merchant {merchant_id}"
        )
    
    # Genera un transaction ID univoco
    transaction_id = f"TXN_{uuid.uuid4().hex[:16].upper()}"
    
    logger.info("Payment transaction completed", 
               account_id=account_id,
               merchant_id=merchant_id,
               amount=str(amount),
               transaction_id=transaction_id,
               reservation_id=reservation_id)
    
    # In produzione, qui salveremmo i dettagli della transazione
    # in un database transazionale
    
    return transaction_id
