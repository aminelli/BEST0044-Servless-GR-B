import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getPromotionHistoryByCustomer } from "../../application/queryHandlers/promotionQueryHandler";
import { mapItemsResponse, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetPromotionHistory", {
  methods: ["GET"],
  authLevel: "function",
  route: "customers/{customerId}/promotions/history",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeCustomerId = mapRouteParam(request, "customerId");
    if (!routeCustomerId.ok) {
      return badRequest(routeCustomerId.error);
    }

    const customerId = routeCustomerId.value;

    const items = await getPromotionHistoryByCustomer(customerId);
    return ok(mapItemsResponse(items));
  }
});
