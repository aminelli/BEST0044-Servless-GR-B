"""
Lambda per verificare la disponibilità di fondi.
Secondo step della Saga.
"""
import json
import sys
from decimal import Decimal
from typing import Dict, Any
import random

# Aggiungi il path per importare i moduli condivisi
sys.path.insert(0, '/opt/python')

from shared import get_logger, DynamoDBClient, InsufficientFundsError
from models import PaymentStatus

logger = get_logger(__name__)
db_client = DynamoDBClient()


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler per verificare la disponibilità di fondi.
    
    Simula una chiamata a un servizio bancario per verificare
    che il conto/carta abbia fondi sufficienti.
    
    Args:
        event: Evento Step Functions con i dati del pagamento
        context: Contesto Lambda
        
    Returns:
        Evento aggiornato con funds_verification_result
        
    Raises:
        InsufficientFundsError: Se i fondi sono insufficienti
    """
    logger.add_context(
        function_name='verify_funds',
        request_id=context.request_id
    )
    
    logger.info("Starting funds verification", event=event)
    
    try:
        payment_data = event.get('payment', {})
        payment_id = payment_data.get('payment_id')
        amount = Decimal(str(payment_data.get('amount', 0)))
        account_id = payment_data.get('account_id')
        
        logger.add_context(
            payment_id=payment_id,
            amount=str(amount),
            account_id=account_id
        )
        
        # Simula la verifica dei fondi
        # In produzione, questo chiamerebbe un'API bancaria reale
        available_balance = _simulate_balance_check(account_id)
        
        logger.info("Balance check completed", 
                   available_balance=str(available_balance),
                   required_amount=str(amount))
        
        if available_balance < amount:
            raise InsufficientFundsError(
                f"Insufficient funds: available={available_balance}, required={amount}"
            )
        
        # Simula la "prenotazione" dei fondi (hold)
        reservation_id = _simulate_funds_hold(account_id, amount)
        
        # Aggiorna lo stato del pagamento
        db_client.update_payment_status(payment_id, PaymentStatus.FUNDS_VERIFIED.value)
        
        logger.info("Funds verification successful", 
                   payment_id=payment_id,
                   reservation_id=reservation_id)
        
        # Aggiorna l'evento
        event['funds_verification_result'] = 'SUCCESS'
        event['payment']['status'] = PaymentStatus.FUNDS_VERIFIED.value
        event['reservation_id'] = reservation_id  # Per rollback
        
        return event
        
    except InsufficientFundsError as e:
        logger.error("Insufficient funds", 
                    error=str(e),
                    payment_id=payment_data.get('payment_id'))
        
        # Aggiorna lo stato del pagamento
        if payment_data.get('payment_id'):
            db_client.update_payment_status(
                payment_data['payment_id'], 
                PaymentStatus.FAILED.value,
                str(e)
            )
        
        raise
    
    except Exception as e:
        logger.error("Unexpected error during funds verification", 
                    error=str(e),
                    error_type=type(e).__name__)
        raise


def _simulate_balance_check(account_id: str) -> Decimal:
    """
    Simula il controllo del saldo disponibile.
    
    In produzione, chiamarebbe un'API bancaria reale.
    
    Args:
        account_id: ID del conto da verificare
        
    Returns:
        Saldo disponibile
    """
    # Simula saldi diversi in base all'account_id
    # Per testing: account che iniziano con "LOW_" hanno saldo basso
    if account_id.startswith("LOW_"):
        return Decimal('10.00')
    elif account_id.startswith("ZERO_"):
        return Decimal('0.00')
    else:
        # Saldo normale per test
        return Decimal('1000.00')


def _simulate_funds_hold(account_id: str, amount: Decimal) -> str:
    """
    Simula la prenotazione dei fondi (hold/authorization).
    
    In produzione, chiamarebbe un'API bancaria per mettere
    i fondi in hold temporaneamente.
    
    Args:
        account_id: ID del conto
        amount: Importo da riservare
        
    Returns:
        ID della prenotazione (per future operazioni/rollback)
    """
    import uuid
    reservation_id = f"HOLD_{uuid.uuid4().hex[:12]}"
    
    logger.info("Funds hold created", 
               account_id=account_id,
               amount=str(amount),
               reservation_id=reservation_id)
    
    return reservation_id
