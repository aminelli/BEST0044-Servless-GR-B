import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getSimCardOrderStatus } from "../../application/queryHandlers/simCardOrderQueryHandler";
import { mapNotFoundResponse, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetOrderStatus", {
  methods: ["GET"],
  authLevel: "function",
  route: "orders/{orderId}",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeOrderId = mapRouteParam(request, "orderId");
    if (!routeOrderId.ok) {
      return badRequest(routeOrderId.error);
    }

    const orderId = routeOrderId.value;

    const order = await getSimCardOrderStatus(orderId);
    if (!order) {
      return mapNotFoundResponse("Order");
    }

    return ok(order);
  }
});
