export type DocumentReferenceType = "IdentityFront" | "IdentityBack" | "TaxCode" | "Contract";

export class DocumentReference {
  private constructor(
    public readonly type: DocumentReferenceType,
    public readonly blobUrl: string,
    public readonly uploadedAtUtc: string
  ) {}

  static create(type: DocumentReferenceType, blobUrl: string, uploadedAtUtc: string): DocumentReference {
    if (!blobUrl || blobUrl.trim().length === 0) {
      throw new Error("DocumentReference blobUrl cannot be empty.");
    }

    if (!uploadedAtUtc || !uploadedAtUtc.endsWith("Z")) {
      throw new Error("DocumentReference uploadedAtUtc must be UTC ISO timestamp.");
    }

    return new DocumentReference(type, blobUrl, uploadedAtUtc);
  }
}
