import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { checkPromotionEligibility } from "../../application/queryHandlers/promotionQueryHandler";
import { mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("CheckPromotionEligibility", {
  methods: ["GET"],
  authLevel: "function",
  route: "promotions/{promotionId}/eligibility/{customerId}",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeCustomerId = mapRouteParam(request, "customerId");
    if (!routeCustomerId.ok) {
      return badRequest(routeCustomerId.error);
    }

    const routePromotionId = mapRouteParam(request, "promotionId");
    if (!routePromotionId.ok) {
      return badRequest(routePromotionId.error);
    }

    const result = await checkPromotionEligibility(routeCustomerId.value, routePromotionId.value);
    return ok(result);
  }
});
