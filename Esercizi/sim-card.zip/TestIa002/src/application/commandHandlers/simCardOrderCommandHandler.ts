import {
  CreateSimCardOrderCommand,
  CreateSimCardOrderCommandSchema
} from "../../domain/salesOrder/commands/createSimCardOrderCommand";
import { SimCardOrderEntity } from "../../domain/salesOrder/entities/simCardOrderEntity";
import { SalesOrderEvent } from "../../domain/salesOrder/events/salesOrderEvents";
import { CustomerId } from "../../domain/salesOrder/valueObjects/customerId";
import { EmailAddress } from "../../domain/salesOrder/valueObjects/emailAddress";
import { OrderId } from "../../domain/salesOrder/valueObjects/orderId";
import { PhoneNumber } from "../../domain/salesOrder/valueObjects/phoneNumber";
import { getApplicationDependencies } from "../dependencies";
import { newId } from "../../shared/ids";
import { createEventMetadata, toUtcIsoTimestamp } from "../../shared/eventMetadata";

export async function createSimCardOrder(raw: unknown) {
  const deps = getApplicationDependencies();
  const command = CreateSimCardOrderCommandSchema.parse(raw) as CreateSimCardOrderCommand;
  const customerEmail = EmailAddress.create(command.customer.email);
  PhoneNumber.create(command.customer.phone);
  const customerId = CustomerId.create(customerEmail.value);
  const orderId = OrderId.create(newId("order"));
  const now = toUtcIsoTimestamp();
  const order = SimCardOrderEntity.createNew({
    id: orderId.value,
    customerId: customerId.value,
    nowUtc: now
  }).toPrimitives();

  await deps.simCardOrderRepository.upsert(order);
  const event: SalesOrderEvent = {
    ...createEventMetadata(orderId.value),
    orderId: order.id,
    type: "SimCardOrderCreated",
    occurredAtUtc: now,
    payload: command
  };

  await deps.domainEventPublisher.publishDomainEvent(event);

  return order;
}
