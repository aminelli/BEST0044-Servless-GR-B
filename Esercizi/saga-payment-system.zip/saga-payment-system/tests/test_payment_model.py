"""
Unit tests per il modello Payment.
"""
import unittest
from decimal import Decimal
from datetime import datetime

import sys
sys.path.insert(0, '../src')

from models.payment import Payment, PaymentStatus


class TestPayment(unittest.TestCase):
    """Test per la classe Payment."""
    
    def test_payment_creation(self):
        """Testa la creazione di un pagamento."""
        payment = Payment(
            payment_id="test-123",
            customer_id="cust-456",
            amount=Decimal("100.50"),
            merchant_id="merch-789"
        )
        
        self.assertEqual(payment.payment_id, "test-123")
        self.assertEqual(payment.customer_id, "cust-456")
        self.assertEqual(payment.amount, Decimal("100.50"))
        self.assertEqual(payment.status, PaymentStatus.PENDING)
        self.assertIsNotNone(payment.created_at)
    
    def test_payment_to_dict(self):
        """Testa la conversione a dizionario."""
        payment = Payment(
            payment_id="test-123",
            customer_id="cust-456",
            amount=Decimal("100.50"),
            merchant_id="merch-789"
        )
        
        data = payment.to_dict()
        
        self.assertEqual(data["payment_id"], "test-123")
        self.assertEqual(data["customer_id"], "cust-456")
        self.assertEqual(data["amount"], "100.50")
        self.assertEqual(data["status"], "PENDING")
    
    def test_payment_from_dict(self):
        """Testa la creazione da dizionario."""
        data = {
            "payment_id": "test-123",
            "customer_id": "cust-456",
            "amount": "100.50",
            "merchant_id": "merch-789",
            "currency": "EUR",
            "status": "VALIDATED",
            "created_at": datetime.utcnow().isoformat()
        }
        
        payment = Payment.from_dict(data)
        
        self.assertEqual(payment.payment_id, "test-123")
        self.assertEqual(payment.amount, Decimal("100.50"))
        self.assertEqual(payment.status, PaymentStatus.VALIDATED)


if __name__ == '__main__':
    unittest.main()
