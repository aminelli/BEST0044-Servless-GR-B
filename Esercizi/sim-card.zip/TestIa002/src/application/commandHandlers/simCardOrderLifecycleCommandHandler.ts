import { z } from "zod";
import {
  OrderDocumentReference,
  SimCardOrder,
  SimCardOrderStatus
} from "../../domain/salesOrder/aggregates/simCardOrderAggregate";
import { SimCardOrderEntity } from "../../domain/salesOrder/entities/simCardOrderEntity";
import { SalesOrderEvent } from "../../domain/salesOrder/events/salesOrderEvents";
import { DocumentReference } from "../../domain/salesOrder/valueObjects/documentReference";
import { Money } from "../../domain/salesOrder/valueObjects/money";
import { OrderId } from "../../domain/salesOrder/valueObjects/orderId";
import { requestAndProcessPayment, refundLatestPayment } from "./paymentCommandHandler";
import { getApplicationDependencies } from "../dependencies";
import { createEventMetadata, toUtcIsoTimestamp } from "../../shared/eventMetadata";

const UploadDocumentsSchema = z.object({
  orderId: z.string().min(1),
  documents: z
    .array(
      z.object({
        type: z.enum(["IdentityFront", "IdentityBack", "TaxCode"]),
        fileName: z.string().min(1),
        content: z.string().min(1)
      })
    )
    .min(1)
});

const RequestActivationSchema = z.object({
  orderId: z.string().min(1)
});

const ProcessPaymentSchema = z.object({
  orderId: z.string().min(1),
  amount: z.number().nonnegative().optional()
});

const ReviewActivationSchema = z.object({
  orderId: z.string().min(1),
  approved: z.boolean(),
  reason: z.string().optional()
});

const GenerateContractSchema = z.object({
  orderId: z.string().min(1)
});

const SendContractSchema = z.object({
  orderId: z.string().min(1),
  channel: z.enum(["email", "sms"]).default("email")
});

const CompensateStepSchema = z.object({
  orderId: z.string().min(1),
  step: z.string().min(1)
});

const DocumentTypeToContainer = {
  IdentityFront: process.env.BLOB_CUSTOMER_DOCS_CONTAINER ?? "customer-documents",
  IdentityBack: process.env.BLOB_CUSTOMER_DOCS_CONTAINER ?? "customer-documents",
  TaxCode: process.env.BLOB_CUSTOMER_DOCS_CONTAINER ?? "customer-documents",
  Contract: process.env.BLOB_CONTRACTS_CONTAINER ?? "contracts"
} as const;

async function loadOrder(orderId: string): Promise<SimCardOrder> {
  const deps = getApplicationDependencies();
  const normalizedOrderId = OrderId.create(orderId);
  const order = await deps.simCardOrderRepository.getById(normalizedOrderId.value);
  if (!order) {
    throw new Error("Order not found.");
  }

  return order;
}

async function publish(orderId: string, type: SalesOrderEvent["type"], payload: Record<string, unknown>) {
  const deps = getApplicationDependencies();
  const event: SalesOrderEvent = {
    ...createEventMetadata(orderId),
    orderId,
    type,
    occurredAtUtc: toUtcIsoTimestamp(),
    payload
  };

  await deps.domainEventPublisher.publishDomainEvent(event);
}

async function updateStatus(order: SimCardOrder, to: SimCardOrderStatus, reason: string) {
  const deps = getApplicationDependencies();
  const now = toUtcIsoTimestamp();
  const entity = SimCardOrderEntity.rehydrate(order);
  entity.transition(to, reason, now);
  const snapshot = entity.toPrimitives();
  order.status = snapshot.status;
  order.updatedAt = snapshot.updatedAt;
  order.transitions = snapshot.transitions;
  await deps.simCardOrderRepository.upsert(snapshot);
}

export async function uploadCustomerDocuments(raw: unknown) {
  const deps = getApplicationDependencies();
  const command = UploadDocumentsSchema.parse(raw);
  const order = await loadOrder(command.orderId);

  const refs: OrderDocumentReference[] = [];
  for (const doc of command.documents) {
    const container = DocumentTypeToContainer[doc.type];
    const blobUrl = await deps.documentStorage.uploadTextDocument(
      container,
      `${order.id}/${doc.fileName}`,
      doc.content
    );
    const ref = DocumentReference.create(doc.type, blobUrl, toUtcIsoTimestamp());
    refs.push({
      type: ref.type,
      blobUrl: ref.blobUrl,
      uploadedAtUtc: ref.uploadedAtUtc
    });
  }

  order.documents.push(...refs);
  const orderEntity = SimCardOrderEntity.rehydrate(order);
  orderEntity.addDocuments(refs);
  const snapshot = orderEntity.toPrimitives();
  order.documents = snapshot.documents;
  await deps.simCardOrderRepository.upsert(snapshot);
  await updateStatus(order, "DocumentsUploaded", "Customer documents uploaded");

  await publish(order.id, "CustomerDocumentsUploaded", {
    count: refs.length,
    documentTypes: refs.map((x) => x.type)
  });

  return { orderId: order.id, uploaded: refs.length };
}

export async function requestActivation(raw: unknown) {
  const command = RequestActivationSchema.parse(raw);
  const order = await loadOrder(command.orderId);

  await updateStatus(order, "ActivationRequested", "Activation requested");
  await publish(order.id, "ActivationRequested", { orderId: order.id });

  return { orderId: order.id, status: order.status };
}

export async function processSimPayment(raw: unknown) {
  const command = ProcessPaymentSchema.parse(raw);
  const order = await loadOrder(command.orderId);
  const payment = Money.eur(command.amount ?? 0);

  const paymentResult = await requestAndProcessPayment({
    aggregateType: "SimOrder",
    aggregateId: order.id,
    customerId: order.customerId,
    amount: payment.amount
  });

  await updateStatus(order, "PaymentProcessed", `Payment processed amount=${payment.amount}`);
  await publish(order.id, "PaymentProcessed", {
    paymentId: paymentResult.paymentId,
    amount: payment.amount,
    currency: payment.currency
  });

  return { orderId: order.id, status: order.status };
}

export async function reviewActivation(raw: unknown) {
  const command = ReviewActivationSchema.parse(raw);
  const order = await loadOrder(command.orderId);

  if (command.approved) {
    await updateStatus(order, "ActivationApproved", command.reason ?? "Activation approved");
    await publish(order.id, "ActivationApproved", {
      orderId: order.id,
      reason: command.reason
    });
  } else {
    await updateStatus(order, "ActivationRejected", command.reason ?? "Activation rejected");
    await publish(order.id, "ActivationRejected", {
      orderId: order.id,
      reason: command.reason
    });
  }

  return { orderId: order.id, status: order.status };
}

export async function generateContract(raw: unknown) {
  const deps = getApplicationDependencies();
  const command = GenerateContractSchema.parse(raw);
  const order = await loadOrder(command.orderId);

  const contractContainer = DocumentTypeToContainer.Contract;
  const contractUrl = await deps.documentStorage.uploadTextDocument(
    contractContainer,
    `${order.id}/contract.txt`,
    `Contract for order ${order.id}`
  );

  const orderEntity = SimCardOrderEntity.rehydrate(order);
  orderEntity.addDocuments([
    {
      ...DocumentReference.create("Contract", contractUrl, toUtcIsoTimestamp())
    }
  ]);
  const snapshot = orderEntity.toPrimitives();
  order.documents = snapshot.documents;
  await deps.simCardOrderRepository.upsert(snapshot);

  await updateStatus(order, "ContractGenerated", "Contract generated");
  await publish(order.id, "ContractGenerated", { orderId: order.id, contractUrl });

  return { orderId: order.id, status: order.status, contractUrl };
}

export async function sendContractToCustomer(raw: unknown) {
  const command = SendContractSchema.parse(raw);
  const order = await loadOrder(command.orderId);

  await updateStatus(order, "ContractSent", `Contract sent via ${command.channel}`);
  await publish(order.id, "ContractSentToCustomer", {
    orderId: order.id,
    channel: command.channel
  });

  return { orderId: order.id, status: order.status, channel: command.channel };
}

export async function compensateSimCardOrderStep(raw: unknown) {
  const deps = getApplicationDependencies();
  const command = CompensateStepSchema.parse(raw);
  const order = await loadOrder(command.orderId);

  if (command.step === "SendContract") {
    await updateStatus(order, "ContractGenerated", "Compensation: cancel contract sending");
    return { orderId: order.id, compensated: true, action: "CancelContractSend" };
  }

  if (command.step === "GenerateContract") {
    const orderEntity = SimCardOrderEntity.rehydrate(order);
    orderEntity.removeDocumentsByTypes(["Contract"]);
    const snapshot = orderEntity.toPrimitives();
    order.documents = snapshot.documents;
    await deps.simCardOrderRepository.upsert(snapshot);
    await updateStatus(order, "ActivationRequested", "Compensation: void contract");
    return { orderId: order.id, compensated: true, action: "VoidContract" };
  }

  if (command.step === "RequestActivation") {
    await updateStatus(order, "ActivationRejected", "Compensation: cancel activation request");
    return { orderId: order.id, compensated: true, action: "CancelActivationRequest" };
  }

  if (command.step === "ProcessPayment") {
    const refund = await refundLatestPayment({
      aggregateType: "SimOrder",
      aggregateId: order.id
    });
    await updateStatus(order, "DocumentsUploaded", "Compensation: refund payment");
    return {
      orderId: order.id,
      compensated: true,
      action: "RefundPayment",
      refunded: refund.refunded,
      paymentId: refund.paymentId
    };
  }

  if (command.step === "UploadDocuments") {
    const orderEntity = SimCardOrderEntity.rehydrate(order);
    orderEntity.removeDocumentsByTypes(["IdentityFront", "IdentityBack", "TaxCode"]);
    const snapshot = orderEntity.toPrimitives();
    order.documents = snapshot.documents;
    await deps.simCardOrderRepository.upsert(snapshot);
    await updateStatus(order, "Created", "Compensation: delete uploaded documents");
    return { orderId: order.id, compensated: true, action: "DeleteDocuments" };
  }

  return { orderId: order.id, compensated: false, action: "NoOp" };
}
