export class PaymentId {
  private constructor(public readonly value: string) {}

  static create(raw: string): PaymentId {
    const value = raw?.trim();
    if (!value) {
      throw new Error("PaymentId cannot be empty.");
    }

    return new PaymentId(value);
  }
}
