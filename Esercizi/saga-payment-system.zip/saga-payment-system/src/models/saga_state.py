"""
Modello per gestire lo stato della Saga.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional
from datetime import datetime


class SagaStatus(Enum):
    """Stati possibili della Saga."""
    STARTED = "STARTED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    COMPENSATING = "COMPENSATING"
    FAILED = "FAILED"
    ROLLED_BACK = "ROLLED_BACK"


class SagaStep(Enum):
    """Step della Saga per il pagamento."""
    VALIDATE_PAYMENT = "VALIDATE_PAYMENT"
    VERIFY_FUNDS = "VERIFY_FUNDS"
    PROCESS_PAYMENT = "PROCESS_PAYMENT"
    NOTIFY_CUSTOMER = "NOTIFY_CUSTOMER"
    RECORD_TRANSACTION = "RECORD_TRANSACTION"


@dataclass
class SagaState:
    """
    Rappresenta lo stato di una Saga in corso.
    
    Attributes:
        saga_id: Identificativo univoco della Saga (stesso del payment_id)
        payment_id: ID del pagamento associato
        status: Stato corrente della Saga
        current_step: Step corrente in esecuzione
        completed_steps: Lista degli step completati con successo
        failed_step: Step che ha causato il fallimento (se presente)
        error_message: Messaggio di errore
        started_at: Timestamp di inizio
        updated_at: Timestamp ultimo aggiornamento
        compensated_steps: Lista degli step per cui è stata eseguita la compensazione
    """
    saga_id: str
    payment_id: str
    status: SagaStatus = SagaStatus.STARTED
    current_step: Optional[SagaStep] = None
    completed_steps: List[str] = field(default_factory=list)
    failed_step: Optional[str] = None
    error_message: Optional[str] = None
    started_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    compensated_steps: List[str] = field(default_factory=list)
    retry_count: int = 0
    
    def __post_init__(self):
        """Inizializza i timestamp se non forniti."""
        if self.started_at is None:
            self.started_at = datetime.utcnow()
        if self.updated_at is None:
            self.updated_at = datetime.utcnow()
    
    def to_dict(self) -> dict:
        """
        Converte lo stato della Saga in un dizionario per DynamoDB.
        
        Returns:
            Dizionario con lo stato della Saga
        """
        return {
            "saga_id": self.saga_id,
            "payment_id": self.payment_id,
            "status": self.status.value,
            "current_step": self.current_step.value if self.current_step else None,
            "completed_steps": self.completed_steps,
            "failed_step": self.failed_step,
            "error_message": self.error_message,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "compensated_steps": self.compensated_steps,
            "retry_count": self.retry_count,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'SagaState':
        """
        Crea un oggetto SagaState da un dizionario.
        
        Args:
            data: Dizionario con i dati della Saga
            
        Returns:
            Istanza di SagaState
        """
        return cls(
            saga_id=data["saga_id"],
            payment_id=data["payment_id"],
            status=SagaStatus(data.get("status", "STARTED")),
            current_step=SagaStep(data["current_step"]) if data.get("current_step") else None,
            completed_steps=data.get("completed_steps", []),
            failed_step=data.get("failed_step"),
            error_message=data.get("error_message"),
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") else None,
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            compensated_steps=data.get("compensated_steps", []),
            retry_count=data.get("retry_count", 0),
        )
    
    def mark_step_completed(self, step: SagaStep):
        """
        Marca uno step come completato.
        
        Args:
            step: Lo step completato
        """
        if step.value not in self.completed_steps:
            self.completed_steps.append(step.value)
        self.updated_at = datetime.utcnow()
    
    def mark_step_compensated(self, step: SagaStep):
        """
        Marca uno step come compensato (rollback eseguito).
        
        Args:
            step: Lo step compensato
        """
        if step.value not in self.compensated_steps:
            self.compensated_steps.append(step.value)
        self.updated_at = datetime.utcnow()
