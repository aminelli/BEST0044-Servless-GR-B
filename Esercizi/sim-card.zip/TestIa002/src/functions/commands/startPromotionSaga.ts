import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import * as df from "durable-functions";
import { mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest } from "../../shared/http";

app.http("StartPromotionSaga", {
  methods: ["POST"],
  authLevel: "function",
  route: "promotions/subscriptions/{subscriptionId}/saga/start",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    const routeSubscriptionId = mapRouteParam(request, "subscriptionId");
    if (!routeSubscriptionId.ok) {
      return badRequest(routeSubscriptionId.error);
    }

    const subscriptionId = routeSubscriptionId.value;

    const client = df.getClient(context);
    const instanceId = await client.startNew("PromotionSubscriptionSaga", {
      input: { subscriptionId }
    });

    return accepted({ instanceId, subscriptionId });
  }
});
