export type UtcIsoTimestamp = `${string}Z`;

export interface EventMetadata {
  eventId: string;
  correlationId: string;
  causationId?: string;
  version: number;
}