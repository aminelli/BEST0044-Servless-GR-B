import { z } from "zod";
import {
  PromotionSubscription,
  PromotionSubscriptionStatus
} from "../../domain/promotionManagement/aggregates/promotionSubscriptionAggregate";
import { PromotionSubscriptionEntity } from "../../domain/promotionManagement/entities/promotionSubscriptionEntity";
import { PromotionEvent } from "../../domain/promotionManagement/events/promotionEvents";
import { SubscriptionId } from "../../domain/promotionManagement/valueObjects/subscriptionId";
import { Money } from "../../domain/salesOrder/valueObjects/money";
import { requestAndProcessPayment, refundLatestPayment } from "./paymentCommandHandler";
import { getApplicationDependencies } from "../dependencies";
import { createEventMetadata, toUtcIsoTimestamp } from "../../shared/eventMetadata";

const ProcessPaymentSchema = z.object({
  subscriptionId: z.string().min(1),
  amount: z.number().nonnegative().optional()
});

const ActivatePromotionSchema = z.object({
  subscriptionId: z.string().min(1)
});

const NotifyCustomerSchema = z.object({
  subscriptionId: z.string().min(1),
  channels: z.array(z.enum(["email", "sms"]))
});

const CompensatePromotionSchema = z.object({
  subscriptionId: z.string().min(1),
  step: z.string().min(1)
});

async function getSubscription(subscriptionId: string): Promise<PromotionSubscription> {
  const deps = getApplicationDependencies();
  const normalizedSubscriptionId = SubscriptionId.create(subscriptionId);
  const item = await deps.promotionSubscriptionRepository.getById(normalizedSubscriptionId.value);
  if (!item) {
    throw new Error("Subscription not found.");
  }

  return item;
}

async function publish(
  subscriptionId: string,
  type: PromotionEvent["type"],
  payload: Record<string, unknown>
) {
  const deps = getApplicationDependencies();
  const event: PromotionEvent = {
    ...createEventMetadata(subscriptionId),
    subscriptionId,
    type,
    occurredAtUtc: toUtcIsoTimestamp(),
    payload
  };

  await deps.domainEventPublisher.publishDomainEvent(event);
}

async function updateStatus(
  subscription: PromotionSubscription,
  to: PromotionSubscriptionStatus
): Promise<void> {
  const deps = getApplicationDependencies();
  const entity = PromotionSubscriptionEntity.rehydrate(subscription);
  entity.transition(to, toUtcIsoTimestamp());
  const snapshot = entity.toPrimitives();
  subscription.status = snapshot.status;
  subscription.updatedAt = snapshot.updatedAt;
  await deps.promotionSubscriptionRepository.upsert(snapshot);
}

export async function processPromotionPayment(raw: unknown) {
  const command = ProcessPaymentSchema.parse(raw);
  const subscription = await getSubscription(command.subscriptionId);
  const payment = Money.eur(command.amount ?? 0);

  const paymentResult = await requestAndProcessPayment({
    aggregateType: "PromotionSubscription",
    aggregateId: subscription.id,
    customerId: subscription.customerId,
    amount: payment.amount
  });

  await updateStatus(subscription, "PaymentProcessed");

  await publish(subscription.id, "PaymentProcessed", {
    paymentId: paymentResult.paymentId,
    amount: payment.amount,
    currency: payment.currency
  });

  return { subscriptionId: subscription.id, status: subscription.status };
}

export async function activatePromotion(raw: unknown) {
  const command = ActivatePromotionSchema.parse(raw);
  const subscription = await getSubscription(command.subscriptionId);

  await updateStatus(subscription, "Activated");

  await publish(subscription.id, "PromotionActivated", {
    promotionId: subscription.promotionId
  });

  return { subscriptionId: subscription.id, status: subscription.status };
}

export async function notifyCustomer(raw: unknown) {
  const command = NotifyCustomerSchema.parse(raw);
  const subscription = await getSubscription(command.subscriptionId);

  await updateStatus(subscription, "Notified");

  await publish(subscription.id, "CustomerNotified", {
    channels: command.channels
  });

  return {
    subscriptionId: subscription.id,
    status: subscription.status,
    channels: command.channels
  };
}

export async function compensatePromotionStep(raw: unknown) {
  const command = CompensatePromotionSchema.parse(raw);
  const subscription = await getSubscription(command.subscriptionId);

  if (command.step === "NotifyCustomer") {
    await updateStatus(subscription, "Activated");
    return { subscriptionId: subscription.id, compensated: true, action: "SendDeactivationNotice" };
  }

  if (command.step === "ActivatePromotion") {
    await updateStatus(subscription, "PaymentProcessed");
    return { subscriptionId: subscription.id, compensated: true, action: "DeactivatePromotion" };
  }

  if (command.step === "ProcessPayment") {
    const refund = await refundLatestPayment({
      aggregateType: "PromotionSubscription",
      aggregateId: subscription.id
    });
    await updateStatus(subscription, "Requested");
    return {
      subscriptionId: subscription.id,
      compensated: true,
      action: "RefundPayment",
      refunded: refund.refunded,
      paymentId: refund.paymentId
    };
  }

  return { subscriptionId: subscription.id, compensated: false, action: "NoOp" };
}
