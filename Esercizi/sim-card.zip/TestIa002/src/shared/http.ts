import { HttpRequest } from "@azure/functions";

export async function readJsonBody<T>(request: HttpRequest): Promise<T> {
  return (await request.json()) as T;
}

export function ok<T>(body: T) {
  return { status: 200, jsonBody: body };
}

export function accepted<T>(body: T) {
  return { status: 202, jsonBody: body };
}

export function badRequest(message: string) {
  return { status: 400, jsonBody: { error: message } };
}
