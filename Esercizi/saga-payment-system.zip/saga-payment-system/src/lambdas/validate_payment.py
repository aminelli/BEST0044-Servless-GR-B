"""
Lambda per validare un pagamento.
Primo step della Saga.
"""
import json
import os
import sys
from decimal import Decimal
from typing import Dict, Any

# Aggiungi il path per importare i moduli condivisi
sys.path.insert(0, '/opt/python')

from shared import get_logger, DynamoDBClient, PaymentValidationError
from models import Payment, PaymentStatus

logger = get_logger(__name__)
db_client = DynamoDBClient()


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler per validare i dati di un pagamento.
    
    Valida:
    - Formato payment_id
    - Importo > 0
    - Lunghezza card_number
    - Presenza customer_id e merchant_id
    
    Args:
        event: Evento Step Functions con i dati del pagamento
        context: Contesto Lambda
        
    Returns:
        Evento aggiornato con validation_result
        
    Raises:
        PaymentValidationError: Se la validazione fallisce
    """
    logger.add_context(
        function_name='validate_payment',
        request_id=context.request_id
    )
    
    logger.info("Starting payment validation", event=event)
    
    try:
        # Estrai i dati del pagamento dall'evento
        payment_data = event.get('payment', {})
        payment_id = payment_data.get('payment_id')
        
        if not payment_id:
            raise PaymentValidationError("Missing payment_id")
        
        logger.add_context(payment_id=payment_id)
        
        # Validazione importo
        amount = payment_data.get('amount')
        if not amount or Decimal(str(amount)) <= 0:
            raise PaymentValidationError(f"Invalid amount: {amount}")
        
        # Validazione customer_id
        if not payment_data.get('customer_id'):
            raise PaymentValidationError("Missing customer_id")
        
        # Validazione merchant_id
        if not payment_data.get('merchant_id'):
            raise PaymentValidationError("Missing merchant_id")
        
        # Validazione account_id o card
        account_id = payment_data.get('account_id')
        card_number = payment_data.get('card_number')
        
        if not account_id and not card_number:
            raise PaymentValidationError("Missing account_id or card_number")
        
        if card_number and len(card_number) < 4:
            raise PaymentValidationError("Invalid card_number format")
        
        # Check idempotenza - verifica se il pagamento esiste già
        idempotency_key = payment_data.get('idempotency_key')
        if idempotency_key:
            existing_payment = db_client.get_payment(payment_id)
            if existing_payment and existing_payment.get('idempotency_key') == idempotency_key:
                logger.warning("Idempotent request detected", 
                             existing_status=existing_payment.get('status'))
                # Ritorna il risultato esistente
                event['validation_result'] = 'ALREADY_PROCESSED'
                event['payment'] = existing_payment
                return event
        
        # Aggiorna lo stato del pagamento
        db_client.update_payment_status(payment_id, PaymentStatus.VALIDATED.value)
        
        logger.info("Payment validation successful", 
                   payment_id=payment_id,
                   amount=str(amount))
        
        # Aggiorna l'evento con il risultato
        event['validation_result'] = 'SUCCESS'
        event['payment']['status'] = PaymentStatus.VALIDATED.value
        
        return event
        
    except PaymentValidationError as e:
        logger.error("Payment validation failed", 
                    error=str(e),
                    payment_id=payment_data.get('payment_id'))
        
        # Aggiorna lo stato del pagamento a FAILED
        if payment_data.get('payment_id'):
            db_client.update_payment_status(
                payment_data['payment_id'], 
                PaymentStatus.FAILED.value,
                str(e)
            )
        
        raise
    
    except Exception as e:
        logger.error("Unexpected error during validation", 
                    error=str(e),
                    error_type=type(e).__name__)
        raise
