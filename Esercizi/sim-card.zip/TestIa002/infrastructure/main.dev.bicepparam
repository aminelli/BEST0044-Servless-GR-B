using './main.bicep'

param environmentName = 'dev'
param appName = 'telecomdemo'
param serviceBusSku = 'Standard'
