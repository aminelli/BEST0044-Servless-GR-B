"""
Lambda per stornare un pagamento (compensazione process_payment).
"""
import json
import sys
from typing import Dict, Any
import uuid

# Aggiungi il path per importare i moduli condivisi
sys.path.insert(0, '/opt/python')

from shared import get_logger, DynamoDBClient
from models import PaymentStatus

logger = get_logger(__name__)
db_client = DynamoDBClient()


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Compensating transaction per process_payment.
    
    Storna il pagamento già processato in caso di fallimento successivo.
    
    Args:
        event: Evento Step Functions con i dati del pagamento
        context: Contesto Lambda
        
    Returns:
        Evento aggiornato con compensation_result
    """
    logger.add_context(
        function_name='compensate_process_payment',
        request_id=context.request_id
    )
    
    logger.info("Starting payment reversal (compensation)", event=event)
    
    try:
        payment_data = event.get('payment', {})
        payment_id = payment_data.get('payment_id')
        transaction_id = event.get('transaction_id')
        account_id = payment_data.get('account_id')
        merchant_id = payment_data.get('merchant_id')
        amount = payment_data.get('amount')
        
        logger.add_context(
            payment_id=payment_id,
            transaction_id=transaction_id
        )
        
        if not transaction_id:
            logger.warning("No transaction_id found, skipping compensation")
            event['payment_compensation_result'] = 'SKIPPED_NO_TRANSACTION'
            return event
        
        # Simula lo storno del pagamento
        reversal_id = _reverse_payment(
            transaction_id=transaction_id,
            account_id=account_id,
            merchant_id=merchant_id,
            amount=amount
        )
        
        # Aggiorna lo stato del pagamento
        db_client.update_payment_status(
            payment_id, 
            PaymentStatus.ROLLED_BACK.value,
            "Payment reversed due to Saga failure"
        )
        
        logger.info("Payment reversed successfully", 
                   payment_id=payment_id,
                   transaction_id=transaction_id,
                   reversal_id=reversal_id)
        
        event['payment_compensation_result'] = 'SUCCESS'
        event['reversal_id'] = reversal_id
        event['payment']['status'] = PaymentStatus.ROLLED_BACK.value
        
        return event
        
    except Exception as e:
        logger.error("Payment reversal failed", 
                    error=str(e),
                    payment_id=payment_data.get('payment_id'))
        
        # Questo è critico - il pagamento è stato processato ma non stornato
        # Richiede intervento manuale urgente
        event['payment_compensation_result'] = 'FAILED_CRITICAL'
        event['payment_compensation_error'] = str(e)
        
        return event


def _reverse_payment(
    transaction_id: str,
    account_id: str,
    merchant_id: str,
    amount: str
) -> str:
    """
    Storna un pagamento già processato.
    
    In produzione:
    1. Riaccrediterebbe il conto del cliente
    2. Addebitare il merchant
    3. Registrerebbe lo storno nel sistema bancario
    4. Creerebbe un record di audit
    
    Args:
        transaction_id: ID della transazione originale da stornare
        account_id: ID del conto da riaccreditare
        merchant_id: ID del merchant da addebitare
        amount: Importo da stornare
        
    Returns:
        ID dello storno
    """
    reversal_id = f"REV_{uuid.uuid4().hex[:16].upper()}"
    
    logger.info("Processing payment reversal", 
               transaction_id=transaction_id,
               reversal_id=reversal_id,
               account_id=account_id,
               merchant_id=merchant_id,
               amount=amount)
    
    # In produzione, qui chiameremmo l'API del payment processor per:
    # 1. Creare una transazione di storno
    # 2. Riaccreditare il cliente
    # 3. Addebitare il merchant
    # 4. Aggiornare i bilanci
    
    # Simula un delay per realismo
    import time
    time.sleep(0.2)
    
    logger.info("Payment reversal completed", 
               reversal_id=reversal_id,
               original_transaction=transaction_id)
    
    return reversal_id
