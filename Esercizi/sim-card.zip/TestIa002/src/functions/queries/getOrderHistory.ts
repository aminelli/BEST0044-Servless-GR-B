import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getSimCardOrderHistory } from "../../application/queryHandlers/simCardOrderQueryHandler";
import { mapItemsResponse, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetOrderHistory", {
  methods: ["GET"],
  authLevel: "function",
  route: "orders/{orderId}/history",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeOrderId = mapRouteParam(request, "orderId");
    if (!routeOrderId.ok) {
      return badRequest(routeOrderId.error);
    }

    const orderId = routeOrderId.value;

    const history = await getSimCardOrderHistory(orderId);
    return ok(mapItemsResponse(history));
  }
});
