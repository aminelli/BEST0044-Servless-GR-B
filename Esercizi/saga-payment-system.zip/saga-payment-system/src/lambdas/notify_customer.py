"""
Lambda per notificare il cliente dell'esito del pagamento.
Quarto step della Saga.
"""
import json
import sys
from typing import Dict, Any

# Aggiungi il path per importare i moduli condivisi
sys.path.insert(0, '/opt/python')

from shared import get_logger, DynamoDBClient
from models import PaymentStatus

logger = get_logger(__name__)
db_client = DynamoDBClient()


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Handler per notificare il cliente dell'esito del pagamento.
    
    Invia notifica via email/SMS/push notification.
    
    Args:
        event: Evento Step Functions con i dati del pagamento
        context: Contesto Lambda
        
    Returns:
        Evento aggiornato con notification_result
    """
    logger.add_context(
        function_name='notify_customer',
        request_id=context.request_id
    )
    
    logger.info("Starting customer notification", event=event)
    
    try:
        payment_data = event.get('payment', {})
        payment_id = payment_data.get('payment_id')
        customer_id = payment_data.get('customer_id')
        amount = payment_data.get('amount')
        transaction_id = event.get('transaction_id')
        
        logger.add_context(
            payment_id=payment_id,
            customer_id=customer_id
        )
        
        # Simula l'invio della notifica
        # In produzione, userebbe SNS, SES, o un servizio di notifica esterno
        notification_id = _send_notification(
            customer_id=customer_id,
            payment_id=payment_id,
            amount=amount,
            transaction_id=transaction_id,
            status='SUCCESS'
        )
        
        logger.info("Customer notification sent", 
                   payment_id=payment_id,
                   notification_id=notification_id)
        
        # Aggiorna l'evento
        event['notification_result'] = 'SUCCESS'
        event['notification_id'] = notification_id
        
        return event
        
    except Exception as e:
        # Le notifiche sono "best effort" - non dovrebbero far fallire la Saga
        # Ma logghiamo l'errore per investigazione
        logger.error("Notification failed (non-critical)", 
                    error=str(e),
                    payment_id=payment_data.get('payment_id'))
        
        # Ritorna comunque successo, ma con flag di warning
        event['notification_result'] = 'FAILED_NON_CRITICAL'
        event['notification_error'] = str(e)
        
        return event


def _send_notification(
    customer_id: str,
    payment_id: str,
    amount: str,
    transaction_id: str,
    status: str
) -> str:
    """
    Simula l'invio di una notifica al cliente.
    
    In produzione:
    - Recupererebbe i dati di contatto del cliente
    - Invierebbe email via SES
    - Invierebbe SMS via SNS
    - Potrebbe inviare push notification
    
    Args:
        customer_id: ID del cliente
        payment_id: ID del pagamento
        amount: Importo del pagamento
        transaction_id: ID della transazione
        status: Stato del pagamento
        
    Returns:
        ID della notifica inviata
    """
    import uuid
    
    notification_id = f"NOTIF_{uuid.uuid4().hex[:12]}"
    
    # Simula il corpo della notifica
    message = f"""
    Caro cliente {customer_id},
    
    Il tuo pagamento è stato completato con successo!
    
    Dettagli:
    - ID Pagamento: {payment_id}
    - Importo: €{amount}
    - ID Transazione: {transaction_id}
    - Data: {__import__('datetime').datetime.utcnow().isoformat()}
    
    Grazie per aver utilizzato il nostro servizio.
    """
    
    logger.info("Notification prepared", 
               customer_id=customer_id,
               notification_id=notification_id,
               message_preview=message[:100])
    
    # In produzione, qui invieremmo realmente la notifica
    # via SNS, SES, o altro servizio
    
    return notification_id
