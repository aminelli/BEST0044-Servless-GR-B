targetScope = 'resourceGroup'

@description('Environment name used in resource naming.')
param environmentName string = 'dev'

@description('Azure region for all resources.')
param location string = resourceGroup().location

@description('Base name prefix for resources.')
param appName string = 'telecomdemo'

@description('Service Bus SKU')
@allowed([
  'Basic'
  'Standard'
  'Premium'
])
param serviceBusSku string = 'Standard'

var suffix = toLower('${appName}-${environmentName}')
var storageName = toLower(replace('st${suffix}', '-', ''))
var cosmosName = toLower('${appName}-${environmentName}-cosmos')
var sbName = toLower('${appName}-${environmentName}-sb')
var aiName = '${appName}-${environmentName}-ai'
var planName = '${appName}-${environmentName}-plan'
var functionAppName = '${appName}-${environmentName}-func'

resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageName
  location: location
  sku: {
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    supportsHttpsTrafficOnly: true
    allowBlobPublicAccess: false
  }
}

resource blobs 'Microsoft.Storage/storageAccounts/blobServices@2023-05-01' = {
  name: 'default'
  parent: storage
}

resource docsContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = {
  name: 'customer-documents'
  parent: blobs
  properties: {
    publicAccess: 'None'
  }
}

resource contractsContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = {
  name: 'contracts'
  parent: blobs
  properties: {
    publicAccess: 'None'
  }
}

resource releasesContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-05-01' = {
  name: 'function-releases'
  parent: blobs
  properties: {
    publicAccess: 'None'
  }
}

resource cosmos 'Microsoft.DocumentDB/databaseAccounts@2024-02-15-preview' = {
  name: cosmosName
  location: location
  kind: 'GlobalDocumentDB'
  properties: {
    databaseAccountOfferType: 'Standard'
    consistencyPolicy: {
      defaultConsistencyLevel: 'Session'
    }
    locations: [
      {
        failoverPriority: 0
        locationName: location
      }
    ]
    minimalTlsVersion: 'Tls12'
    publicNetworkAccess: 'Enabled'
    disableKeyBasedMetadataWriteAccess: true
  }
}

resource cosmosSqlDb 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2024-02-15-preview' = {
  name: 'telecom-demo'
  parent: cosmos
  properties: {
    resource: {
      id: 'telecom-demo'
    }
  }
}

resource cosmosOrdersContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2024-02-15-preview' = {
  name: 'orders'
  parent: cosmosSqlDb
  properties: {
    resource: {
      id: 'orders'
      partitionKey: {
        paths: [
          '/customerId'
        ]
        kind: 'Hash'
      }
    }
  }
}

resource cosmosPromotionsContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2024-02-15-preview' = {
  name: 'promotion-subscriptions'
  parent: cosmosSqlDb
  properties: {
    resource: {
      id: 'promotion-subscriptions'
      partitionKey: {
        paths: [
          '/customerId'
        ]
        kind: 'Hash'
      }
    }
  }
}

resource cosmosPaymentsContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2024-02-15-preview' = {
  name: 'payments'
  parent: cosmosSqlDb
  properties: {
    resource: {
      id: 'payments'
      partitionKey: {
        paths: [
          '/aggregateId'
        ]
        kind: 'Hash'
      }
    }
  }
}

resource sb 'Microsoft.ServiceBus/namespaces@2024-01-01' = {
  name: sbName
  location: location
  sku: {
    name: serviceBusSku
    tier: serviceBusSku
  }
  properties: {
    minimumTlsVersion: '1.2'
    publicNetworkAccess: 'Enabled'
  }
}

resource sbTopic 'Microsoft.ServiceBus/namespaces/topics@2024-01-01' = {
  name: 'domain-events'
  parent: sb
}

resource sbSubscription 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2024-01-01' = {
  name: 'telecom-demo-subscription'
  parent: sbTopic
  properties: {
    deadLetteringOnMessageExpiration: true
    lockDuration: 'PT5M'
    maxDeliveryCount: 10
  }
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: aiName
  location: location
  kind: 'web'
  properties: {
    Application_Type: 'web'
    IngestionMode: 'LogAnalytics'
  }
}

resource plan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: planName
  location: location
  sku: {
    name: 'FC1'
    tier: 'FlexConsumption'
  }
  kind: 'functionapp'
  properties: {
    reserved: true
  }
}

resource functionApp 'Microsoft.Web/sites@2023-12-01' = {
  name: functionAppName
  location: location
  kind: 'functionapp,linux'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: plan.id
    httpsOnly: true
    publicNetworkAccess: 'Enabled'
    siteConfig: {
      linuxFxVersion: 'Node|20'
      appSettings: [
        {
          name: 'FUNCTIONS_WORKER_RUNTIME'
          value: 'node'
        }
        {
          name: 'AzureWebJobsStorage'
          value: 'DefaultEndpointsProtocol=https;AccountName=${storage.name};EndpointSuffix=${environment().suffixes.storage};AccountKey=${storage.listKeys().keys[0].value}'
        }
        {
          name: 'APPLICATIONINSIGHTS_CONNECTION_STRING'
          value: appInsights.properties.ConnectionString
        }
        {
          name: 'COSMOS_ENDPOINT'
          value: cosmos.properties.documentEndpoint
        }
        {
          name: 'COSMOS_KEY'
          value: cosmos.listKeys().primaryMasterKey
        }
        {
          name: 'COSMOS_DATABASE'
          value: cosmosSqlDb.name
        }
        {
          name: 'COSMOS_ORDERS_CONTAINER'
          value: cosmosOrdersContainer.name
        }
        {
          name: 'COSMOS_PROMOTION_SUBSCRIPTIONS_CONTAINER'
          value: cosmosPromotionsContainer.name
        }
        {
          name: 'COSMOS_PAYMENTS_CONTAINER'
          value: cosmosPaymentsContainer.name
        }
        {
          name: 'USE_IN_MEMORY_REPOSITORY'
          value: 'false'
        }
      ]
    }
    functionAppConfig: {
      deployment: {
        storage: {
          type: 'blobContainer'
          value: 'https://${storage.name}.blob.${environment().suffixes.storage}/function-releases'
          authentication: {
            type: 'SystemAssignedIdentity'
          }
        }
      }
      runtime: {
        name: 'node'
        version: '20'
      }
      scaleAndConcurrency: {
        maximumInstanceCount: 40
      }
    }
  }
}

output functionAppName string = functionApp.name
output storageAccountName string = storage.name
output cosmosDbName string = cosmos.name
output serviceBusNamespace string = sb.name
