import { HttpRequest } from "@azure/functions";

export type DocumentUploadBody = {
  documents: Array<{
    type: "IdentityFront" | "IdentityBack" | "TaxCode";
    fileName: string;
    content: string;
  }>;
};

export function mapCreateSimCardOrderResponse(order: { id: string; status: string }) {
  return {
    orderId: order.id,
    status: order.status
  };
}

export function mapRequestPromotionSubscriptionResponse(subscription: {
  id: string;
  status: string;
}) {
  return {
    subscriptionId: subscription.id,
    status: subscription.status
  };
}

export function mapUploadCustomerDocumentsCommand(orderId: string, body: DocumentUploadBody) {
  return {
    orderId,
    documents: body.documents
  };
}

export function mapRequestActivationCommand(orderId: string) {
  return { orderId };
}

export function mapReviewActivationCommand(
  orderId: string,
  body: { approved: boolean; reason?: string }
) {
  return {
    orderId,
    approved: body.approved,
    reason: body.reason
  };
}

export function mapGenerateContractCommand(orderId: string) {
  return { orderId };
}

export function mapSendContractCommand(orderId: string, body: { channel?: "email" | "sms" }) {
  return {
    orderId,
    channel: body.channel ?? "email"
  };
}

export function mapProcessPromotionPaymentCommand(
  subscriptionId: string,
  body: { amount?: number }
) {
  return {
    subscriptionId,
    amount: body.amount
  };
}

export function mapActivatePromotionCommand(subscriptionId: string) {
  return { subscriptionId };
}

export function mapNotifyPromotionCustomerCommand(
  subscriptionId: string,
  body: { channels?: Array<"email" | "sms"> }
) {
  return {
    subscriptionId,
    channels: body.channels ?? ["email", "sms"]
  };
}

export function mapRouteParam(
  request: HttpRequest,
  paramName: string
): { ok: true; value: string } | { ok: false; error: string } {
  const value = request.params[paramName];
  if (!value) {
    return {
      ok: false,
      error: `${paramName} is required.`
    };
  }

  return {
    ok: true,
    value
  };
}
