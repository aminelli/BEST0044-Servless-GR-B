const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export class EmailAddress {
  private constructor(public readonly value: string) {}

  static create(raw: string): EmailAddress {
    const value = raw?.trim().toLowerCase();
    if (!value || !emailRegex.test(value)) {
      throw new Error("Invalid EmailAddress.");
    }

    return new EmailAddress(value);
  }
}
