import { PromotionSubscription } from "../../domain/promotionManagement/aggregates/promotionSubscriptionAggregate";
import { getContainer, isInMemoryRepositoryEnabled } from "./cosmosClient";

const subscriptions = new Map<string, PromotionSubscription>();

const SUBSCRIPTIONS_CONTAINER_ENV = "COSMOS_PROMOTION_SUBSCRIPTIONS_CONTAINER";

async function queryById(subscriptionId: string): Promise<PromotionSubscription | null> {
  const container = await getContainer(SUBSCRIPTIONS_CONTAINER_ENV);
  const query = {
    query: "SELECT TOP 1 * FROM c WHERE c.id = @id",
    parameters: [{ name: "@id", value: subscriptionId }]
  };
  const { resources } = await container.items.query<PromotionSubscription>(query).fetchAll();
  return resources[0] ?? null;
}

export const promotionSubscriptionRepository = {
  async upsert(subscription: PromotionSubscription): Promise<void> {
    if (isInMemoryRepositoryEnabled()) {
      subscriptions.set(subscription.id, subscription);
      return;
    }

    const container = await getContainer(SUBSCRIPTIONS_CONTAINER_ENV);
    await container.items.upsert(subscription);
  },
  async getById(subscriptionId: string): Promise<PromotionSubscription | null> {
    if (isInMemoryRepositoryEnabled()) {
      return subscriptions.get(subscriptionId) ?? null;
    }

    return queryById(subscriptionId);
  },
  async getByCustomer(customerId: string): Promise<PromotionSubscription[]> {
    if (isInMemoryRepositoryEnabled()) {
      return [...subscriptions.values()].filter((x) => x.customerId === customerId);
    }

    const container = await getContainer(SUBSCRIPTIONS_CONTAINER_ENV);
    const query = {
      query: "SELECT * FROM c WHERE c.customerId = @customerId",
      parameters: [{ name: "@customerId", value: customerId }]
    };
    const { resources } = await container.items.query<PromotionSubscription>(query).fetchAll();
    return resources;
  }
};
