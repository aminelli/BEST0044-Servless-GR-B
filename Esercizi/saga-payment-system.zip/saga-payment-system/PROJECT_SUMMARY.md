# Saga Payment System

## Descrizione Breve

Sistema serverless AWS che implementa il pattern Saga per gestire pagamenti digitali con transazioni distribuite e compensating transactions automatiche.

## Stack Tecnologico

- **AWS Lambda** (Python 3.9)
- **AWS Step Functions** (Orchestrazione Saga)
- **Amazon DynamoDB** (Persistenza)
- **Amazon API Gateway** (HTTP endpoint)
- **AWS SAM** (Infrastructure as Code)

## Quick Start

```bash
# Setup
python -m venv venv
source venv/bin/activate  # Windows: .\venv\Scripts\Activate.ps1
pip install -r requirements.txt

# Deploy
sam build
sam deploy --guided

# Test
curl -X POST <API_ENDPOINT> -H "Content-Type: application/json" \
  -d '{"customer_id":"cust-1","amount":"50.00","account_id":"acc-1","merchant_id":"merch-1"}'
```

## Documentazione

- [README.md](README.md) - Guida completa
- [ARCHITECTURE.md](docs/ARCHITECTURE.md) - Architettura dettagliata
- [DEPLOYMENT.md](docs/DEPLOYMENT.md) - Guida deployment

## Pattern Implementato

```
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│  Validate    │──▶│ Verify Funds │──▶│   Process    │
│  Payment     │   │              │   │   Payment    │
└──────────────┘   └──────┬───────┘   └──────┬───────┘
                          │                  │
                    [FAIL]│            [FAIL]│
                          ▼                  ▼
                   ┌─────────────┐    ┌─────────────┐
                   │ Compensate  │◀───│ Compensate  │
                   │   (Release) │    │  (Reverse)  │
                   └─────────────┘    └─────────────┘
```

## Features

✅ Pattern Saga orchestrato  
✅ Compensating transactions  
✅ Idempotenza  
✅ Retry automatico  
✅ Logging strutturato  
✅ Infrastructure as Code  
✅ Test suite completa  

## Autore

Progetto didattico per dimostrare il pattern Saga in ambiente serverless AWS.

## Licenza

MIT - Free to use for learning purposes
