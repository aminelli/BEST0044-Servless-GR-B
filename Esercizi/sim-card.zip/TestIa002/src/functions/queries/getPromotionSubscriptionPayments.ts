import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getPaymentsByPromotionSubscription } from "../../application/queryHandlers/paymentQueryHandler";
import { mapItemsResponse, mapPaymentQueryFilter, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetPromotionSubscriptionPayments", {
  methods: ["GET"],
  authLevel: "function",
  route: "promotions/subscriptions/{subscriptionId}/payments",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeSubscriptionId = mapRouteParam(request, "subscriptionId");
    if (!routeSubscriptionId.ok) {
      return badRequest(routeSubscriptionId.error);
    }

    const paymentFilter = mapPaymentQueryFilter(request);
    if (!paymentFilter.ok) {
      return badRequest(paymentFilter.error);
    }

    const items = await getPaymentsByPromotionSubscription(
      routeSubscriptionId.value,
      paymentFilter.value
    );
    return ok(mapItemsResponse(items));
  }
});
