import {
  RequestPromotionSubscriptionCommand,
  RequestPromotionSubscriptionCommandSchema
} from "../../domain/promotionManagement/commands/requestPromotionSubscriptionCommand";
import { PromotionSubscriptionEntity } from "../../domain/promotionManagement/entities/promotionSubscriptionEntity";
import { PromotionEvent } from "../../domain/promotionManagement/events/promotionEvents";
import { CustomerId } from "../../domain/promotionManagement/valueObjects/customerId";
import { PromotionId } from "../../domain/promotionManagement/valueObjects/promotionId";
import { SubscriptionId } from "../../domain/promotionManagement/valueObjects/subscriptionId";
import { getApplicationDependencies } from "../dependencies";
import { createEventMetadata, toUtcIsoTimestamp } from "../../shared/eventMetadata";
import { newId } from "../../shared/ids";

export async function requestPromotionSubscription(raw: unknown) {
  const deps = getApplicationDependencies();
  const command = RequestPromotionSubscriptionCommandSchema.parse(
    raw
  ) as RequestPromotionSubscriptionCommand;

  const subscriptionId = SubscriptionId.create(newId("promo"));
  const customerId = CustomerId.create(command.customerId);
  const promotionId = PromotionId.create(command.promotionId);
  const now = toUtcIsoTimestamp();
  const subscription = PromotionSubscriptionEntity.createNew({
    id: subscriptionId.value,
    customerId: customerId.value,
    promotionId: promotionId.value,
    nowUtc: now
  }).toPrimitives();

  await deps.promotionSubscriptionRepository.upsert(subscription);
  const event: PromotionEvent = {
    ...createEventMetadata(subscriptionId.value),
    subscriptionId: subscriptionId.value,
    type: "PromotionSubscriptionRequested",
    occurredAtUtc: now,
    payload: command
  };

  await deps.domainEventPublisher.publishDomainEvent(event);

  return subscription;
}
