import { EventMetadata, UtcIsoTimestamp } from "../../../shared/eventEnvelope";

export type PaymentEventType = "PaymentRequested" | "PaymentProcessed" | "PaymentRefunded" | "PaymentFailed";

export interface PaymentEvent extends EventMetadata {
  paymentId: string;
  type: PaymentEventType;
  occurredAtUtc: UtcIsoTimestamp;
  payload: Record<string, unknown>;
}
