"""
Eccezioni personalizzate per il sistema di pagamenti.
"""


class SagaError(Exception):
    """Eccezione base per errori della Saga."""
    pass


class PaymentValidationError(SagaError):
    """Errore durante la validazione del pagamento."""
    pass


class InsufficientFundsError(SagaError):
    """Errore per fondi insufficienti."""
    pass


class PaymentProcessingError(SagaError):
    """Errore durante il processamento del pagamento."""
    pass


class NotificationError(SagaError):
    """Errore durante l'invio della notifica."""
    pass


class RecordingError(SagaError):
    """Errore durante la registrazione della transazione."""
    pass


class IdempotencyError(SagaError):
    """Errore di idempotenza - operazione già eseguita."""
    pass
