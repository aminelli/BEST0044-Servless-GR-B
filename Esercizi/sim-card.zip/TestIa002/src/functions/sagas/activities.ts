import * as df from "durable-functions";
import {
  compensatePromotionStep,
  notifyCustomer,
  processPromotionPayment,
  activatePromotion
} from "../../application/commandHandlers/promotionLifecycleCommandHandler";
import {
  compensateSimCardOrderStep,
  generateContract,
  processSimPayment,
  requestActivation,
  sendContractToCustomer,
  uploadCustomerDocuments
} from "../../application/commandHandlers/simCardOrderLifecycleCommandHandler";

df.app.activity("SimOrderStepUploadDocuments", {
  handler: async (input: { orderId: string }) =>
    uploadCustomerDocuments({
      orderId: input.orderId,
      documents: [
        {
          type: "IdentityFront",
          fileName: "identity-front.txt",
          content: "identity-front-content"
        },
        {
          type: "IdentityBack",
          fileName: "identity-back.txt",
          content: "identity-back-content"
        },
        {
          type: "TaxCode",
          fileName: "tax-code.txt",
          content: "tax-code-content"
        }
      ]
    })
});

df.app.activity("SimOrderStepProcessPayment", {
  handler: async (input: { orderId: string }) =>
    processSimPayment({ orderId: input.orderId, amount: 10 })
});

df.app.activity("SimOrderStepRequestActivation", {
  handler: async (input: { orderId: string }) => requestActivation({ orderId: input.orderId })
});

df.app.activity("SimOrderStepGenerateContract", {
  handler: async (input: { orderId: string }) => generateContract({ orderId: input.orderId })
});

df.app.activity("SimOrderStepSendContract", {
  handler: async (input: { orderId: string }) =>
    sendContractToCustomer({ orderId: input.orderId, channel: "email" })
});

df.app.activity("SimOrderCompensation", {
  handler: async (input: { orderId: string; step: string }) => compensateSimCardOrderStep(input)
});

df.app.activity("PromoStepProcessPayment", {
  handler: async (input: { subscriptionId: string }) =>
    processPromotionPayment({ subscriptionId: input.subscriptionId, amount: 5 })
});

df.app.activity("PromoStepActivatePromotion", {
  handler: async (input: { subscriptionId: string }) =>
    activatePromotion({ subscriptionId: input.subscriptionId })
});

df.app.activity("PromoStepNotifyCustomer", {
  handler: async (input: { subscriptionId: string }) =>
    notifyCustomer({ subscriptionId: input.subscriptionId, channels: ["email", "sms"] })
});

df.app.activity("PromoCompensation", {
  handler: async (input: { subscriptionId: string; step: string }) => compensatePromotionStep(input)
});
