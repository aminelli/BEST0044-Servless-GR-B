# DOMAIN

## Aggregates

### SimCardOrder
Responsabile della consistenza transazionale dell'ordine SIM.

Stati principali:
- Created
- DocumentsUploaded
- PaymentProcessed
- ActivationRequested
- ActivationApproved / ActivationRejected
- ContractGenerated
- ContractSent

### PromotionSubscription
Responsabile della consistenza dell'adesione promozione.

Stati principali:
- Requested
- PaymentProcessed
- Activated
- Notified

## Domain Events

Tutti gli eventi del dominio usano un envelope comune:

- eventId: identificatore univoco evento
- correlationId: id di correlazione end-to-end della transazione
- causationId (opzionale): evento/comando che ha causato quello corrente
- version: versione del contratto evento (attuale: 1)
- occurredAtUtc: timestamp UTC in formato ISO 8601 (es: 2026-04-30T10:15:00.000Z)

SalesOrder events:
- SimCardOrderCreated
- CustomerDocumentsUploaded
- PaymentProcessed
- ActivationRequested
- ActivationApproved / ActivationRejected
- ContractGenerated
- ContractSentToCustomer

Promotion events:
- PromotionSubscriptionRequested
- PaymentProcessed
- PromotionActivated
- CustomerNotified

Schema logico evento (valido per tutti i bounded context):

{
	"eventId": "evt-...",
	"correlationId": "corr-...",
	"causationId": "cmd-...",
	"version": 1,
	"type": "EventType",
	"occurredAtUtc": "2026-04-30T10:15:00.000Z",
	"payload": {}
}

## Value Objects

SalesOrder:
- OrderId
- CustomerId
- EmailAddress
- PhoneNumber
- DocumentReference
- Money

PromotionManagement:
- SubscriptionId
- CustomerId
- PromotionId

Payments:
- PaymentId
- Money (riusato)

I command handler applicano questi Value Object per validare invarianti dominio e ridurre primitive obsession.

## Entities

SalesOrder:
- SimCardOrderEntity (gestione transizioni stato e documenti ordine)

PromotionManagement:
- PromotionSubscriptionEntity (gestione transizioni stato sottoscrizione)

Payments:
- PaymentTransactionEntity (gestione ciclo pagamento Requested -> Processed -> Refunded)

## Tabelle/Container di Dominio (Cosmos)

- orders
- promotion-subscriptions
- payments

## Business Rules (iniziali)

- Un ordine SIM deve avere customer e piano validi.
- Una promozione deve essere richiesta con customerId e promotionId validi.
- Le transizioni multi-step vanno orchestrate dalla Saga con compensazioni.
