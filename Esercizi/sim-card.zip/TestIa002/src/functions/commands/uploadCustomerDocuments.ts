import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { uploadCustomerDocuments } from "../../application/commandHandlers/simCardOrderLifecycleCommandHandler";
import { mapRouteParam, mapUploadCustomerDocumentsCommand } from "../mappers/commandHttpMapper";
import { badRequest, accepted, readJsonBody } from "../../shared/http";

app.http("UploadCustomerDocuments", {
  methods: ["POST"],
  authLevel: "function",
  route: "orders/{orderId}/documents",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeOrderId = mapRouteParam(request, "orderId");
      if (!routeOrderId.ok) {
        return badRequest(routeOrderId.error);
      }

      const body = await readJsonBody<{ documents: Array<{ type: "IdentityFront" | "IdentityBack" | "TaxCode"; fileName: string; content: string }> }>(request);
      const result = await uploadCustomerDocuments(
        mapUploadCustomerDocumentsCommand(routeOrderId.value, body)
      );

      return accepted(result);
    } catch (error) {
      context.error("UploadCustomerDocuments failed", error);
      return badRequest("Invalid document upload payload.");
    }
  }
});
