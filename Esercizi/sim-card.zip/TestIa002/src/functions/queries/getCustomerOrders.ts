import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getSimCardOrdersByCustomer } from "../../application/queryHandlers/simCardOrderQueryHandler";
import { mapItemsResponse, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetCustomerOrders", {
  methods: ["GET"],
  authLevel: "function",
  route: "customers/{customerId}/orders",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeCustomerId = mapRouteParam(request, "customerId");
    if (!routeCustomerId.ok) {
      return badRequest(routeCustomerId.error);
    }

    const customerId = routeCustomerId.value;

    const orders = await getSimCardOrdersByCustomer(customerId);
    return ok(mapItemsResponse(orders));
  }
});
