import {
  PromotionSubscription,
  PromotionSubscriptionStatus
} from "../aggregates/promotionSubscriptionAggregate";

export class PromotionSubscriptionEntity {
  private constructor(private readonly state: PromotionSubscription) {}

  static createNew(params: {
    id: string;
    customerId: string;
    promotionId: string;
    nowUtc: string;
  }): PromotionSubscriptionEntity {
    return new PromotionSubscriptionEntity({
      id: params.id,
      customerId: params.customerId,
      promotionId: params.promotionId,
      status: "Requested",
      createdAt: params.nowUtc,
      updatedAt: params.nowUtc
    });
  }

  static rehydrate(raw: PromotionSubscription): PromotionSubscriptionEntity {
    return new PromotionSubscriptionEntity({ ...raw });
  }

  get id(): string {
    return this.state.id;
  }

  get status(): PromotionSubscriptionStatus {
    return this.state.status;
  }

  transition(to: PromotionSubscriptionStatus, nowUtc: string): void {
    this.state.status = to;
    this.state.updatedAt = nowUtc;
  }

  toPrimitives(): PromotionSubscription {
    return { ...this.state };
  }
}
