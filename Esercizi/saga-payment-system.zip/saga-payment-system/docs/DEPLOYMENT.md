# Guida Deployment Completa

Guida dettagliata passo-passo per il deployment del Saga Payment System su AWS.

## Indice

- [Prerequisiti](#prerequisiti)
- [Setup Ambiente Locale](#setup-ambiente-locale)
- [Build del Progetto](#build-del-progetto)
- [Deploy su AWS](#deploy-su-aws)
- [Verifica Deployment](#verifica-deployment)
- [Testing Post-Deploy](#testing-post-deploy)
- [Monitoring](#monitoring)
- [Update e Rollback](#update-e-rollback)
- [Cleanup](#cleanup)
- [Troubleshooting](#troubleshooting)

## Prerequisiti

### 1. Installazione AWS CLI

**Windows:**
```powershell
# Download installer MSI da:
# https://awscli.amazonaws.com/AWSCLIV2.msi

# Verifica installazione
aws --version
# Output atteso: aws-cli/2.x.x Python/3.x.x Windows/x
```

**Linux:**
```bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Verifica
aws --version
```

**macOS:**
```bash
brew install awscli

# Oppure:
curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o "AWSCLIV2.pkg"
sudo installer -pkg AWSCLIV2.pkg -target /

# Verifica
aws --version
```

### 2. Configurazione AWS CLI

```bash
# Configura credenziali (ti chiederà Access Key ID e Secret Access Key)
aws configure

# Input richiesti:
# AWS Access Key ID [None]: YOUR_ACCESS_KEY
# AWS Secret Access Key [None]: YOUR_SECRET_KEY
# Default region name [None]: eu-west-1
# Default output format [None]: json

# Verifica configurazione
aws sts get-caller-identity
# Output mostra Account ID, User ARN
```

**Creazione Access Keys:**
1. AWS Console → IAM → Users → Il tuo utente
2. Security credentials → Create access key
3. Scegli "CLI" use case
4. Copia Access Key ID e Secret Access Key

### 3. Installazione AWS SAM CLI

**Windows (via installer):**
```powershell
# Download da:
# https://github.com/aws/aws-sam-cli/releases/latest/download/AWS_SAM_CLI_64_PY3.msi

# Verifica
sam --version
```

**Windows (via Chocolatey):**
```powershell
choco install aws-sam-cli

sam --version
```

**Linux:**
```bash
# Scarica installer
wget https://github.com/aws/aws-sam-cli/releases/latest/download/aws-sam-cli-linux-x86_64.zip
unzip aws-sam-cli-linux-x86_64.zip -d sam-installation

# Installa
sudo ./sam-installation/install

# Verifica
sam --version
```

**macOS:**
```bash
brew tap aws/tap
brew install aws-sam-cli

sam --version
```

### 4. Installazione Python 3.9+

**Windows:**
```powershell
# Download da python.org oppure:
choco install python39

# Verifica
python --version
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install python3.9 python3.9-venv python3-pip

python3.9 --version
```

**macOS:**
```bash
brew install python@3.9

python3.9 --version
```

## Setup Ambiente Locale

### 1. Clone del Repository

```bash
# Se usando Git
git clone <repository-url>
cd saga-payment-system

# Oppure scarica e estrai ZIP
cd saga-payment-system
```

### 2. Creazione Virtual Environment

**Windows (PowerShell):**
```powershell
# Crea venv
python -m venv venv

# Attiva venv
.\venv\Scripts\Activate.ps1

# Se errore "script disabled", abilita execution:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Poi riprova
.\venv\Scripts\Activate.ps1

# Verifica (prompt mostrerà (venv))
(venv) PS C:\...\saga-payment-system>
```

**Windows (CMD):**
```cmd
python -m venv venv
venv\Scripts\activate.bat
```

**Linux/macOS:**
```bash
# Crea venv
python3 -m venv venv

# Attiva venv
source venv/bin/activate

# Verifica
(venv) user@host:~/saga-payment-system$
```

### 3. Installazione Dipendenze

```bash
# Aggiorna pip
python -m pip install --upgrade pip

# Installa dipendenze
pip install -r requirements.txt

# Verifica installazione boto3
python -c "import boto3; print(boto3.__version__)"
```

### 4. Configurazione Variabili d'Ambiente

```bash
# Copia template
cp .env.example .env

# Modifica .env (opzionale per test locali)
# Per deploy AWS, le variabili sono gestite da SAM template
```

## Build del Progetto

### 1. Validazione Template SAM

```bash
# Valida sintassi template
sam validate --template infrastructure/template.yaml

# Output atteso:
# infrastructure/template.yaml is a valid SAM Template
```

**Troubleshooting validazione:**
```bash
# Se errore di sintassi YAML
# Usa un validatore YAML online o:
python -c "import yaml; yaml.safe_load(open('infrastructure/template.yaml'))"

# Se errore CloudFormation
# Verifica che le risorse abbiano Type corretti
# Verifica che i !Ref riferiscano risorse esistenti
```

### 2. Build SAM

```bash
# Build del progetto
sam build --template infrastructure/template.yaml

# Output:
# Building codeuri: /path/to/saga-payment-system/src/lambdas runtime: python3.9
# ...
# Build Succeeded

# Build artifacts in: .aws-sam/build/
```

**Build con Docker (per dipendenze native):**
```bash
# Se hai dipendenze che richiedono compilazione nativa
sam build --use-container
```

**Verifica build:**
```bash
# Controlla directory build
ls -la .aws-sam/build/

# Dovresti vedere:
# - template.yaml (processed)
# - ValidatePaymentFunction/
# - VerifyFundsFunction/
# - ...
```

## Deploy su AWS

### Deploy Guidato (Prima Volta)

```bash
# Deploy interattivo
sam deploy --guided

# Rispondi alle domande:
```

**Domande e risposte suggerite:**

```
Stack Name [sam-app]: saga-payment-system-dev
AWS Region [eu-west-1]: eu-west-1  # o la tua region preferita
Parameter Environment [dev]: dev

# Confirm changes before deploy? [Y/n]: Y
# Allow SAM CLI IAM role creation? [Y/n]: Y
# Disable rollback [y/N]: N
# Save arguments to configuration file? [Y/n]: Y
# SAM configuration file [samconfig.toml]: samconfig.toml
# SAM configuration environment [default]: default

# Deploy questo changeset? [y/N]: y
```

**Deploy in corso:**
```
Deploying with following values
===============================
Stack name                   : saga-payment-system-dev
Region                       : eu-west-1
Confirm changeset            : True
Disable rollback             : False
Deployment s3 bucket         : aws-sam-cli-managed-default-samclisourcebucket-xxx
Capabilities                 : ["CAPABILITY_IAM"]
Parameter overrides          : {"Environment": "dev"}
Signing Profiles             : {}

Initiating deployment
=====================
...
CloudFormation stack changeset
...
Successfully created/updated stack - saga-payment-system-dev in eu-west-1
```

### Deploy Successivi (Automatico)

Dopo il primo deploy guidato, `samconfig.toml` viene creato:

```bash
# Deploy automatico (usa config salvata)
sam build
sam deploy

# Oppure in un solo comando
sam build && sam deploy
```

### Deploy con Parametri Custom

```bash
# Override parametri
sam deploy --parameter-overrides Environment=staging

# Deploy in region diversa
sam deploy --region us-east-1

# Deploy con stack name custom
sam deploy --stack-name my-custom-stack-name
```

### Deploy Multi-Environment

**Development:**
```bash
sam deploy --parameter-overrides Environment=dev --stack-name saga-payment-dev
```

**Staging:**
```bash
sam deploy --parameter-overrides Environment=staging --stack-name saga-payment-staging
```

**Production:**
```bash
sam deploy --parameter-overrides Environment=prod --stack-name saga-payment-prod --no-confirm-changeset
```

## Verifica Deployment

### 1. Verifica Stack CloudFormation

```bash
# Descrivi stack
aws cloudformation describe-stacks \
  --stack-name saga-payment-system-dev

# Output JSON con status, outputs, etc.

# Verifica status
aws cloudformation describe-stacks \
  --stack-name saga-payment-system-dev \
  --query 'Stacks[0].StackStatus' \
  --output text

# Output atteso: CREATE_COMPLETE o UPDATE_COMPLETE
```

### 2. Recupera Outputs

```bash
# Lista tutti gli outputs
aws cloudformation describe-stacks \
  --stack-name saga-payment-system-dev \
  --query 'Stacks[0].Outputs' \
  --output table

# Output:
# --------------------------------------------------------------------------------------------------------
# |                                              DescribeStacks                                          |
# +----------------------+-------------------+--------------------------------------------------------------+
# |    Description       |   OutputKey       |                   OutputValue                                |
# +----------------------+-------------------+--------------------------------------------------------------+
# |  API Endpoint        |  ApiEndpoint      |  https://xxx.execute-api.eu-west-1.amazonaws.com/dev/payments|
# |  State Machine ARN   |  StateMachineArn  |  arn:aws:states:eu-west-1:123456:stateMachine:PaymentSaga-dev|
# +----------------------+-------------------+--------------------------------------------------------------+
```

**Salva outputs in variabili:**
```bash
# API Endpoint
export API_ENDPOINT=$(aws cloudformation describe-stacks \
  --stack-name saga-payment-system-dev \
  --query 'Stacks[0].Outputs[?OutputKey==`ApiEndpoint`].OutputValue' \
  --output text)

echo $API_ENDPOINT

# State Machine ARN
export STATE_MACHINE_ARN=$(aws cloudformation describe-stacks \
  --stack-name saga-payment-system-dev \
  --query 'Stacks[0].Outputs[?OutputKey==`StateMachineArn`].OutputValue' \
  --output text)

echo $STATE_MACHINE_ARN
```

### 3. Verifica Risorse Create

**Lambda Functions:**
```bash
# Lista funzioni Lambda del progetto
aws lambda list-functions \
  --query 'Functions[?starts_with(FunctionName, `saga-`)].FunctionName' \
  --output table

# Verifica una funzione specifica
aws lambda get-function --function-name saga-validate-payment-dev
```

**DynamoDB Tables:**
```bash
# Lista tabelle
aws dynamodb list-tables \
  --query 'TableNames[?contains(@, `Saga`)]' \
  --output table

# Descrivi tabella Payments
aws dynamodb describe-table --table-name SagaPayments-dev

# Descrivi tabella SagaStates
aws dynamodb describe-table --table-name SagaStates-dev
```

**Step Functions:**
```bash
# Lista state machines
aws stepfunctions list-state-machines \
  --query 'stateMachines[?starts_with(name, `PaymentSaga`)].{Name:name, ARN:stateMachineArn}' \
  --output table
```

## Testing Post-Deploy

### 1. Test API con curl

**Pagamento valido (successo):**
```bash
curl -X POST $API_ENDPOINT \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": "cust-test-001",
    "amount": "99.99",
    "currency": "EUR",
    "account_id": "acc-normal-123",
    "merchant_id": "merch-test-001",
    "idempotency_key": "test-'"$(date +%s)"'"
  }'

# Output:
# {"payment_id":"uuid-xxx","execution_arn":"arn:...","status":"PROCESSING"}
```

**Salva payment_id:**
```bash
PAYMENT_ID=$(curl -s -X POST $API_ENDPOINT \
  -H "Content-Type: application/json" \
  -d '{"customer_id":"cust-001","amount":"50.00","account_id":"acc-123","merchant_id":"merch-001"}' \
  | jq -r '.payment_id')

echo "Payment ID: $PAYMENT_ID"
```

**Test fondi insufficienti:**
```bash
curl -X POST $API_ENDPOINT \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id": "cust-002",
    "amount": "5000.00",
    "account_id": "LOW_acc-456",
    "merchant_id": "merch-001"
  }'
```

### 2. Monitorare Esecuzione Step Functions

```bash
# Lista ultime esecuzioni
aws stepfunctions list-executions \
  --state-machine-arn $STATE_MACHINE_ARN \
  --max-results 10 \
  --output table

# Descrivi esecuzione specifica
EXECUTION_ARN="arn:aws:states:...:execution:PaymentSaga-dev:payment-xxx"

aws stepfunctions describe-execution \
  --execution-arn $EXECUTION_ARN

# Visualizza history
aws stepfunctions get-execution-history \
  --execution-arn $EXECUTION_ARN \
  --output json | jq '.events[] | {id:.id, type:.type, timestamp:.timestamp}'
```

### 3. Query DynamoDB

**Verifica pagamento creato:**
```bash
aws dynamodb get-item \
  --table-name SagaPayments-dev \
  --key '{"payment_id": {"S": "'"$PAYMENT_ID"'"}}' \
  --output json | jq '.Item'
```

**Verifica stato Saga:**
```bash
aws dynamodb get-item \
  --table-name SagaStates-dev \
  --key '{"saga_id": {"S": "'"$PAYMENT_ID"'"}}' \
  --output json | jq '.Item'
```

**Scan tutti i pagamenti (attenzione: costoso se molti record):**
```bash
aws dynamodb scan \
  --table-name SagaPayments-dev \
  --max-items 10 \
  --output table
```

### 4. Visualizza Logs CloudWatch

```bash
# Lista log groups
aws logs describe-log-groups \
  --log-group-name-prefix /aws/lambda/saga- \
  --query 'logGroups[].logGroupName' \
  --output table

# Tail logs di una funzione (ultimi 10 minuti)
aws logs tail /aws/lambda/saga-validate-payment-dev --follow

# Logs Step Functions
aws logs tail /aws/stepfunctions/PaymentSaga-dev --follow
```

**Query CloudWatch Insights:**
```bash
# Cerca errori nelle ultime 1 ora
aws logs start-query \
  --log-group-name /aws/lambda/saga-validate-payment-dev \
  --start-time $(date -u -d '1 hour ago' +%s) \
  --end-time $(date -u +%s) \
  --query-string 'fields @timestamp, @message | filter @message like /ERROR/ | sort @timestamp desc'
```

## Monitoring

### CloudWatch Dashboard (Manuale via Console)

1. AWS Console → CloudWatch → Dashboards → Create dashboard
2. Add widgets:
   - **Lambda Invocations** (metric: Invocations)
   - **Lambda Errors** (metric: Errors)
   - **Step Functions Executions** (metric: ExecutionsStarted, ExecutionsSucceeded, ExecutionsFailed)
   - **DynamoDB Throttles** (metric: SystemErrors)

### CloudWatch Alarms (CLI)

```bash
# Alarm per esecuzioni Step Functions fallite
aws cloudwatch put-metric-alarm \
  --alarm-name saga-payment-failures \
  --alarm-description "Alert on Saga failures" \
  --metric-name ExecutionsFailed \
  --namespace AWS/States \
  --statistic Sum \
  --period 300 \
  --evaluation-periods 1 \
  --threshold 1 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --dimensions Name=StateMachineArn,Value=$STATE_MACHINE_ARN

# Alarm per errori Lambda
aws cloudwatch put-metric-alarm \
  --alarm-name saga-lambda-errors \
  --metric-name Errors \
  --namespace AWS/Lambda \
  --statistic Sum \
  --period 300 \
  --evaluation-periods 1 \
  --threshold 5 \
  --comparison-operator GreaterThanThreshold
```

## Update e Rollback

### Update Stack

```bash
# Dopo modifiche al codice o template
sam build
sam deploy

# CloudFormation creerà un changeset e chiederà conferma
# Changeset preview:
# +-----------------------------------+
# | Resource                  | Action|
# +-----------------------------------+
# | ValidatePaymentFunction   | Update|
# | ...                              |
# +-----------------------------------+

# Deploy this changeset? [y/N]: y
```

### Rollback Manuale

```bash
# Lista stacks per vedere versioni precedenti
aws cloudformation list-stacks \
  --stack-status-filter UPDATE_COMPLETE \
  --query 'StackSummaries[?starts_with(StackName, `saga-payment`)].{Name:StackName,Time:LastUpdatedTime}' \
  --output table

# Se deploy ha causato problemi, rollback all'ultimo stato stabile
aws cloudformation cancel-update-stack --stack-name saga-payment-system-dev

# Oppure elimina e redeploy versione precedente
sam delete --stack-name saga-payment-system-dev --no-prompts
# Poi redeploy da commit precedente
```

### Verifica Changeset Prima del Deploy

```bash
# Crea changeset senza deployare
sam deploy --no-execute-changeset

# Visualizza changeset via console o:
CHANGESET_NAME=$(aws cloudformation list-change-sets \
  --stack-name saga-payment-system-dev \
  --query 'Summaries[0].ChangeSetName' \
  --output text)

aws cloudformation describe-change-set \
  --change-set-name $CHANGESET_NAME \
  --stack-name saga-payment-system-dev

# Esegui se OK
aws cloudformation execute-change-set \
  --change-set-name $CHANGESET_NAME \
  --stack-name saga-payment-system-dev
```

## Cleanup

### Eliminazione Stack Completo

```bash
# Elimina stack (rimuove tutte le risorse)
sam delete --stack-name saga-payment-system-dev

# Conferma:
# Are you sure you want to delete the stack saga-payment-system-dev in the region eu-west-1 ? [y/N]: y
# Are you sure you want to delete the folder saga-payment-system-dev in S3 which contains the artifacts? [y/N]: y

# Verifica eliminazione
aws cloudformation describe-stacks --stack-name saga-payment-system-dev
# Output: Stack with id saga-payment-system-dev does not exist (OK)
```

**Nota:** Le tabelle DynamoDB con `DeletionPolicy: Retain` potrebbero rimanere - eliminale manualmente se necessario:

```bash
# Verifica tabelle rimaste
aws dynamodb list-tables | grep Saga

# Elimina tabelle manualmente
aws dynamodb delete-table --table-name SagaPayments-dev
aws dynamodb delete-table --table-name SagaStates-dev
```

### Cleanup File Locali

```bash
# Rimuovi artifacts build
rm -rf .aws-sam/

# Rimuovi cache Python
find . -type d -name __pycache__ -exec rm -rf {} +
find . -type f -name "*.pyc" -delete

# Oppure usa Make
make clean
```

## Troubleshooting

### Errore: "Unable to upload artifact"

**Causa:** Bucket S3 per artifacts non accessibile

**Soluzione:**
```bash
# Crea bucket manualmente
aws s3 mb s3://my-sam-artifacts-bucket --region eu-west-1

# Deploy specificando bucket
sam deploy --s3-bucket my-sam-artifacts-bucket
```

### Errore: "No changes to deploy"

**Causa:** Template/codice non modificati

**Soluzione:**
```bash
# Force deploy
sam deploy --force-upload
```

### Errore: "ValidationError: Stack is in UPDATE_ROLLBACK_FAILED"

**Causa:** Precedente update fallito

**Soluzione:**
```bash
# Continua rollback
aws cloudformation continue-update-rollback --stack-name saga-payment-system-dev

# Oppure elimina e redeploy
sam delete --stack-name saga-payment-system-dev --no-prompts
sam deploy
```

### Lambda Timeout

**Causa:** Funzione richiede più di 30 secondi

**Soluzione:** Aumenta timeout in `template.yaml`:
```yaml
Globals:
  Function:
    Timeout: 60  # aumenta a 60 secondi
```

### DynamoDB Throttling

**Verifica:**
```bash
aws cloudwatch get-metric-statistics \
  --namespace AWS/DynamoDB \
  --metric-name SystemErrors \
  --dimensions Name=TableName,Value=SagaPayments-dev \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Sum
```

**Soluzione:** Passa a Provisioned Capacity o aumenta On-Demand limits

### Step Functions Execution Failed

**Debug:**
```bash
# Visualizza execution nella console
# Oppure via CLI:
aws stepfunctions describe-execution --execution-arn $EXECUTION_ARN \
  | jq '.cause,.error,.status'

# Visualizza history per vedere dove è fallito
aws stepfunctions get-execution-history --execution-arn $EXECUTION_ARN \
  | jq '.events[] | select(.type | contains("Failed"))'
```

---

## Riepilogo Comandi Essenziali

```bash
# Setup iniziale
python -m venv venv
source venv/bin/activate  # o .\venv\Scripts\Activate.ps1 su Windows
pip install -r requirements.txt

# Build e deploy
sam build
sam deploy --guided  # prima volta
sam deploy           # successive

# Recupera info
aws cloudformation describe-stacks --stack-name saga-payment-system-dev

# Test
curl -X POST $API_ENDPOINT -H "Content-Type: application/json" -d '{...}'

# Logs
aws logs tail /aws/lambda/saga-validate-payment-dev --follow

# Cleanup
sam delete --stack-name saga-payment-system-dev
```

---

**Con questa guida dovresti essere in grado di deployare e gestire il Saga Payment System end-to-end! 🚀**
