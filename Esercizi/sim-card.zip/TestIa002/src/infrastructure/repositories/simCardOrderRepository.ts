import { SimCardOrder } from "../../domain/salesOrder/aggregates/simCardOrderAggregate";
import { getContainer, isInMemoryRepositoryEnabled } from "./cosmosClient";

const orders = new Map<string, SimCardOrder>();

const ORDERS_CONTAINER_ENV = "COSMOS_ORDERS_CONTAINER";

async function queryById(orderId: string): Promise<SimCardOrder | null> {
  const container = await getContainer(ORDERS_CONTAINER_ENV);
  const query = {
    query: "SELECT TOP 1 * FROM c WHERE c.id = @id",
    parameters: [{ name: "@id", value: orderId }]
  };
  const { resources } = await container.items.query<SimCardOrder>(query).fetchAll();
  return resources[0] ?? null;
}

export const simCardOrderRepository = {
  async upsert(order: SimCardOrder): Promise<void> {
    if (isInMemoryRepositoryEnabled()) {
      orders.set(order.id, order);
      return;
    }

    const container = await getContainer(ORDERS_CONTAINER_ENV);
    await container.items.upsert(order);
  },
  async getById(orderId: string): Promise<SimCardOrder | null> {
    if (isInMemoryRepositoryEnabled()) {
      return orders.get(orderId) ?? null;
    }

    return queryById(orderId);
  },
  async getByCustomer(customerId: string): Promise<SimCardOrder[]> {
    if (isInMemoryRepositoryEnabled()) {
      return [...orders.values()].filter((x) => x.customerId === customerId);
    }

    const container = await getContainer(ORDERS_CONTAINER_ENV);
    const query = {
      query: "SELECT * FROM c WHERE c.customerId = @customerId",
      parameters: [{ name: "@customerId", value: customerId }]
    };
    const { resources } = await container.items.query<SimCardOrder>(query).fetchAll();
    return resources;
  },
  async getTransitions(orderId: string) {
    const order = isInMemoryRepositoryEnabled() ? orders.get(orderId) : await queryById(orderId);
    return order?.transitions ?? [];
  },
  async getDocuments(orderId: string) {
    const order = isInMemoryRepositoryEnabled() ? orders.get(orderId) : await queryById(orderId);
    return order?.documents ?? [];
  }
};
