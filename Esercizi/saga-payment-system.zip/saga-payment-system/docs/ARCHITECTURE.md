# Architettura del Sistema

Documentazione dettagliata dell'architettura del Saga Payment System.

## Indice

- [Pattern Saga](#pattern-saga)
- [Approccio Implementato](#approccio-implementato)
- [Componenti dell'Architettura](#componenti-dellarchitettura)
- [Flusso di Esecuzione](#flusso-di-esecuzione)
- [Compensating Transactions](#compensating-transactions)
- [Gestione degli Errori](#gestione-degli-errori)
- [Idempotenza](#idempotenza)
- [Decision Log](#decision-log)

## Pattern Saga

### Definizione

Il **pattern Saga** è un design pattern per gestire transazioni distribuite in architetture a microservizi. Una Saga è una sequenza di transazioni locali, dove ciascuna transazione aggiorna un singolo servizio e pubblica eventi che triggera la prossima transazione locale.

### Perché Utilizzare il Pattern Saga?

In architetture distribuite e serverless:

1. **Non esiste transazione ACID globale**: Ogni servizio ha il proprio database
2. **2PC (Two-Phase Commit) non è pratico**: Richiede lock prolungati e non scala
3. **Eventual consistency è accettabile**: Per molti casi d'uso business

### Tipi di Saga

#### 1. Orchestrazione (Implementato in questo progetto)

Un orchestratore centrale coordina tutti gli step della Saga:

**Vantaggi:**
- ✅ Centralizzazione della logica di business
- ✅ Facile da debuggare e monitorare
- ✅ Chiara visualizzazione del flusso
- ✅ Gestione errori centralizzata

**Svantaggi:**
- ❌ Single point of failure (orchestratore)
- ❌ Coupling con l'orchestratore

#### 2. Coreografia (Non implementato)

Ogni servizio pubblica eventi che triggera il prossimo servizio:

**Vantaggi:**
- ✅ Decoupling completo tra servizi
- ✅ No single point of failure

**Svantaggi:**
- ❌ Logica distribuita difficile da comprendere
- ❌ Difficile da debuggare
- ❌ Complessità ciclomatica

## Approccio Implementato

### Orchestrazione con AWS Step Functions

Abbiamo scelto l'approccio orchestrato utilizzando **AWS Step Functions** come orchestratore centrale perché:

1. **Visualizzazione grafica** del flusso in AWS Console
2. **Retry automatico** configurabile
3. **Error handling** dichiarativo
4. **Logging e tracing** integrati
5. **Bassi costi** con Free Tier generoso

### State Machine

La state machine Step Functions definisce:

```
START
  ↓
Initialize Saga State
  ↓
Validate Payment
  ↓
Verify Funds ──────────[FAIL]──→ Compensate Verify Funds ──→ ROLLBACK
  ↓
Process Payment ───────[FAIL]──→ Compensate Process Payment
  ↓                               ↓
Notify Customer                Compensate Verify Funds ──→ ROLLBACK
  ↓
Record Transaction ────[FAIL]──→ CRITICAL ERROR (manual intervention)
  ↓
Mark Saga Completed
  ↓
SUCCESS
```

## Componenti dell'Architettura

### 1. API Gateway + Initiate Payment Lambda

**Responsabilità:**
- Riceve richieste HTTP dai client
- Valida input di base
- Crea record iniziale in DynamoDB (Payment e SagaState)
- Avvia l'esecuzione Step Functions
- Ritorna payment_id al client

**Pattern:** API Gateway → Lambda → Step Functions (fire-and-forget)

### 2. Step Functions State Machine

**Responsabilità:**
- Orchestrazione degli step della Saga
- Gestione retry automatici
- Invocazione Lambda functions
- Routing in caso di errori
- Aggiornamento stato Saga in DynamoDB

**Configurazione Retry:**
- `IntervalSeconds`: 1-2 secondi
- `MaxAttempts`: 2-3 tentativi
- `BackoffRate`: 1.5-2.0 (exponential backoff)

### 3. Lambda Functions - Forward Path

#### validate_payment.py

**Input:**
```json
{
  "payment": {
    "payment_id": "uuid",
    "customer_id": "cust-123",
    "amount": "100.00",
    "account_id": "acc-456",
    "merchant_id": "merch-789"
  }
}
```

**Validazioni:**
- payment_id non vuoto
- amount > 0
- customer_id presente
- merchant_id presente
- account_id o card_number presente

**Output:** Evento arricchito con `validation_result`

#### verify_funds.py

**Responsabilità:**
- Simula chiamata a servizio bancario
- Verifica saldo disponibile
- Crea "hold" sui fondi (prenotazione)

**Output:** Aggiunge `reservation_id` all'evento (necessario per compensazione)

**Logica di Simulazione:**
- Account normali: saldo €1000
- Account "LOW_": saldo €10
- Account "ZERO_": saldo €0

#### process_payment.py

**Responsabilità:**
- Converte hold in addebito effettivo
- Simula trasferimento fondi al merchant
- Genera transaction_id

**Output:** Aggiunge `transaction_id` all'evento

**Logica di Simulazione:**
- Merchant "FAIL_": simula errore processamento
- Altri merchant: successo

#### notify_customer.py

**Responsabilità:**
- Invia notifica di successo al cliente
- In produzione: SNS, SES, o servizio terzo

**Peculiarità:** Errori qui sono **non-critical** - non dovrebbero causare rollback del pagamento già processato

#### record_transaction.py

**Responsabilità:**
- Crea record audit permanente
- Aggiorna stato pagamento a COMPLETED

**Importanza:** Errori qui sono **CRITICAL** - il pagamento è processato ma non registrato, richiede intervento manuale

### 4. Lambda Functions - Compensating Path

#### compensate_verify_funds.py

**Compensazione per:** verify_funds

**Azioni:**
- Rilascia l'hold sui fondi usando `reservation_id`
- Rende i fondi nuovamente disponibili

**Idempotenza:** Se non esiste `reservation_id`, skip

#### compensate_process_payment.py

**Compensazione per:** process_payment

**Azioni:**
- Storna il pagamento usando `transaction_id`
- Riaccredita il customer
- Addebita il merchant

**Criticità:** Se fallisce, richiede intervento manuale urgente

### 5. DynamoDB Tables

#### PaymentsTable

**Schema:**
```
Primary Key: payment_id (String)
GSI: customer_id-index
```

**Attributi:**
- payment_id, customer_id, merchant_id
- amount, currency
- account_id, card_number (masked)
- status (PENDING, VALIDATED, PROCESSED, COMPLETED, FAILED, ROLLED_BACK)
- created_at, updated_at
- error_message
- idempotency_key

**Features:**
- Streams abilitati per event sourcing
- Point-in-time recovery
- On-demand billing

#### SagaStateTable

**Schema:**
```
Primary Key: saga_id (String)
GSI: payment_id-index
```

**Attributi:**
- saga_id (= payment_id)
- payment_id
- status (STARTED, IN_PROGRESS, COMPLETED, COMPENSATING, FAILED, ROLLED_BACK)
- current_step
- completed_steps[] 
- compensated_steps[]
- error_message
- started_at, updated_at
- retry_count

**TTL:** Abilitato per pulizia automatica dopo X giorni

## Flusso di Esecuzione

### Scenario 1: Successo Completo

```
1. Client POST /payments
2. InitiatePayment Lambda
   - Crea Payment (status=PENDING)
   - Crea SagaState (status=STARTED)
   - StartExecution Step Functions
   - Ritorna 202 Accepted
3. Step Functions inizia
   - UpdateSagaState (status=IN_PROGRESS)
4. ValidatePayment
   - Valida dati
   - UpdatePayment (status=VALIDATED)
5. VerifyFunds
   - Verifica saldo
   - Crea hold
   - UpdatePayment (status=FUNDS_VERIFIED)
   - Aggiunge reservation_id
6. ProcessPayment
   - Processa pagamento
   - UpdatePayment (status=PROCESSED)
   - Aggiunge transaction_id
7. NotifyCustomer
   - Invia notifica
8. RecordTransaction
   - Crea audit record
   - UpdatePayment (status=COMPLETED)
9. UpdateSagaState (status=COMPLETED)
10. Step Functions termina con SUCCESS
```

### Scenario 2: Fallimento con Rollback

```
1-4. [Come sopra fino a VerifyFunds]
5. VerifyFunds
   - Verifica saldo
   - INSUFFICIENT FUNDS!
   - Raise InsufficientFundsError
6. Step Functions catch error
   - Entra in compensation path
7. CompensateVerifyFunds
   - Nessun hold creato → skip
8. UpdateSagaState (status=ROLLED_BACK, error=...)
9. UpdatePayment (status=FAILED)
10. Step Functions termina con FAILED
```

### Scenario 3: Fallimento Dopo Processamento

```
1-6. [Successo fino a ProcessPayment]
7. NotifyCustomer
   - ERRORE invio notifica
   - Raise NotificationError
8. Step Functions catch error
   - Entra in compensation path
9. CompensateProcessPayment
   - Storna pagamento con transaction_id
   - Crea reversal_id
   - UpdatePayment (status=ROLLED_BACK)
10. CompensateVerifyFunds
    - Rilascia hold con reservation_id
11. UpdateSagaState (status=ROLLED_BACK)
12. Step Functions termina con FAILED
```

## Compensating Transactions

### Principi

1. **Compensazione semantica, non tecnica**: Storno = nuova transazione opposta, non DELETE
2. **Idempotenza**: Eseguibili multiple volte con stesso risultato
3. **Best effort**: Loggare se falliscono, ma non propagare errore (tranne casi critici)
4. **Ordine inverso**: Compensare dall'ultimo step riuscito al primo

### Implementazione

**Step con compensazione:**
- VerifyFunds → CompensateVerifyFunds (release hold)
- ProcessPayment → CompensateProcessPayment (reverse payment)

**Step senza compensazione:**
- ValidatePayment: solo validazione, nessun side-effect
- NotifyCustomer: notifica informativa, può essere ritentata
- RecordTransaction: audit log, non modificare in caso di errore

### Gestione Fallimenti di Compensazione

**Compensazione non critica (es. release hold):**
```python
try:
    release_hold(reservation_id)
except Exception as e:
    logger.error("Compensation failed", error=e)
    # Non propagare - ritorna success con flag
    return {'compensation_result': 'FAILED_NON_CRITICAL'}
```

**Compensazione critica (es. reverse payment):**
```python
try:
    reverse_payment(transaction_id)
except Exception as e:
    logger.critical("Critical compensation failure", error=e)
    # Alert per intervento manuale
    send_alert_to_ops_team()
    return {'compensation_result': 'FAILED_CRITICAL'}
```

## Gestione degli Errori

### Livelli di Retry

#### 1. Lambda Level Retry

AWS Lambda automaticamente ritenta in caso di:
- Throttling
- Timeout
- System errors

**Configurazione:** MaximumRetryAttempts = 0 (disabilitato, gestiamo a livello Step Functions)

#### 2. Step Functions Retry

Dichiarativo in ASL:

```json
"Retry": [
  {
    "ErrorEquals": ["States.TaskFailed"],
    "IntervalSeconds": 2,
    "MaxAttempts": 2,
    "BackoffRate": 2.0
  }
]
```

#### 3. Application Level Retry

Nella Lambda function stessa (non implementato, preferito Step Functions retry)

### Error Handling Strategy

| Error Type | Retry? | Compensate? | Alert? |
|------------|--------|-------------|--------|
| Validation error | No | No | No |
| Insufficient funds | Yes (2x) | Yes (release hold) | No |
| Payment processing error | Yes (2x) | Yes (reverse payment) | Yes |
| Notification error | Yes (3x) | No | No |
| Recording error | Yes (3x) | **CRITICAL** | **YES** |
| Compensation error | No | N/A | **YES** |

## Idempotenza

### Strategia

Tutte le operazioni sono idempotenti usando:

1. **idempotency_key** nel payload
2. **payment_id** come UUID
3. **Conditional writes** in DynamoDB

### Implementazione

```python
# In validate_payment.py
if idempotency_key:
    existing = db.get_payment(payment_id)
    if existing and existing['idempotency_key'] == idempotency_key:
        # Richiesta duplicata - ritorna risultato esistente
        return existing_result
```

### Casi d'Uso

- Client retry dopo timeout
- Step Functions retry automatico
- Replay manuale di esecuzione fallita

## Decision Log

### Perché Step Functions invece di SQS/EventBridge?

**Pros Step Functions:**
- ✅ Visualizzazione grafica chiara
- ✅ Gestione errori dichiarativa
- ✅ Retry automatico configurabile
- ✅ Auditing built-in

**Cons:**
- ❌ Costo leggermente superiore (ma minimo)
- ❌ Limite 25,000 eventi in history (non problema per pagamenti)

**Decisione:** Step Functions per semplicità e visibilità

### Perché DynamoDB invece di RDS?

**Pros DynamoDB:**
- ✅ Serverless, auto-scaling
- ✅ Latenza <10ms
- ✅ No cold start
- ✅ Pay-per-request

**Cons:**
- ❌ No transazioni ACID multi-table (ma gestito dalla Saga!)
- ❌ Query limitate (OK per access patterns definiti)

**Decisione:** DynamoDB per coerenza con architettura serverless

### Perché Orchestrazione invece di Coreografia?

**Pros Orchestrazione:**
- ✅ Chiarezza: flusso tutto in un posto
- ✅ Debugging facilitato
- ✅ Modifiche più semplici

**Cons:**
- ❌ Coupling con orchestratore

**Decisione:** Orchestrazione per sistema di pagamenti dove tracciabilità > decoupling

### Perché Python 3.9?

- ✅ Supportato da Lambda
- ✅ Type hints nativi
- ✅ Ricco ecosistema
- ✅ Sintassi chiara per demo/didattica
- ✅ boto3 SDK maturo

## Considerazioni di Produzione

### Sicurezza

- [ ] Encrypt at rest per DynamoDB (KMS)
- [ ] Encrypt in transit (TLS/HTTPS)
- [ ] Secrets in AWS Secrets Manager (non env vars)
- [ ] IAM roles con least privilege
- [ ] VPC Lambda per accesso a risorse private
- [ ] API Gateway con autenticazione (Cognito/IAM)

### Performance

- [ ] Reserved Concurrency per Lambda critiche
- [ ] Provisioned Capacity per DynamoDB (se throughput prevedibile)
- [ ] Lambda SnapStart per cold start ridotto (Java/.NET)
- [ ] CloudFront per API caching

### Monitoring

- [ ] CloudWatch Dashboards personalizzate
- [ ] Alarms su metriche chiave (failure rate, latency)
- [ ] X-Ray tracing per distributed tracing
- [ ] Custom metrics con CloudWatch Metrics

### Disaster Recovery

- [ ] DynamoDB Point-in-Time Recovery
- [ ] Cross-region replication
- [ ] Backup automatici
- [ ] Runbook per recovery procedure

---

**Questa architettura bilancia semplicità, osservabilità e resilienza per un sistema di pagamenti production-ready.**
