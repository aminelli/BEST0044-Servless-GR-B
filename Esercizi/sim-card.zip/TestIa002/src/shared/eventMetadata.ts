import { newId } from "./ids";
import { UtcIsoTimestamp } from "./eventEnvelope";

export function toUtcIsoTimestamp(date: Date = new Date()): UtcIsoTimestamp {
  const value = date.toISOString();
  return value as UtcIsoTimestamp;
}

export function createEventMetadata(correlationId?: string, causationId?: string) {
  return {
    eventId: newId("evt"),
    correlationId: correlationId ?? newId("corr"),
    causationId,
    version: 1
  };
}