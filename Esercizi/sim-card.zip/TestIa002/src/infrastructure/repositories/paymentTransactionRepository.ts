import { PaymentTransaction } from "../../domain/payments/aggregates/paymentTransactionAggregate";
import { getContainer, isInMemoryRepositoryEnabled } from "./cosmosClient";

const payments = new Map<string, PaymentTransaction>();
const PAYMENTS_CONTAINER_ENV = "COSMOS_PAYMENTS_CONTAINER";

async function queryById(paymentId: string): Promise<PaymentTransaction | null> {
  const container = await getContainer(PAYMENTS_CONTAINER_ENV);
  const query = {
    query: "SELECT TOP 1 * FROM c WHERE c.id = @id",
    parameters: [{ name: "@id", value: paymentId }]
  };
  const { resources } = await container.items.query<PaymentTransaction>(query).fetchAll();
  return resources[0] ?? null;
}

export const paymentTransactionRepository = {
  async upsert(payment: PaymentTransaction): Promise<void> {
    if (isInMemoryRepositoryEnabled()) {
      payments.set(payment.id, payment);
      return;
    }

    const container = await getContainer(PAYMENTS_CONTAINER_ENV);
    await container.items.upsert(payment);
  },

  async getById(paymentId: string): Promise<PaymentTransaction | null> {
    if (isInMemoryRepositoryEnabled()) {
      return payments.get(paymentId) ?? null;
    }

    return queryById(paymentId);
  },

  async getByAggregate(
    aggregateType: PaymentTransaction["aggregateType"],
    aggregateId: string
  ): Promise<PaymentTransaction[]> {
    if (isInMemoryRepositoryEnabled()) {
      return [...payments.values()].filter(
        (x) => x.aggregateType === aggregateType && x.aggregateId === aggregateId
      );
    }

    const container = await getContainer(PAYMENTS_CONTAINER_ENV);
    const query = {
      query: "SELECT * FROM c WHERE c.aggregateType = @aggregateType AND c.aggregateId = @aggregateId",
      parameters: [
        { name: "@aggregateType", value: aggregateType },
        { name: "@aggregateId", value: aggregateId }
      ]
    };
    const { resources } = await container.items.query<PaymentTransaction>(query).fetchAll();
    return resources;
  }
};
