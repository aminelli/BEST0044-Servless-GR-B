import { ServiceBusClient } from "@azure/service-bus";

export async function publishDomainEvent<T extends object>(event: T): Promise<void> {
  const connectionString = process.env.SERVICE_BUS_CONNECTION_STRING;
  const topicName = process.env.SERVICE_BUS_TOPIC;

  if (!connectionString || !topicName) {
    return;
  }

  const client = new ServiceBusClient(connectionString);
  const sender = client.createSender(topicName);

  try {
    await sender.sendMessages({ body: event, contentType: "application/json" });
  } finally {
    await sender.close();
    await client.close();
  }
}
