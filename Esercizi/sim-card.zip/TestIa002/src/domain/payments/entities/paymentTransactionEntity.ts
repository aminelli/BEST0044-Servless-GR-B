import { PaymentStatus, PaymentTransaction } from "../aggregates/paymentTransactionAggregate";

export class PaymentTransactionEntity {
  private constructor(private readonly state: PaymentTransaction) {}

  static createNew(params: {
    id: string;
    aggregateType: PaymentTransaction["aggregateType"];
    aggregateId: string;
    customerId: string;
    amount: number;
    currency: "EUR";
    nowUtc: string;
  }): PaymentTransactionEntity {
    return new PaymentTransactionEntity({
      id: params.id,
      aggregateType: params.aggregateType,
      aggregateId: params.aggregateId,
      customerId: params.customerId,
      amount: params.amount,
      currency: params.currency,
      status: "Requested",
      createdAt: params.nowUtc,
      updatedAt: params.nowUtc
    });
  }

  static rehydrate(raw: PaymentTransaction): PaymentTransactionEntity {
    return new PaymentTransactionEntity({ ...raw });
  }

  get id(): string {
    return this.state.id;
  }

  get status(): PaymentStatus {
    return this.state.status;
  }

  transition(to: PaymentStatus, nowUtc: string): void {
    this.state.status = to;
    this.state.updatedAt = nowUtc;
  }

  toPrimitives(): PaymentTransaction {
    return { ...this.state };
  }
}
