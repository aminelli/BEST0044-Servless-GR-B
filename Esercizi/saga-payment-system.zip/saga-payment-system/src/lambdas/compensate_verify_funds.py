"""
Lambda per rilasciare la prenotazione fondi (compensazione verify_funds).
"""
import json
import sys
from typing import Dict, Any

# Aggiungi il path per importare i moduli condivisi
sys.path.insert(0, '/opt/python')

from shared import get_logger

logger = get_logger(__name__)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Compensating transaction per verify_funds.
    
    Rilascia il hold sui fondi in caso di fallimento della Saga.
    
    Args:
        event: Evento Step Functions con i dati del pagamento
        context: Contesto Lambda
        
    Returns:
        Evento aggiornato con compensation_result
    """
    logger.add_context(
        function_name='compensate_verify_funds',
        request_id=context.request_id
    )
    
    logger.info("Starting funds hold release (compensation)", event=event)
    
    try:
        payment_data = event.get('payment', {})
        payment_id = payment_data.get('payment_id')
        reservation_id = event.get('reservation_id')
        account_id = payment_data.get('account_id')
        
        logger.add_context(
            payment_id=payment_id,
            reservation_id=reservation_id
        )
        
        if not reservation_id:
            logger.warning("No reservation_id found, skipping compensation")
            event['funds_compensation_result'] = 'SKIPPED_NO_RESERVATION'
            return event
        
        # Simula il rilascio del hold
        _release_funds_hold(reservation_id, account_id)
        
        logger.info("Funds hold released successfully", 
                   payment_id=payment_id,
                   reservation_id=reservation_id)
        
        event['funds_compensation_result'] = 'SUCCESS'
        
        return event
        
    except Exception as e:
        logger.error("Funds hold release failed", 
                    error=str(e),
                    payment_id=payment_data.get('payment_id'))
        
        # Anche se la compensazione fallisce, non dovremmo propagare l'errore
        # Ma dovremmo creare un alert per intervento manuale
        event['funds_compensation_result'] = 'FAILED'
        event['funds_compensation_error'] = str(e)
        
        return event


def _release_funds_hold(reservation_id: str, account_id: str):
    """
    Rilascia il hold sui fondi.
    
    In produzione, chiamarebbe un'API bancaria per rilasciare
    la prenotazione dei fondi.
    
    Args:
        reservation_id: ID della prenotazione da rilasciare
        account_id: ID del conto
    """
    logger.info("Releasing funds hold", 
               reservation_id=reservation_id,
               account_id=account_id)
    
    # In produzione, qui chiameremmo l'API bancaria per:
    # 1. Rilasciare l'hold
    # 2. Rendere i fondi nuovamente disponibili
    # 3. Confermare il rilascio
    
    # Simula un piccolo delay per realismo
    import time
    time.sleep(0.1)
    
    logger.info("Funds hold released", 
               reservation_id=reservation_id)
