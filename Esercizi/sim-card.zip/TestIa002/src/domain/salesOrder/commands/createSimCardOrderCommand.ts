import { z } from "zod";

export const CreateSimCardOrderCommandSchema = z.object({
  customer: z.object({
    firstName: z.string().min(1),
    lastName: z.string().min(1),
    email: z.string().email(),
    phone: z.string().min(5)
  }),
  sim: z.object({
    planType: z.string().min(1),
    preferredNumber: z.string().optional()
  })
});

export type CreateSimCardOrderCommand = z.infer<typeof CreateSimCardOrderCommandSchema>;
