import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getSimCardOrderDocuments } from "../../application/queryHandlers/simCardOrderQueryHandler";
import { mapItemsResponse, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetOrderDocuments", {
  methods: ["GET"],
  authLevel: "function",
  route: "orders/{orderId}/documents",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeOrderId = mapRouteParam(request, "orderId");
    if (!routeOrderId.ok) {
      return badRequest(routeOrderId.error);
    }

    const orderId = routeOrderId.value;

    const documents = await getSimCardOrderDocuments(orderId);
    return ok(mapItemsResponse(documents));
  }
});
