# TESTING

## Strategia

- Unit tests: dominio e command/query handlers
- Integration tests: endpoint HTTP e integrazione repository/messaging mock
- Obiettivo coverage: > 70%

## Esecuzione

- Tutti i test:

npm test

- Modalita watch:

npm run test:watch

## Linee guida nuovi test

- Preferire test deterministici
- Mockare dipendenze esterne (Service Bus, Blob, Cosmos)
- Validare sia percorso happy path sia error handling
