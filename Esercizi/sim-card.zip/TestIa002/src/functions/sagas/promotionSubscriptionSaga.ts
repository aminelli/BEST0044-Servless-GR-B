import * as df from "durable-functions";

// Orchestrazione base della saga promozioni con compensazione pagamento/attivazione.
df.app.orchestration("PromotionSubscriptionSaga", function* (context) {
  const input = context.df.getInput() as { subscriptionId: string };
  const completedSteps: string[] = [];

  try {
    yield context.df.callActivity("PromoStepProcessPayment", input);
    completedSteps.push("ProcessPayment");

    yield context.df.callActivity("PromoStepActivatePromotion", input);
    completedSteps.push("ActivatePromotion");

    yield context.df.callActivity("PromoStepNotifyCustomer", input);
    completedSteps.push("NotifyCustomer");

    return { ok: true, subscriptionId: input.subscriptionId };
  } catch (error) {
    for (const step of completedSteps.reverse()) {
      yield context.df.callActivity("PromoCompensation", {
        subscriptionId: input.subscriptionId,
        step
      });
    }

    return { ok: false, error: `${error}` };
  }
});
