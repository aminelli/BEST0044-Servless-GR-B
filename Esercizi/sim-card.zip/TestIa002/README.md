# Azure Functions CQRS + DDD + Saga Demo

Questo progetto mostra un'implementazione di riferimento in TypeScript/Node.js su Azure Functions con pattern CQRS, DDD e Saga (Durable Functions), in un dominio telecom (acquisto SIM e adesione promozioni).

## Cosa include

- Azure Functions v4 (HTTP, Service Bus, Durable)
- Separazione Commands/Queries
- Aggregati e Domain Events
- Saga orchestration con compensazioni
- Infrastruttura Azure via Bicep
- Documentazione tecnica completa in docs

Nota: i Domain Events sono uniformati con envelope comune (eventId, correlationId, causationId, version, occurredAtUtc).

## Prerequisiti

- Node.js 20+
- npm 10+
- Azure Functions Core Tools v4
- Azure CLI

## Setup locale

1. Installa dipendenze:

npm install

2. Crea il file locale settings:

copy local.settings.json.example local.settings.json

Opzionale (per tool/test locali):

copy .env.example .env

3. Build TypeScript:

npm run build

4. Avvio locale Functions:

npm start

Nota validazione env a startup:

- L'app valida le variabili ambiente richieste all'avvio
- Per bypass locale: imposta SKIP_ENV_VALIDATION=true
- Per disattivare controlli specifici: SERVICE_BUS_ENABLED=false o BLOB_STORAGE_ENABLED=false
- Persistenza reale usa Cosmos DB; per fallback locale: USE_IN_MEMORY_REPOSITORY=true

## Struttura

- src/functions: endpoint HTTP, handler eventi, saga orchestrators
- src/domain: modelli DDD (aggregates, events, commands, value objects)
- src/application: command/query handlers
- src/infrastructure: repository, messaging, storage
- infrastructure: template IaC Bicep
- docs: documentazione architetturale e operativa

## Deploy Azure (base)

1. Login:

az login

2. Deploy risorse:

az deployment group create --resource-group <rg> --template-file infrastructure/main.bicep --parameters infrastructure/main.dev.bicepparam

Oppure con file JSON parametri classico:

az deployment group create --resource-group <rg> --template-file infrastructure/main.bicep --parameters @infrastructure/main.parameters.dev.json

Per staging:

az deployment group create --resource-group <rg-staging> --template-file infrastructure/main.bicep --parameters @infrastructure/main.parameters.staging.json

Per produzione:

az deployment group create --resource-group <rg-prod> --template-file infrastructure/main.bicep --parameters @infrastructure/main.parameters.prod.json

## Documentazione

- docs/ARCHITECTURE.md
- docs/API.md
- docs/DOMAIN.md
- docs/DEPLOYMENT.md
- docs/TESTING.md
