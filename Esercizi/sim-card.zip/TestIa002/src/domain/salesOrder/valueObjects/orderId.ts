export class OrderId {
  private constructor(public readonly value: string) {}

  static create(raw: string): OrderId {
    if (!raw || raw.trim().length === 0) {
      throw new Error("OrderId cannot be empty.");
    }

    return new OrderId(raw.trim());
  }
}
