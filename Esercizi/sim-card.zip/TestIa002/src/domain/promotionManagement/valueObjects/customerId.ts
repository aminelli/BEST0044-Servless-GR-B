export class CustomerId {
  private constructor(public readonly value: string) {}

  static create(raw: string): CustomerId {
    const value = raw?.trim();
    if (!value) {
      throw new Error("CustomerId cannot be empty.");
    }

    return new CustomerId(value);
  }
}
