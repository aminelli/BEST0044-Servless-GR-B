import { EventMetadata, UtcIsoTimestamp } from "../../../shared/eventEnvelope";

export type PromotionEventType =
  | "PromotionSubscriptionRequested"
  | "PaymentProcessed"
  | "PromotionActivated"
  | "CustomerNotified";

export interface PromotionEvent extends EventMetadata {
  subscriptionId: string;
  type: PromotionEventType;
  occurredAtUtc: UtcIsoTimestamp;
  payload: Record<string, unknown>;
}
