import { createSimCardOrder } from "../../src/application/commandHandlers/simCardOrderCommandHandler";

describe("createSimCardOrder", () => {
  it("creates an order with Created status", async () => {
    const result = await createSimCardOrder({
      customer: {
        firstName: "Mario",
        lastName: "Rossi",
        email: "mario.rossi@example.com",
        phone: "+390000000"
      },
      sim: {
        planType: "UNLIMITED"
      }
    });

    expect(result.status).toBe("Created");
    expect(result.id).toContain("order-");
  });
});
