import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { generateContract } from "../../application/commandHandlers/simCardOrderLifecycleCommandHandler";
import { mapGenerateContractCommand, mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest } from "../../shared/http";

app.http("GenerateContract", {
  methods: ["POST"],
  authLevel: "function",
  route: "orders/{orderId}/contract/generate",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeOrderId = mapRouteParam(request, "orderId");
      if (!routeOrderId.ok) {
        return badRequest(routeOrderId.error);
      }

      const result = await generateContract(mapGenerateContractCommand(routeOrderId.value));
      return accepted(result);
    } catch (error) {
      context.error("GenerateContract failed", error);
      return badRequest("Invalid contract generation payload.");
    }
  }
});
