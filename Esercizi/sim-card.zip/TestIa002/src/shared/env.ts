const requiredAtRuntime = [
  "FUNCTIONS_WORKER_RUNTIME",
  "SERVICE_BUS_TOPIC",
  "BLOB_CUSTOMER_DOCS_CONTAINER",
  "BLOB_CONTRACTS_CONTAINER",
  "COSMOS_DATABASE",
  "COSMOS_ORDERS_CONTAINER",
  "COSMOS_PROMOTION_SUBSCRIPTIONS_CONTAINER",
  "COSMOS_PAYMENTS_CONTAINER"
] as const;

const requiredWhenFeatureEnabled = [
  "SERVICE_BUS_CONNECTION_STRING",
  "BLOB_CONNECTION_STRING",
  "COSMOS_ENDPOINT",
  "COSMOS_KEY"
] as const;

function isMissing(value: string | undefined): boolean {
  return !value || value.trim().length === 0;
}

export function validateEnvironmentVariables(): void {
  if (process.env.NODE_ENV === "test" || process.env.SKIP_ENV_VALIDATION === "true") {
    return;
  }

  const missing = new Set<string>();

  for (const key of requiredAtRuntime) {
    if (isMissing(process.env[key])) {
      missing.add(key);
    }
  }

  const serviceBusEnabled = process.env.SERVICE_BUS_ENABLED !== "false";
  const blobEnabled = process.env.BLOB_STORAGE_ENABLED !== "false";
  const cosmosEnabled = process.env.USE_IN_MEMORY_REPOSITORY !== "true";

  if (serviceBusEnabled && isMissing(process.env.SERVICE_BUS_CONNECTION_STRING)) {
    missing.add("SERVICE_BUS_CONNECTION_STRING");
  }

  if (blobEnabled && isMissing(process.env.BLOB_CONNECTION_STRING)) {
    missing.add("BLOB_CONNECTION_STRING");
  }

  if (cosmosEnabled) {
    if (isMissing(process.env.COSMOS_ENDPOINT)) {
      missing.add("COSMOS_ENDPOINT");
    }

    if (isMissing(process.env.COSMOS_KEY)) {
      missing.add("COSMOS_KEY");
    }
  }

  if (missing.size > 0) {
    const missingKeys = [...missing.values()].sort().join(", ");
    throw new Error(`Missing required environment variables: ${missingKeys}`);
  }
}
