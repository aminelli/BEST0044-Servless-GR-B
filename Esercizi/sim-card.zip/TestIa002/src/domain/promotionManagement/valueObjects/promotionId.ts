export class PromotionId {
  private constructor(public readonly value: string) {}

  static create(raw: string): PromotionId {
    const value = raw?.trim();
    if (!value) {
      throw new Error("PromotionId cannot be empty.");
    }

    return new PromotionId(value);
  }
}
