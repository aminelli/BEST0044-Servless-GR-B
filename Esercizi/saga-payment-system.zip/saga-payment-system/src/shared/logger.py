"""
Configurazione del logging strutturato.
"""
import logging
import json
import os
from typing import Any, Dict


class StructuredLogger(logging.Logger):
    """
    Logger personalizzato con output JSON strutturato.
    
    Aggiunge contesto automatico a tutti i log per facilitare
    il monitoring e la ricerca in CloudWatch.
    """
    
    def __init__(self, name: str):
        """
        Inizializza il logger strutturato.
        
        Args:
            name: Nome del logger (tipicamente __name__)
        """
        super().__init__(name)
        self.context: Dict[str, Any] = {}
    
    def add_context(self, **kwargs):
        """
        Aggiunge contesto al logger che sarà incluso in tutti i log.
        
        Args:
            **kwargs: Coppie chiave-valore da aggiungere al contesto
        """
        self.context.update(kwargs)
    
    def _log_structured(self, level: int, msg: str, **kwargs):
        """
        Logga un messaggio con formato JSON strutturato.
        
        Args:
            level: Livello di log
            msg: Messaggio da loggare
            **kwargs: Dati aggiuntivi da includere nel log
        """
        log_data = {
            'message': msg,
            'level': logging.getLevelName(level),
            **self.context,
            **kwargs
        }
        super()._log(level, json.dumps(log_data), ())
    
    def info(self, msg: str, **kwargs):
        """Logga un messaggio INFO."""
        self._log_structured(logging.INFO, msg, **kwargs)
    
    def error(self, msg: str, **kwargs):
        """Logga un messaggio ERROR."""
        self._log_structured(logging.ERROR, msg, **kwargs)
    
    def warning(self, msg: str, **kwargs):
        """Logga un messaggio WARNING."""
        self._log_structured(logging.WARNING, msg, **kwargs)
    
    def debug(self, msg: str, **kwargs):
        """Logga un messaggio DEBUG."""
        self._log_structured(logging.DEBUG, msg, **kwargs)


def get_logger(name: str) -> StructuredLogger:
    """
    Crea e configura un logger strutturato.
    
    Args:
        name: Nome del logger (tipicamente __name__)
        
    Returns:
        Istanza di StructuredLogger configurato
    """
    logging.setLoggerClass(StructuredLogger)
    logger = logging.getLogger(name)
    
    log_level = os.environ.get('LOG_LEVEL', 'INFO')
    logger.setLevel(getattr(logging, log_level))
    
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter('%(message)s'))
        logger.addHandler(handler)
    
    return logger
