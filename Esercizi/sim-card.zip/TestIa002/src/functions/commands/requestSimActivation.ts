import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { requestActivation } from "../../application/commandHandlers/simCardOrderLifecycleCommandHandler";
import { mapRequestActivationCommand, mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest } from "../../shared/http";

app.http("RequestSimActivation", {
  methods: ["POST"],
  authLevel: "function",
  route: "orders/{orderId}/activation/request",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeOrderId = mapRouteParam(request, "orderId");
      if (!routeOrderId.ok) {
        return badRequest(routeOrderId.error);
      }

      const result = await requestActivation(mapRequestActivationCommand(routeOrderId.value));
      return accepted(result);
    } catch (error) {
      context.error("RequestSimActivation failed", error);
      return badRequest("Invalid activation request payload.");
    }
  }
});
