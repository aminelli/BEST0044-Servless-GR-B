import { PaymentTransaction } from "../../domain/payments/aggregates/paymentTransactionAggregate";
import { PromotionSubscription } from "../../domain/promotionManagement/aggregates/promotionSubscriptionAggregate";
import { SimCardOrder } from "../../domain/salesOrder/aggregates/simCardOrderAggregate";

export interface SimCardOrderRepositoryPort {
  upsert(order: SimCardOrder): Promise<void>;
  getById(orderId: string): Promise<SimCardOrder | null>;
  getByCustomer(customerId: string): Promise<SimCardOrder[]>;
  getTransitions(orderId: string): Promise<SimCardOrder["transitions"]>;
  getDocuments(orderId: string): Promise<SimCardOrder["documents"]>;
}

export interface PromotionSubscriptionRepositoryPort {
  upsert(subscription: PromotionSubscription): Promise<void>;
  getById(subscriptionId: string): Promise<PromotionSubscription | null>;
  getByCustomer(customerId: string): Promise<PromotionSubscription[]>;
}

export interface PaymentTransactionRepositoryPort {
  upsert(payment: PaymentTransaction): Promise<void>;
  getById(paymentId: string): Promise<PaymentTransaction | null>;
  getByAggregate(
    aggregateType: PaymentTransaction["aggregateType"],
    aggregateId: string
  ): Promise<PaymentTransaction[]>;
}

export interface DomainEventPublisherPort {
  publishDomainEvent<T extends object>(event: T): Promise<void>;
}

export interface DocumentStoragePort {
  uploadTextDocument(containerName: string, blobName: string, content: string): Promise<string>;
}

export interface ApplicationOutboundPorts {
  simCardOrderRepository: SimCardOrderRepositoryPort;
  promotionSubscriptionRepository: PromotionSubscriptionRepositoryPort;
  paymentTransactionRepository: PaymentTransactionRepositoryPort;
  domainEventPublisher: DomainEventPublisherPort;
  documentStorage: DocumentStoragePort;
}
