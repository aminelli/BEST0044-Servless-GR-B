import { Container, CosmosClient } from "@azure/cosmos";

let client: CosmosClient | null = null;

function getClient(): CosmosClient {
  if (client) {
    return client;
  }

  const endpoint = process.env.COSMOS_ENDPOINT;
  const key = process.env.COSMOS_KEY;

  if (!endpoint || !key) {
    throw new Error("COSMOS_ENDPOINT and COSMOS_KEY are required when Cosmos repository is enabled.");
  }

  client = new CosmosClient({ endpoint, key });
  return client;
}

export function isInMemoryRepositoryEnabled(): boolean {
  return process.env.NODE_ENV === "test" || process.env.USE_IN_MEMORY_REPOSITORY === "true";
}

export async function getContainer(containerName: string): Promise<Container> {
  const databaseId = process.env.COSMOS_DATABASE ?? "telecom-demo";
  const containerId = process.env[containerName];

  if (!containerId) {
    throw new Error(`Missing required container env var: ${containerName}`);
  }

  return getClient().database(databaseId).container(containerId);
}
