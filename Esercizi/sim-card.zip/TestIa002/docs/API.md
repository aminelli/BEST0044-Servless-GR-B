# API

## Commands

### POST /api/orders
Crea un nuovo ordine SIM.

Request esempio:
{
  "customer": {
    "firstName": "Mario",
    "lastName": "Rossi",
    "email": "mario.rossi@example.com",
    "phone": "+393331112233"
  },
  "sim": {
    "planType": "UNLIMITED",
    "preferredNumber": "3331234567"
  }
}

Response esempio:
{
  "orderId": "order-...",
  "status": "Created"
}

Nota: dopo la creazione ordine, la SimCardOrderSaga include anche lo step ProcessPayment con compensazione RefundPayment in caso di rollback.

### POST /api/promotions/subscriptions
Crea richiesta adesione promozione.

Request esempio:
{
  "customerId": "cust-100",
  "promotionId": "promo-summer"
}

### POST /api/orders/{orderId}/documents
Carica documenti cliente per l'ordine.

### POST /api/orders/{orderId}/activation/request
Richiede abilitazione SIM.

### POST /api/orders/{orderId}/activation/review
Approva o rifiuta abilitazione SIM.

### POST /api/orders/{orderId}/contract/generate
Genera contratto e lo registra tra i documenti ordine.

### POST /api/orders/{orderId}/contract/send
Invia contratto al cliente (email/sms simulato).

### POST /api/orders/{orderId}/saga/start
Avvia orchestrazione Durable SimCardOrderSaga.

### POST /api/promotions/subscriptions/{subscriptionId}/payment/process
Elabora pagamento adesione promozione.

### POST /api/promotions/subscriptions/{subscriptionId}/activate
Attiva promozione.

### POST /api/promotions/subscriptions/{subscriptionId}/notify
Notifica cliente per promozione attivata.

### POST /api/promotions/subscriptions/{subscriptionId}/saga/start
Avvia orchestrazione Durable PromotionSubscriptionSaga.

## Queries

### GET /api/orders/{orderId}
Restituisce stato ordine.

### GET /api/customers/{customerId}/promotions
Restituisce promozioni del cliente.

### GET /api/customers/{customerId}/orders
Restituisce lista ordini SIM del cliente.

### GET /api/orders/{orderId}/history
Restituisce storico transizioni stato ordine.

### GET /api/orders/{orderId}/documents
Restituisce documenti associati all'ordine.

### GET /api/orders/{orderId}/payments
Restituisce transazioni pagamento associate all'ordine.
Query params opzionali: status (Requested|Processed|Refunded|Failed), fromUtc, toUtc.

### GET /api/promotions/available
Restituisce lista promozioni disponibili.

### GET /api/customers/{customerId}/promotions/history
Restituisce storico adesioni promozioni cliente.

### GET /api/promotions/{promotionId}/eligibility/{customerId}
Verifica eleggibilita' cliente per promozione.

### GET /api/promotions/subscriptions/{subscriptionId}/payments
Restituisce transazioni pagamento associate alla sottoscrizione promozione.
Query params opzionali: status (Requested|Processed|Refunded|Failed), fromUtc, toUtc.

## Standard Domain Events

Gli endpoint command pubblicano eventi con envelope uniforme:

- eventId
- correlationId
- causationId (opzionale)
- version
- occurredAtUtc (ISO UTC)

Questo standard e' condiviso tra SalesOrder e PromotionManagement.

## Autenticazione

AuthLevel attuale: function.
Per produzione: Azure AD + APIM o front-door con policy di sicurezza.
