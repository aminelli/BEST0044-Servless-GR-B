export class SubscriptionId {
  private constructor(public readonly value: string) {}

  static create(raw: string): SubscriptionId {
    const value = raw?.trim();
    if (!value) {
      throw new Error("SubscriptionId cannot be empty.");
    }

    return new SubscriptionId(value);
  }
}
