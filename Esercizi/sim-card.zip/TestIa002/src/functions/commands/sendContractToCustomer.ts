import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { sendContractToCustomer } from "../../application/commandHandlers/simCardOrderLifecycleCommandHandler";
import { mapRouteParam, mapSendContractCommand } from "../mappers/commandHttpMapper";
import { accepted, badRequest, readJsonBody } from "../../shared/http";

app.http("SendContractToCustomer", {
  methods: ["POST"],
  authLevel: "function",
  route: "orders/{orderId}/contract/send",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeOrderId = mapRouteParam(request, "orderId");
      if (!routeOrderId.ok) {
        return badRequest(routeOrderId.error);
      }

      const body = await readJsonBody<{ channel?: "email" | "sms" }>(request);
      const result = await sendContractToCustomer(mapSendContractCommand(routeOrderId.value, body));

      return accepted(result);
    } catch (error) {
      context.error("SendContractToCustomer failed", error);
      return badRequest("Invalid contract send payload.");
    }
  }
});
