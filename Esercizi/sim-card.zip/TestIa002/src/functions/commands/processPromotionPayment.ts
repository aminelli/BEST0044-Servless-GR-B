import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { processPromotionPayment } from "../../application/commandHandlers/promotionLifecycleCommandHandler";
import { mapProcessPromotionPaymentCommand, mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest, readJsonBody } from "../../shared/http";

app.http("ProcessPromotionPayment", {
  methods: ["POST"],
  authLevel: "function",
  route: "promotions/subscriptions/{subscriptionId}/payment/process",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeSubscriptionId = mapRouteParam(request, "subscriptionId");
      if (!routeSubscriptionId.ok) {
        return badRequest(routeSubscriptionId.error);
      }

      const body = await readJsonBody<{ amount?: number }>(request);
      const result = await processPromotionPayment(
        mapProcessPromotionPaymentCommand(routeSubscriptionId.value, body)
      );

      return accepted(result);
    } catch (error) {
      context.error("ProcessPromotionPayment failed", error);
      return badRequest("Invalid payment process payload.");
    }
  }
});
