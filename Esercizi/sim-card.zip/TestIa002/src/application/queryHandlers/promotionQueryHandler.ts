import { getApplicationDependencies } from "../dependencies";
import { CustomerId } from "../../domain/promotionManagement/valueObjects/customerId";
import { PromotionId } from "../../domain/promotionManagement/valueObjects/promotionId";

const availablePromotions = [
  { id: "promo-summer", name: "Summer Unlimited", price: 9.99 },
  { id: "promo-family", name: "Family Pack", price: 19.99 },
  { id: "promo-5g", name: "5G Booster", price: 4.99 }
];

export async function getPromotionsByCustomer(customerId: string) {
  return getApplicationDependencies().promotionSubscriptionRepository.getByCustomer(customerId);
}

export async function getPromotionHistoryByCustomer(customerId: string) {
  return getApplicationDependencies().promotionSubscriptionRepository.getByCustomer(customerId);
}

export async function getAvailablePromotions() {
  return availablePromotions;
}

export async function checkPromotionEligibility(customerId: string, promotionId: string) {
  const customer = CustomerId.create(customerId);
  const promotion = PromotionId.create(promotionId);

  const alreadySubscribed = (
    await getApplicationDependencies().promotionSubscriptionRepository.getByCustomer(customer.value)
  ).some((x) => x.promotionId === promotion.value);

  return {
    customerId: customer.value,
    promotionId: promotion.value,
    eligible: !alreadySubscribed,
    reason: alreadySubscribed ? "Promotion already active/requested for customer." : "Eligible"
  };
}
