export type PromotionSubscriptionStatus =
  | "Requested"
  | "PaymentProcessed"
  | "Activated"
  | "Notified";

export interface PromotionSubscription {
  id: string;
  customerId: string;
  promotionId: string;
  status: PromotionSubscriptionStatus;
  createdAt: string;
  updatedAt: string;
}
