"""
Client per operazioni su DynamoDB.
"""
import os
from typing import Optional, Dict, Any
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError


class DynamoDBClient:
    """
    Client wrapper per operazioni DynamoDB.
    
    Fornisce metodi di alto livello per interagire con le tabelle
    di pagamenti e stato Saga con gestione degli errori.
    """
    
    def __init__(self):
        """Inizializza il client DynamoDB."""
        self.dynamodb = boto3.resource('dynamodb')
        self.payments_table_name = os.environ.get('PAYMENTS_TABLE', 'SagaPayments')
        self.saga_state_table_name = os.environ.get('SAGA_STATE_TABLE', 'SagaStates')
        
        self.payments_table = self.dynamodb.Table(self.payments_table_name)
        self.saga_state_table = self.dynamodb.Table(self.saga_state_table_name)
    
    def get_payment(self, payment_id: str) -> Optional[Dict[str, Any]]:
        """
        Recupera un pagamento da DynamoDB.
        
        Args:
            payment_id: ID del pagamento
            
        Returns:
            Dizionario con i dati del pagamento o None se non trovato
        """
        try:
            response = self.payments_table.get_item(Key={'payment_id': payment_id})
            return response.get('Item')
        except ClientError as e:
            print(f"Error getting payment {payment_id}: {e}")
            return None
    
    def put_payment(self, payment_data: Dict[str, Any]) -> bool:
        """
        Salva un pagamento in DynamoDB.
        
        Args:
            payment_data: Dati del pagamento da salvare
            
        Returns:
            True se successo, False altrimenti
        """
        try:
            self.payments_table.put_item(Item=payment_data)
            return True
        except ClientError as e:
            print(f"Error putting payment: {e}")
            return False
    
    def update_payment_status(self, payment_id: str, status: str, error_message: Optional[str] = None) -> bool:
        """
        Aggiorna lo stato di un pagamento.
        
        Args:
            payment_id: ID del pagamento
            status: Nuovo stato
            error_message: Messaggio di errore opzionale
            
        Returns:
            True se successo, False altrimenti
        """
        try:
            update_expression = "SET #status = :status, updated_at = :updated_at"
            expression_values = {
                ':status': status,
                ':updated_at': str(boto3.utils.datetime.datetime.utcnow().isoformat())
            }
            expression_names = {'#status': 'status'}
            
            if error_message:
                update_expression += ", error_message = :error_message"
                expression_values[':error_message'] = error_message
            
            self.payments_table.update_item(
                Key={'payment_id': payment_id},
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_values,
                ExpressionAttributeNames=expression_names
            )
            return True
        except ClientError as e:
            print(f"Error updating payment status: {e}")
            return False
    
    def get_saga_state(self, saga_id: str) -> Optional[Dict[str, Any]]:
        """
        Recupera lo stato di una Saga.
        
        Args:
            saga_id: ID della Saga
            
        Returns:
            Dizionario con lo stato della Saga o None se non trovato
        """
        try:
            response = self.saga_state_table.get_item(Key={'saga_id': saga_id})
            return response.get('Item')
        except ClientError as e:
            print(f"Error getting saga state {saga_id}: {e}")
            return None
    
    def put_saga_state(self, saga_data: Dict[str, Any]) -> bool:
        """
        Salva lo stato di una Saga.
        
        Args:
            saga_data: Dati dello stato della Saga
            
        Returns:
            True se successo, False altrimenti
        """
        try:
            self.saga_state_table.put_item(Item=saga_data)
            return True
        except ClientError as e:
            print(f"Error putting saga state: {e}")
            return False
    
    def update_saga_state(
        self, 
        saga_id: str, 
        status: str, 
        current_step: Optional[str] = None,
        error_message: Optional[str] = None
    ) -> bool:
        """
        Aggiorna lo stato di una Saga.
        
        Args:
            saga_id: ID della Saga
            status: Nuovo stato
            current_step: Step corrente opzionale
            error_message: Messaggio di errore opzionale
            
        Returns:
            True se successo, False altrimenti
        """
        try:
            update_expression = "SET #status = :status, updated_at = :updated_at"
            expression_values = {
                ':status': status,
                ':updated_at': str(boto3.utils.datetime.datetime.utcnow().isoformat())
            }
            expression_names = {'#status': 'status'}
            
            if current_step:
                update_expression += ", current_step = :current_step"
                expression_values[':current_step'] = current_step
            
            if error_message:
                update_expression += ", error_message = :error_message"
                expression_values[':error_message'] = error_message
            
            self.saga_state_table.update_item(
                Key={'saga_id': saga_id},
                UpdateExpression=update_expression,
                ExpressionAttributeValues=expression_values,
                ExpressionAttributeNames=expression_names
            )
            return True
        except ClientError as e:
            print(f"Error updating saga state: {e}")
            return False
    
    def mark_step_completed(self, saga_id: str, step: str) -> bool:
        """
        Marca uno step della Saga come completato.
        
        Args:
            saga_id: ID della Saga
            step: Nome dello step completato
            
        Returns:
            True se successo, False altrimenti
        """
        try:
            self.saga_state_table.update_item(
                Key={'saga_id': saga_id},
                UpdateExpression="SET completed_steps = list_append(if_not_exists(completed_steps, :empty_list), :step), updated_at = :updated_at",
                ExpressionAttributeValues={
                    ':step': [step],
                    ':empty_list': [],
                    ':updated_at': str(boto3.utils.datetime.datetime.utcnow().isoformat())
                }
            )
            return True
        except ClientError as e:
            print(f"Error marking step completed: {e}")
            return False
