# ARCHITECTURE

## Visione generale

L'architettura usa un approccio event-driven e serverless:

- Write side: HTTP Commands + command handlers + aggregate updates
- Read side: HTTP Queries su modelli lettura ottimizzati
- Integration side: Domain Events pubblicati su Service Bus Topic
- Process orchestration: Durable Functions con Saga e compensazioni

I Domain Events sono uniformati con envelope comune per observability e tracing:

- eventId
- correlationId
- causationId (opzionale)
- version
- occurredAtUtc (ISO UTC)

## Bounded Contexts

- SalesOrder: ciclo ordine SIM (creazione, documenti, pagamento, attivazione, contratto)
- PromotionManagement: adesione e attivazione promozioni

## CQRS

- Commands: mutate stato e pubblicano eventi
- Queries: leggono stato senza side effect
- Possibile evoluzione: read models denormalizzati su container dedicati

## Saga

- SimCardOrderSaga: UploadDocuments -> ProcessPayment -> RequestActivation -> GenerateContract -> SendContract
- PromotionSubscriptionSaga: ProcessPayment -> ActivatePromotion -> NotifyCustomer
- In caso di errore viene applicata la compensation in ordine inverso

## Diagramma logico (testuale)

Client -> HTTP Functions (Commands/Queries)
HTTP Commands -> Application Handlers -> Domain Aggregates -> Repository
Application Handlers -> Service Bus Topic (Domain Events)
Durable Orchestrator -> Activity Functions -> Compensation
