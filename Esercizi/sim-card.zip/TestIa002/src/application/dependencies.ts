import { ApplicationOutboundPorts } from "./ports/outboundPorts";
import { outboundAdapters } from "../infrastructure/adapters/outboundAdapters";

let deps: ApplicationOutboundPorts = outboundAdapters;

export function setApplicationDependencies(next: ApplicationOutboundPorts): void {
  deps = next;
}

export function getApplicationDependencies(): ApplicationOutboundPorts {
  return deps;
}
