export type SimCardOrderStatus =
  | "Created"
  | "DocumentsUploaded"
  | "PaymentProcessed"
  | "ActivationRequested"
  | "ActivationApproved"
  | "ActivationRejected"
  | "ContractGenerated"
  | "ContractSent";

export interface OrderDocumentReference {
  type: "IdentityFront" | "IdentityBack" | "TaxCode" | "Contract";
  blobUrl: string;
  uploadedAtUtc: string;
}

export interface OrderStatusTransition {
  from: SimCardOrderStatus | null;
  to: SimCardOrderStatus;
  changedAtUtc: string;
  reason?: string;
}

export interface SimCardOrder {
  id: string;
  customerId: string;
  status: SimCardOrderStatus;
  documents: OrderDocumentReference[];
  transitions: OrderStatusTransition[];
  createdAt: string;
  updatedAt: string;
}
