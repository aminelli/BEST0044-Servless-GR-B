import { app, InvocationContext } from "@azure/functions";

app.serviceBusTopic("DomainEventsConsumer", {
  connection: "SERVICE_BUS_CONNECTION_STRING",
  topicName: "%SERVICE_BUS_TOPIC%",
  subscriptionName: "telecom-demo-subscription",
  handler: async (
    message: unknown,
    context: InvocationContext
  ): Promise<void> => {
    context.log("Domain event received", message);
  }
});
