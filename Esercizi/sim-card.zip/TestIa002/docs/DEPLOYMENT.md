# DEPLOYMENT

## Strategia

- Provisioning risorse con Bicep
- Deploy codice Functions via CI/CD (GitHub Actions o Azure DevOps)
- Ambiente separato per dev/staging/prod con file parametri dedicati

## Provisioning risorse

Comando:

az deployment group create --resource-group <rg> --template-file infrastructure/main.bicep --parameters infrastructure/main.dev.bicepparam

Alternativa con file parametri JSON classico:

az deployment group create --resource-group <rg> --template-file infrastructure/main.bicep --parameters @infrastructure/main.parameters.dev.json

Esempio ambiente staging:

az deployment group create --resource-group <rg-staging> --template-file infrastructure/main.bicep --parameters @infrastructure/main.parameters.staging.json

Esempio ambiente produzione:

az deployment group create --resource-group <rg-prod> --template-file infrastructure/main.bicep --parameters @infrastructure/main.parameters.prod.json

Risorse principali:
- Function App (Flex Consumption FC1)
- Storage Account
- Service Bus Namespace + Topic + Subscription
- Cosmos DB account
- Application Insights

## Configurazioni runtime

Variabili principali:
- AzureWebJobsStorage
- FUNCTIONS_WORKER_RUNTIME=node
- SERVICE_BUS_CONNECTION_STRING
- SERVICE_BUS_TOPIC
- COSMOS_ENDPOINT
- COSMOS_KEY
- COSMOS_DATABASE
- COSMOS_ORDERS_CONTAINER
- COSMOS_PROMOTION_SUBSCRIPTIONS_CONTAINER
- COSMOS_PAYMENTS_CONTAINER
- BLOB_CONNECTION_STRING

Opzione repository locale:
- USE_IN_MEMORY_REPOSITORY=false per usare Cosmos reale
- USE_IN_MEMORY_REPOSITORY=true solo per test/dev rapido

Note ambiente locale:
- local.settings.json e' la fonte primaria per Azure Functions runtime
- .env e' opzionale per tooling/test Node.js non eseguiti dal Functions host

## Troubleshooting rapido

- Verifica host locale con npm start
- Verifica logs in Application Insights
- Controlla dead-letter queue Service Bus
- Verifica permessi Managed Identity per storage/eventi
