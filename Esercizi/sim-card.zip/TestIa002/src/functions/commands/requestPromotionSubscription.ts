import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { requestPromotionSubscription } from "../../application/commandHandlers/promotionCommandHandler";
import { mapRequestPromotionSubscriptionResponse } from "../mappers/commandHttpMapper";
import { accepted, badRequest, readJsonBody } from "../../shared/http";

export async function requestPromotionSubscriptionHttp(
  request: HttpRequest,
  context: InvocationContext
): Promise<HttpResponseInit> {
  try {
    const body = await readJsonBody<unknown>(request);
    const subscription = await requestPromotionSubscription(body);
    return accepted(mapRequestPromotionSubscriptionResponse(subscription));
  } catch (error) {
    context.error("RequestPromotionSubscription failed", error);
    return badRequest("Invalid promotion subscription payload.");
  }
}

app.http("RequestPromotionSubscription", {
  methods: ["POST"],
  authLevel: "function",
  route: "promotions/subscriptions",
  handler: requestPromotionSubscriptionHttp
});
