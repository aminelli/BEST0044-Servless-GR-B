export class PhoneNumber {
  private constructor(public readonly value: string) {}

  static create(raw: string): PhoneNumber {
    const value = raw?.trim();
    if (!value || value.length < 5) {
      throw new Error("Invalid PhoneNumber.");
    }

    return new PhoneNumber(value);
  }
}
