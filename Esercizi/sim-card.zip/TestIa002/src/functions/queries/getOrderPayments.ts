import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getPaymentsByOrder } from "../../application/queryHandlers/paymentQueryHandler";
import { mapItemsResponse, mapPaymentQueryFilter, mapRouteParam } from "../mappers/queryHttpMapper";
import { badRequest, ok } from "../../shared/http";

app.http("GetOrderPayments", {
  methods: ["GET"],
  authLevel: "function",
  route: "orders/{orderId}/payments",
  handler: async (request: HttpRequest): Promise<HttpResponseInit> => {
    const routeOrderId = mapRouteParam(request, "orderId");
    if (!routeOrderId.ok) {
      return badRequest(routeOrderId.error);
    }

    const paymentFilter = mapPaymentQueryFilter(request);
    if (!paymentFilter.ok) {
      return badRequest(paymentFilter.error);
    }

    const items = await getPaymentsByOrder(routeOrderId.value, paymentFilter.value);
    return ok(mapItemsResponse(items));
  }
});
