import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { getAvailablePromotions } from "../../application/queryHandlers/promotionQueryHandler";
import { mapItemsResponse } from "../mappers/queryHttpMapper";
import { ok } from "../../shared/http";

app.http("GetAvailablePromotions", {
  methods: ["GET"],
  authLevel: "function",
  route: "promotions/available",
  handler: async (_request: HttpRequest): Promise<HttpResponseInit> => {
    const items = await getAvailablePromotions();
    return ok(mapItemsResponse(items));
  }
});
