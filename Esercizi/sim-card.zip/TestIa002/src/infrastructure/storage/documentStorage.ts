import { BlobServiceClient } from "@azure/storage-blob";

export async function uploadTextDocument(
  containerName: string,
  blobName: string,
  content: string
): Promise<string> {
  const connectionString = process.env.BLOB_CONNECTION_STRING;
  if (!connectionString) {
    return `mock://${containerName}/${blobName}`;
  }

  const blobClient = BlobServiceClient.fromConnectionString(connectionString);
  const containerClient = blobClient.getContainerClient(containerName);
  await containerClient.createIfNotExists();
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);
  await blockBlobClient.uploadData(Buffer.from(content, "utf-8"));
  return blockBlobClient.url;
}
