import { app, HttpRequest, HttpResponseInit, InvocationContext } from "@azure/functions";
import { activatePromotion } from "../../application/commandHandlers/promotionLifecycleCommandHandler";
import { mapActivatePromotionCommand, mapRouteParam } from "../mappers/commandHttpMapper";
import { accepted, badRequest } from "../../shared/http";

app.http("ActivatePromotion", {
  methods: ["POST"],
  authLevel: "function",
  route: "promotions/subscriptions/{subscriptionId}/activate",
  handler: async (request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit> => {
    try {
      const routeSubscriptionId = mapRouteParam(request, "subscriptionId");
      if (!routeSubscriptionId.ok) {
        return badRequest(routeSubscriptionId.error);
      }

      const result = await activatePromotion(mapActivatePromotionCommand(routeSubscriptionId.value));

      return accepted(result);
    } catch (error) {
      context.error("ActivatePromotion failed", error);
      return badRequest("Invalid promotion activation payload.");
    }
  }
});
